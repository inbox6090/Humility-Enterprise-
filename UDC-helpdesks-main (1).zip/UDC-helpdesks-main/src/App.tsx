import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HomeScreen } from './components/HomeScreen';
import { AiChatScreen } from './components/AiChatScreen';
import { ContactDirectoryScreen } from './components/ContactDirectoryScreen';
import { ServiceDetailModal } from './components/ServiceDetailModal';
import { PhoneCallModal } from './components/PhoneCallModal';
import { Footer } from './components/Footer';
import { DEFAULT_OPERATOR, SERVICES_DATA } from './data/knowledgeBase';
import { ServiceItem, OperatorProfile, Route } from './types';
import { MessageCircle, Sparkles } from 'lucide-react';

export default function App() {
  const [route, setRoute] = useState<Route>('Home');
  const [services, setServices] = useState<ServiceItem[]>(SERVICES_DATA);
  const [operator, setOperator] = useState<OperatorProfile>(DEFAULT_OPERATOR);
  const [selectedServiceModal, setSelectedServiceModal] = useState<ServiceItem | null>(null);
  const [chatServiceContext, setChatServiceContext] = useState<ServiceItem | null>(null);
  const [chatInitialQuery, setChatInitialQuery] = useState<string | null>(null);
  const [showOperatorEditModal, setShowOperatorEditModal] = useState<boolean>(false);
  const [showCallWarningModal, setShowCallWarningModal] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  // Monitor online / offline network state
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Fetch live services and operator from backend
    fetch('/api/services')
      .then((res) => res.json())
      .then((data) => {
        if (data.services) setServices(data.services);
        if (data.operator) setOperator(data.operator);
      })
      .catch((err) => {
        console.warn('Using local knowledge base state:', err);
      });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Update operator profile on server and state
  const handleUpdateOperator = async (updated: Partial<OperatorProfile>) => {
    try {
      const res = await fetch('/api/operator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });
      const data = await res.json();
      if (data.operator) {
        setOperator(data.operator);
      }
    } catch (err) {
      console.error('Failed to update operator:', err);
      // Update local state fallback
      setOperator((prev) => ({ ...prev, ...updated }));
    }
  };

  // Switch to chat with specific service context
  const handleNavigateAiChat = (service?: ServiceItem | null, initialQuery?: string) => {
    setChatServiceContext(service || null);
    setChatInitialQuery(initialQuery || null);
    setRoute('AiChat');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateContactDirectory = () => {
    setRoute('ContactDirectory');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHome = () => {
    setRoute('Home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-100 text-slate-800 antialiased font-sans">
      {/* Top Header */}
      <Header
        operator={operator}
        currentRoute={route}
        onNavigate={setRoute}
        isOnline={isOnline}
        onOpenOperatorModal={() => setShowOperatorEditModal(true)}
      />

      {/* Main Screen Router */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-4 py-4 sm:py-6">
        {/* Screen 1: HomeScreen */}
        {route === 'Home' && (
          <HomeScreen
            operator={operator}
            services={services}
            onNavigateAiChat={handleNavigateAiChat}
            onNavigateContactDirectory={handleNavigateContactDirectory}
            onUpdateOperator={handleUpdateOperator}
            showOperatorEditModal={showOperatorEditModal}
            setShowOperatorEditModal={setShowOperatorEditModal}
            onCallWarningModal={() => setShowCallWarningModal(true)}
            onSelectServiceModal={(srv) => setSelectedServiceModal(srv)}
          />
        )}

        {/* Screen 2: AiChatScreen */}
        {route === 'AiChat' && (
          <AiChatScreen
            operator={operator}
            serviceContext={chatServiceContext}
            initialQuery={chatInitialQuery}
            onClearServiceContext={() => {
              setChatServiceContext(null);
              setChatInitialQuery(null);
            }}
            onBackToHome={handleBackToHome}
          />
        )}

        {/* Screen 3: ContactDirectoryScreen */}
        {route === 'ContactDirectory' && (
          <ContactDirectoryScreen
            onBackToHome={handleBackToHome}
            onAskAiWithContext={(query) => {
              handleNavigateAiChat(null, query);
            }}
          />
        )}
      </main>

      {/* Floating Quick Action Bar for Mobile Viewers */}
      <div className="sm:hidden fixed bottom-3 left-3 right-3 z-30 flex items-center gap-2 bg-[#0c1e36]/95 backdrop-blur-md p-2 rounded-2xl border border-slate-700/80 shadow-2xl">
        <a
          id="mobile-float-whatsapp-btn"
          href={operator.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2.5 px-3 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all"
        >
          <MessageCircle className="w-4 h-4" />
          <span>WhatsApp চ্যাট</span>
        </a>

        <button
          id="mobile-float-ai-btn"
          onClick={() => handleNavigateAiChat(null)}
          className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all"
        >
          <Sparkles className="w-4 h-4 text-emerald-300 animate-spin-slow" />
          <span>AI সহকারী</span>
        </button>
      </div>

      {/* Detailed Service Specs Modal */}
      <ServiceDetailModal
        service={selectedServiceModal}
        operator={operator}
        onClose={() => setSelectedServiceModal(null)}
        onAskAi={(srv, query) => handleNavigateAiChat(srv, query)}
      />

      {/* Call Warning Modal */}
      <PhoneCallModal
        isOpen={showCallWarningModal}
        onClose={() => setShowCallWarningModal(false)}
        operator={operator}
      />

      {/* Government Standard Footer */}
      <Footer operator={operator} />
    </div>
  );
}
