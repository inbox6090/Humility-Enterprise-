export type Route = 'Home' | 'AiChat' | 'ContactDirectory';

export interface ServiceItem {
  id: string;
  name: string;
  shortDescription: string;
  category: 'civil' | 'certificate' | 'social_welfare' | 'status' | 'other';
  requiredDocuments: string[];
  fee: string;
  processingTime: string;
  counter: string; // UDC / সচিব / চেয়ারম্যান
  applicationProcess: string[];
  commonQuestions: { question: string; answer: string }[];
  commonMistakes: string[];
  importantNotes: string[];
  contactInstructions: string;
}

export interface OperatorProfile {
  name: string;
  role: string;
  unionName: string;
  upazila: string;
  district: string;
  phone: string;
  whatsappUrl: string;
  facebookUrl: string;
  email: string;
  photoUrl: string;
}

// --------------------------------------------------------------------------
// Full Production Gemini Input & Output Schema Types
// --------------------------------------------------------------------------
export type ChatbotIntent = 
  | 'generalquery' 
  | 'servicequery' 
  | 'statuscheck' 
  | 'complaint' 
  | 'suggestion' 
  | 'contactrequest' 
  | 'other'
  | 'status_check' 
  | 'general_query';

export type ChatbotCategory = 
  | 'সনদ' 
  | 'জন্ম' 
  | 'মৃত্যু' 
  | 'রাস্তা' 
  | 'পানি' 
  | 'বিদ্যুৎ' 
  | 'প্রশাসনিক' 
  | 'অন্যান্য' 
  | 'none';

export interface FormattedResponseReportAnalysis {
  reportNumber: string;
  summary: string;
  possible_reason: string;
  recommended_action: string;
}

export interface FormattedResponseContact {
  call: string;
  whatsapp: string;
  sms: string;
  email: string;
}

export interface FormattedResponse {
  service: string;
  documents: string[];
  steps: string[];
  counter: string;
  notes: string[];
  report_analysis: FormattedResponseReportAnalysis;
  contact: FormattedResponseContact;
}

export interface OfficeHoursInfo {
  call_available: string;
  closed: string;
}

export interface GeminiInputPayload {
  message: string;
  serviceName?: string | null;
  reportNumber?: string | null;
  context?: string | null;
  citizenProfile?: {
    name: string;
    mobile: string;
    address: string;
  } | null;
  serviceData?: {
    documents: string[];
    steps: string[];
    counter: string;
    notes: string[];
  } | null;
  contactDirectory?: any | null;
  flowStep?: 'greeting' | 'ask_name' | 'ask_mobile' | 'check_returning' | 'validate_report' | 'new_citizen_issue' | 'final_template';
}

export interface GeminiOutputResponse {
  intent: ChatbotIntent;
  category: ChatbotCategory;
  confidence_score: number;
  reply_text: string;
  needs_escalation: boolean;
  ticket_summary: string | null;
  formatted_response: FormattedResponse;
  ticket_id?: string | null;
  channel?: 'whatsapp' | 'call' | 'web';
  office_hours?: OfficeHoursInfo;
  generated_report_number?: string;
  flow_step?: string;
}

export type ChatbotResponse = GeminiOutputResponse;

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  serviceId?: string;
  suggestedQuestions?: string[];
  isError?: boolean;
  intent?: ChatbotIntent;
  category?: ChatbotCategory;
  confidence_score?: number;
  needs_escalation?: boolean;
  ticket_summary?: string | null;
  ticket_id?: string | null;
  channel?: 'whatsapp' | 'call' | 'web';
  formatted_response?: FormattedResponse;
  office_hours?: OfficeHoursInfo;
  generated_report_number?: string;
}

export interface TicketItem {
  ticketId: string;
  timestamp: string;
  phone: string;
  channel: 'whatsapp' | 'call' | 'web';
  intent: string;
  category: string;
  summary: string;
  status: 'গৃহীত' | 'প্রক্রিয়াধীন' | 'সমাধানকৃত';
}

export interface EscalationItem {
  id: string;
  timestamp: string;
  phone: string;
  channel: string;
  userMessage: string;
  confidence_score: number;
  handled: 'হ্যাঁ' | 'না';
  reason?: string;
}

export interface CitizenProfile {
  name: string;
  phone: string;
  lastApplication?: string;
  address?: string;
}

export interface CitizenReportItem {
  reportNo: string;
  citizenName: string;
  serviceName: string;
  previousIssue: string; // তাদের পূর্বের সমস্যা কী ছিল
  reasonForContact: string; // কেন তারা যোগাযোগ করছে
  relatedDocuments: string[]; // কোন সেবা বা নথি সম্পর্কিত সমস্যা
  stuckStep: string; // কোন ধাপে তারা আটকে গেছে
  currentStatus: string;
  counter: string; // UDC / সচিব / চেয়ারম্যান
  recommendedAction: string;
  submissionDate?: string;
}

export interface ApplicationStatusResult {
  found: boolean;
  trackingId?: string; // used interchangeably with reportNo
  reportNo?: string;
  applicantName?: string;
  serviceName?: string;
  previousIssue?: string;
  reasonForContact?: string;
  relatedDocuments?: string[];
  stuckStep?: string;
  status?: 'received' | 'processing' | 'ready' | 'delivered' | 'contact_office';
  statusText?: string;
  submissionDate?: string;
  counter?: string;
  recommendedAction?: string;
  message: string;
}

export interface ContactPerson {
  name: string;
  mobile: string;
  whatsapp: string;
  role: string;
  duty?: string;
  ward?: string;
  email?: string;
}

export interface ContactDirectorySchema {
  chairman: ContactPerson;
  secretary: ContactPerson;
  udc_operator: ContactPerson;
  members: ContactPerson[];
  reserved_female_members: ContactPerson[];
  village_police: ContactPerson[];
  admin_officer: ContactPerson;
}

