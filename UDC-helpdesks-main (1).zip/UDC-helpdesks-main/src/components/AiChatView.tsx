import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Sparkles, 
  Trash2, 
  Copy, 
  Check, 
  MessageCircle, 
  Bot, 
  User, 
  RefreshCw, 
  AlertCircle,
  HelpCircle,
  ShieldCheck,
  ChevronRight,
  Ticket,
  AlertTriangle,
  Code,
  Phone,
  Globe,
  Radio,
  ArrowLeft,
  WifiOff,
  GitBranch,
  PhoneCall,
  Mic,
  MicOff
} from 'lucide-react';
import { ChatMessage, ServiceItem, OperatorProfile, ChatbotIntent, ChatbotCategory } from '../types';
import { REGISTERED_CITIZENS_DATA } from '../data/knowledgeBase';
import { TicketEscalationModal } from './TicketEscalationModal';
import { GasCodeModal } from './GasCodeModal';
import { FlowchartModal } from './FlowchartModal';
import { FlowStepIndicator } from './FlowStepIndicator';

interface AiChatViewProps {
  operator: OperatorProfile;
  initialServiceContext?: ServiceItem | null;
  initialQuery?: string | null;
  onClearServiceContext?: () => void;
  onBackToHome?: () => void;
}

export const AiChatView: React.FC<AiChatViewProps> = ({
  operator,
  initialServiceContext,
  initialQuery,
  onClearServiceContext,
  onBackToHome,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [currentService, setCurrentService] = useState<ServiceItem | null>(initialServiceContext || null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Chatbot channel & citizen simulator state
  const [selectedChannel, setSelectedChannel] = useState<'whatsapp' | 'web' | 'call'>('whatsapp');
  const [selectedPhone, setSelectedPhone] = useState<string>('01711000001');
  const [customPhone, setCustomPhone] = useState<string>('');
  const [isTicketModalOpen, setIsTicketModalOpen] = useState<boolean>(false);
  const [isGasModalOpen, setIsGasModalOpen] = useState<boolean>(false);
  const [isFlowchartModalOpen, setIsFlowchartModalOpen] = useState<boolean>(false);

  // Flowchart state machine tracking (Supports 7-step WhatsApp flow Q1-Q7)
  const [flowchartState, setFlowchartState] = useState<{
    active: boolean;
    flowType?: 'whatsapp_q1_q7' | 'legacy';
    step: 'q1_name' | 'q2_mobile' | 'q3_previous_contact' | 'q4_service' | 'q5_purpose' | 'q6_documents_time' | 'q7_prior_submission' | 'completed' | 'ask_name' | 'ask_mobile' | 'returning_citizen' | 'new_citizen';
    stepNumber?: number;
    citizenName?: string;
    mobile?: string;
    reportNumber?: string;
    q1_name?: string;
    q2_mobile?: string;
    q3_previous_contact?: string;
    q4_service?: string;
    q5_purpose?: string;
    q6_documents_time?: string;
    q7_prior_submission?: string;
  }>({ active: false, step: 'q1_name' });

  // Web Speech API (window.SpeechRecognition) state
  const [isListening, setIsListening] = useState<boolean>(false);
  const [speechError, setSpeechError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // Toggle Web Speech recognition
  const toggleSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setSpeechError('আপনার ব্রাউজারে স্পিচ রিকগনিশন (Web Speech API) সমর্থিত নয়। অনুগ্রহ করে Google Chrome বা Edge ব্যবহার করুন।');
      setTimeout(() => setSpeechError(null), 5000);
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          console.warn('Error stopping speech recognition:', e);
        }
      }
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'bn-BD'; // Primary Bangla (Bangladesh)
      recognition.interimResults = true;
      recognition.continuous = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setSpeechError(null);
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          currentTranscript += event.results[i][0].transcript;
        }
        if (currentTranscript) {
          // Automatically inject transcribed text into chat input field
          setInputPrompt(currentTranscript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition event error:', event.error);
        if (event.error === 'not-allowed' || event.error === 'permission-denied') {
          setSpeechError('মাইক্রোফোন ব্যবহারের অনুমতি দিন (Microphone permission required)।');
        } else if (event.error === 'no-speech') {
          setSpeechError('কোনো কথা শনাক্ত করা যায়নি। অনুগ্রহ করে পুনরায় মাইক্রোফোন চেপে স্পষ্ট করে বলুন।');
        } else if (event.error === 'network') {
          setSpeechError('ভয়েস সার্ভারের সাথে সংযোগে সমস্যা হয়েছে। ইন্টারনেট সংযোগ চেক করুন।');
        } else {
          setSpeechError('ভয়েস শনাক্তকরণে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
        }
        setIsListening(false);
        setTimeout(() => setSpeechError(null), 5000);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Failed to initiate SpeechRecognition:', err);
      setIsListening(false);
      setSpeechError('মাইক্রোফোন চালু করা সম্ভব হয়নি।');
      setTimeout(() => setSpeechError(null), 4000);
    }
  };

  // Cleanup speech recognition on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }
    };
  }, []);

  // Active citizen information from UPMS lookup
  const activeCitizen = REGISTERED_CITIZENS_DATA.find(c => c.phone === (customPhone || selectedPhone));

  // Default suggested questions
  const defaultSuggestions = [
    '💬 WhatsApp ফ্লো শুরু করুন (Q1–Q7)',
    'আমার রিপোর্ট নং BT-REP-01 এর সমস্যা ও করণীয় কি?',
    'সখীপুর রোডের বহেড়াতৈল বাজারে ড্রেন বন্ধ হয়ে পানি জমে আছে (অভিযোগ)',
    'জন্ম নিবন্ধনে কী কী কাগজপত্র লাগে?',
    'নাগরিক সনদ পেতে কার সুপারিশ প্রয়োজন?',
    'ইউনিয়ন পরিষদে বয়োজ্যেষ্ঠদের বসার জন্য ব্যবস্থা করা দরকার (পরামর্শ)'
  ];

  // Initialize welcome message
  useEffect(() => {
    if (initialServiceContext) {
      setCurrentService(initialServiceContext);
      setMessages([
        {
          id: 'welcome-context',
          role: 'assistant',
          content: `আসসালামু আলাইকুম! আপনি **${initialServiceContext.name}** সেবা সম্পর্কে জানতে চেয়েছেন।\n\n${initialServiceContext.name} সম্পর্কে কোন তথ্যটি জানতে চান? নিচের অপশন নির্বাচন করুন অথবা সরাসরি প্রশ্ন লিখুন:`,
          timestamp: Date.now(),
          suggestedQuestions: [
            `${initialServiceContext.name} প্রয়োজনীয় কাগজপত্র`,
            `${initialServiceContext.name} প্রক্রিয়াকরণ ধাপসমূহ`,
            `${initialServiceContext.name} দায়িত্বপ্রাপ্ত কাউন্টার`,
            'আমার রিপোর্ট নং দিয়ে স্ট্যাটাস জানব কীভাবে?'
          ]
        }
      ]);
    } else if (messages.length === 0) {
      setMessages([
        {
          id: 'welcome-default',
          role: 'assistant',
          content: `আসসালামু আলাইকুম! আমি **সহায়ক** — ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল সিটিজেন অ্যাসিস্ট্যান্ট। 🤝\n\nবহেড়াতৈল ইউনিয়নের নাগরিক সেবা, অভিযোগ দায়ের, পরামর্শ প্রদান বা রিপোর্ট ট্র্যাকিংয়ের জন্য আপনার বার্তা নিচে লিখুন।\n\n📌 আপনার যদি পূর্বে জমা দেওয়া কোনো **"রিপোর্ট নং"** (যেমন: BT-REP-01) থাকে, তবে তা লিখুন—আপনার পূর্বের সমস্যা এবং আটকে থাকা ধাপ পর্যালোচনা করে তাৎক্ষণিক দিকনির্দেশনা দেওয়া হবে।`,
          timestamp: Date.now(),
          suggestedQuestions: defaultSuggestions
        }
      ]);
    }
  }, [initialServiceContext]);

  useEffect(() => {
    if (initialQuery) {
      setInputPrompt(initialQuery);
    }
  }, [initialQuery]);

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Start WhatsApp 7-step Q1-Q7 Flow
  const startWhatsAppFlow = async () => {
    setSelectedChannel('whatsapp');
    setIsLoading(true);
    try {
      const fcRes = await fetch('/api/flowchart/step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ step: 'whatsapp_start' })
      });
      const fcData = await fcRes.json();

      setFlowchartState({
        active: true,
        flowType: 'whatsapp_q1_q7',
        step: 'q1_name',
        stepNumber: 1,
        citizenName: '',
        mobile: '',
        q1_name: '',
        q2_mobile: '',
        q3_previous_contact: '',
        q4_service: '',
        q5_purpose: '',
        q6_documents_time: '',
        q7_prior_submission: '',
        reportNumber: undefined
      });

      const assistantMessage: ChatMessage = {
        id: `ai-wa-${Date.now()}`,
        role: 'assistant',
        content: fcData.reply,
        timestamp: Date.now(),
        channel: 'whatsapp',
        suggestedQuestions: fcData.quickOptions
      };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      console.error('WhatsApp flow start error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputPrompt).trim();
    if (!query || isLoading) return;

    // Check if user clicked to start WhatsApp onboarding flow
    if (query === '💬 WhatsApp ফ্লো শুরু করুন (Q1–Q7)' || query === 'WhatsApp ফ্লো শুরু করুন') {
      setInputPrompt('');
      await startWhatsAppFlow();
      return;
    }

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: Date.now()
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputPrompt('');
    setIsLoading(true);

    // 💬 7-STEP WHATSAPP ONBOARDING FLOW STATE MACHINE (Q1 ➔ Q7)
    if (flowchartState.active && flowchartState.flowType === 'whatsapp_q1_q7') {
      try {
        let payload: any = {};
        const curStep = flowchartState.step;

        if (curStep === 'q1_name') {
          payload = { 
            step: 'q2_mobile', 
            q1_name: query, 
            name: query, 
            userResponse: query 
          };
        } else if (curStep === 'q2_mobile') {
          payload = { 
            step: 'q3_previous_contact', 
            q1_name: flowchartState.q1_name, 
            q2_mobile: query, 
            mobile: query, 
            userResponse: query 
          };
        } else if (curStep === 'q3_previous_contact') {
          payload = { 
            step: 'q4_service', 
            q1_name: flowchartState.q1_name, 
            q2_mobile: flowchartState.q2_mobile, 
            q3_previous_contact: query, 
            userResponse: query 
          };
        } else if (curStep === 'q4_service') {
          payload = { 
            step: 'q5_purpose', 
            q1_name: flowchartState.q1_name, 
            q2_mobile: flowchartState.q2_mobile, 
            q3_previous_contact: flowchartState.q3_previous_contact, 
            q4_service: query, 
            userResponse: query 
          };
        } else if (curStep === 'q5_purpose') {
          payload = { 
            step: 'q6_documents_time', 
            q1_name: flowchartState.q1_name, 
            q2_mobile: flowchartState.q2_mobile, 
            q3_previous_contact: flowchartState.q3_previous_contact, 
            q4_service: flowchartState.q4_service, 
            q5_purpose: query, 
            userResponse: query 
          };
        } else if (curStep === 'q6_documents_time') {
          payload = { 
            step: 'q7_prior_submission', 
            q1_name: flowchartState.q1_name, 
            q2_mobile: flowchartState.q2_mobile, 
            q3_previous_contact: flowchartState.q3_previous_contact, 
            q4_service: flowchartState.q4_service, 
            q5_purpose: flowchartState.q5_purpose, 
            q6_documents_time: query, 
            userResponse: query 
          };
        } else if (curStep === 'q7_prior_submission') {
          payload = { 
            step: 'whatsapp_summary', 
            q1_name: flowchartState.q1_name, 
            q2_mobile: flowchartState.q2_mobile, 
            q3_previous_contact: flowchartState.q3_previous_contact, 
            q4_service: flowchartState.q4_service, 
            q5_purpose: flowchartState.q5_purpose, 
            q6_documents_time: flowchartState.q6_documents_time, 
            q7_prior_submission: query, 
            userResponse: query 
          };
        }

        const fcRes = await fetch('/api/flowchart/step', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const fcData = await fcRes.json();

        // Advance the state machine
        if (curStep === 'q1_name') {
          setFlowchartState(prev => ({
            ...prev,
            step: 'q2_mobile',
            stepNumber: 2,
            q1_name: query,
            citizenName: query
          }));
        } else if (curStep === 'q2_mobile') {
          setFlowchartState(prev => ({
            ...prev,
            step: 'q3_previous_contact',
            stepNumber: 3,
            q2_mobile: query,
            mobile: query
          }));
        } else if (curStep === 'q3_previous_contact') {
          setFlowchartState(prev => ({
            ...prev,
            step: 'q4_service',
            stepNumber: 4,
            q3_previous_contact: query
          }));
        } else if (curStep === 'q4_service') {
          setFlowchartState(prev => ({
            ...prev,
            step: 'q5_purpose',
            stepNumber: 5,
            q4_service: query
          }));
        } else if (curStep === 'q5_purpose') {
          setFlowchartState(prev => ({
            ...prev,
            step: 'q6_documents_time',
            stepNumber: 6,
            q5_purpose: query
          }));
        } else if (curStep === 'q6_documents_time') {
          setFlowchartState(prev => ({
            ...prev,
            step: 'q7_prior_submission',
            stepNumber: 7,
            q6_documents_time: query
          }));
        } else if (curStep === 'q7_prior_submission') {
          setFlowchartState(prev => ({
            ...prev,
            active: false,
            flowType: 'whatsapp_q1_q7',
            step: 'completed',
            stepNumber: 8,
            q7_prior_submission: query,
            reportNumber: fcData.generated_report_number
          }));
        }

        const assistantMessage: ChatMessage = {
          id: `ai-wa-${Date.now()}`,
          role: 'assistant',
          content: fcData.reply,
          timestamp: Date.now(),
          category: fcData.category,
          formatted_response: fcData.formatted_response,
          generated_report_number: fcData.generated_report_number,
          office_hours: fcData.office_hours,
          suggestedQuestions: fcData.quickOptions || (fcData.currentStep === 'completed' ? [
            'আমার রিপোর্ট নং দিয়ে ট্র্যাকিং করতে চাই',
            'নতুন কোনো সেবার তথ্য ও নিয়ম জানতে চাই',
            'ইউনিয়ন পরিষদ হেল্পডেস্কে সরাসরি যোগাযোগ'
          ] : undefined)
        };
        setMessages((prev) => [...prev, assistantMessage]);
      } catch (err) {
        console.error('WhatsApp flowchart step execution failed:', err);
      } finally {
        setIsLoading(false);
      }
      return;
    }

    // Legacy / Fallback interactive Flowchart Mode
    if (flowchartState.active) {
      try {
        let payload: any = { step: flowchartState.step };
        if (flowchartState.step === 'ask_name') {
          payload = { step: 'name', name: query };
        } else if (flowchartState.step === 'ask_mobile') {
          payload = { step: 'mobile', mobile: query, name: flowchartState.citizenName };
        } else if (flowchartState.step === 'returning_citizen') {
          payload = { step: 'validate_report', reportNumber: query };
        } else if (flowchartState.step === 'new_citizen') {
          payload = { step: 'new_issue', issueText: query, name: flowchartState.citizenName, mobile: flowchartState.mobile };
        }

        const fcRes = await fetch('/api/flowchart/step', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const fcData = await fcRes.json();

        if (flowchartState.step === 'ask_name') {
          setFlowchartState({
            active: true,
            step: 'ask_mobile',
            citizenName: query
          });
        } else if (flowchartState.step === 'ask_mobile') {
          setFlowchartState({
            active: true,
            step: fcData.isReturning ? 'returning_citizen' : 'new_citizen',
            citizenName: fcData.citizenName || flowchartState.citizenName,
            mobile: query
          });
        } else if (flowchartState.step === 'returning_citizen') {
          if (!fcData.valid) {
            setFlowchartState(prev => ({ ...prev, step: 'returning_citizen' }));
          } else {
            setFlowchartState({ active: false, step: 'completed' });
          }
        } else if (flowchartState.step === 'new_citizen') {
          setFlowchartState({ active: false, step: 'completed' });
        }

        const assistantMessage: ChatMessage = {
          id: `ai-fc-${Date.now()}`,
          role: 'assistant',
          content: fcData.reply,
          timestamp: Date.now(),
          category: fcData.category,
          formatted_response: fcData.formatted_response,
          generated_report_number: fcData.generated_report_number,
          office_hours: {
            call_available: "10:00–17:00 (Sat–Thu)",
            closed: "Friday & Govt Holidays"
          },
          suggestedQuestions: fcData.currentStep === 'completed' ? [
            'আমার রিপোর্ট নং দিয়ে পুনরায় চেক করুন',
            'অন্য কোনো সেবার তথ্য জানতে চাই'
          ] : undefined
        };
        setMessages((prev) => [...prev, assistantMessage]);
      } catch (err) {
        console.error('Flowchart step execution failed:', err);
      } finally {
        setIsLoading(false);
      }
      return;
    }

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          serviceName: currentService?.name || null,
          serviceData: currentService ? {
            documents: currentService.requiredDocuments,
            steps: currentService.applicationProcess,
            counter: currentService.counter,
            notes: currentService.importantNotes
          } : null,
          phone: customPhone.trim() || selectedPhone,
          channel: selectedChannel,
          serviceId: currentService?.id,
          history: messages.slice(-6).map(m => ({ role: m.role, content: m.content }))
        })
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      
      const assistantMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        content: data.reply || data.reply_text || 'দুঃখিত, কোনো উত্তর পাওয়া যায়নি।',
        timestamp: Date.now(),
        intent: data.intent as ChatbotIntent,
        category: data.category as ChatbotCategory,
        confidence_score: data.confidence_score,
        needs_escalation: data.needs_escalation,
        ticket_id: data.ticket_id,
        ticket_summary: data.ticket_summary,
        formatted_response: data.formatted_response,
        office_hours: data.office_hours,
        generated_report_number: data.generated_report_number,
        suggestedQuestions: currentService ? [
          `${currentService.name} আবেদনের নিয়ম কী?`,
          'ইউনিয়ন পরিষদ হেল্পডেস্কের যোগাযোগ তথ্য'
        ] : [
          'জন্ম নিবন্ধন সংশোধনের নিয়ম কী?',
          'নাগরিক সনদের আবেদন প্রক্রিয়া'
        ]
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: `AI সহকারী এই মুহূর্তে সাময়িকভাবে unavailable। অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন অথবা WhatsApp-এ লিখিতভাবে যোগাযোগ করুন।\n\n📌 সরাসরি হেল্পডেস্ক: **${operator.phone}**`,
        timestamp: Date.now(),
        isError: true
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    if (onClearServiceContext) onClearServiceContext();
    setCurrentService(null);
    setMessages([
      {
        id: `cleared-${Date.now()}`,
        role: 'assistant',
        content: `চ্যাট রিসেট করা হয়েছে। ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের যে কোনো সেবা বা অভিযোগ সম্পর্কে আবার প্রশ্ন করতে পারেন।`,
        timestamp: Date.now(),
        suggestedQuestions: defaultSuggestions
      }
    ]);
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden flex flex-col h-[78vh] sm:h-[82vh]">
      {/* Modals */}
      <TicketEscalationModal 
        isOpen={isTicketModalOpen}
        onClose={() => setIsTicketModalOpen(false)}
      />
      <GasCodeModal
        isOpen={isGasModalOpen}
        onClose={() => setIsGasModalOpen(false)}
      />
      <FlowchartModal
        isOpen={isFlowchartModalOpen}
        onClose={() => setIsFlowchartModalOpen(false)}
      />

      {/* Chat Header */}
      <div className="px-4 py-3 bg-gradient-to-r from-[#0c1e36] to-[#16355d] text-white flex items-center justify-between border-b border-slate-700 shrink-0">
        <div className="flex items-center gap-2.5">
          {onBackToHome && (
            <button
              id="chat-back-to-home-btn"
              onClick={onBackToHome}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all flex items-center gap-1 text-xs font-semibold active:scale-95 mr-1"
              title="হোমে ফিরে যান"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">হোম</span>
            </button>
          )}
          <div className="w-9 h-9 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
            <Sparkles className="w-4 h-4 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-sm font-bold text-white">AI সহকারী (Digital Citizen Assistant)</h3>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
            <p className="text-[11px] text-slate-300">
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ • WhatsApp, কল ও ওয়েব হেল্পডেস্ক
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Quick trigger for 7-step WhatsApp Flow (Q1 to Q7) */}
          <button
            id="start-whatsapp-q1-q7-btn"
            onClick={startWhatsAppFlow}
            className="px-2.5 py-1 text-emerald-100 bg-emerald-600 hover:bg-emerald-500 border border-emerald-400/40 rounded-lg text-xs flex items-center gap-1.5 transition-all shadow-xs font-medium active:scale-95"
            title="৭-ধাপ WhatsApp অনবোর্ডিং ফ্লো শুরু করুন (Q1 থেকে Q7)"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-200" />
            <span className="hidden sm:inline">WhatsApp ফ্লো (Q1–Q7)</span>
          </button>

          <button
            onClick={() => setIsFlowchartModalOpen(true)}
            className="px-2 py-1 text-amber-200 bg-amber-950/60 hover:bg-amber-900 border border-amber-500/40 rounded-lg text-xs flex items-center gap-1 transition-all"
            title="ফ্লোচার্ট নির্দেশিকা ও রূপরেখা"
          >
            <GitBranch className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">ফ্লোচার্ট</span>
          </button>

          <button
            onClick={() => setIsTicketModalOpen(true)}
            className="px-2.5 py-1 text-emerald-200 bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 rounded-lg text-xs flex items-center gap-1 transition-all"
            title="লাইভ টিকেট ও এসকেলেশন তালিকা"
          >
            <Ticket className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden lg:inline">টিকেট ট্র্যাকার</span>
          </button>

          <button
            onClick={() => setIsGasModalOpen(true)}
            className="px-2.5 py-1 text-sky-200 bg-sky-950/60 hover:bg-sky-900 border border-sky-500/40 rounded-lg text-xs flex items-center gap-1 transition-all"
            title="Google Apps Script (AI_Chatbot.gs) কোড"
          >
            <Code className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden lg:inline">GAS কোড</span>
          </button>

          <button
            id="clear-chat-btn"
            onClick={handleClearChat}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg text-xs flex items-center gap-1 transition-colors"
            title="নতুন চ্যাট শুরু করুন"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">রিসেট</span>
          </button>
        </div>
      </div>

      {/* Interactive Simulation Strip: Channel & Citizen Switcher */}
      <div className="bg-slate-100/90 px-3.5 py-2 border-b border-slate-200 text-xs flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex flex-wrap items-center gap-3">
          {/* Channel selector */}
          <div className="flex items-center gap-1 bg-white px-2 py-1 rounded-lg border border-slate-200 shadow-2xs">
            <span className="text-[11px] font-semibold text-slate-500">চ্যানেল:</span>
            <div className="flex items-center gap-1 text-[11px]">
              <button
                onClick={() => setSelectedChannel('whatsapp')}
                className={`px-2 py-0.5 rounded font-medium flex items-center gap-1 transition-all ${
                  selectedChannel === 'whatsapp'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <MessageCircle className="w-3 h-3" />
                <span>WhatsApp</span>
              </button>
              <button
                onClick={() => setSelectedChannel('web')}
                className={`px-2 py-0.5 rounded font-medium flex items-center gap-1 transition-all ${
                  selectedChannel === 'web'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Globe className="w-3 h-3" />
                <span>ওয়েব</span>
              </button>
              <button
                onClick={() => setSelectedChannel('call')}
                className={`px-2 py-0.5 rounded font-medium flex items-center gap-1 transition-all ${
                  selectedChannel === 'call'
                    ? 'bg-purple-600 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                <Phone className="w-3 h-3" />
                <span>কল-লগ</span>
              </button>
            </div>
          </div>

          {/* Citizen phone simulator */}
          <div className="flex items-center gap-1.5 bg-white px-2 py-1 rounded-lg border border-slate-200 shadow-2xs text-[11px]">
            <span className="text-slate-500 font-semibold">নাগরিক:</span>
            <select
              value={selectedPhone}
              onChange={(e) => {
                setSelectedPhone(e.target.value);
                setCustomPhone('');
              }}
              className="bg-transparent font-sans text-slate-800 text-[11px] focus:outline-none cursor-pointer"
            >
              {REGISTERED_CITIZENS_DATA.map((c) => (
                <option key={c.phone} value={c.phone}>
                  {c.phone} — {c.name} ({c.address.split(',')[0]})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Matched Citizen UPMS Context Tag */}
        {activeCitizen && (
          <div className="hidden lg:flex items-center gap-1.5 text-[11px] text-emerald-900 bg-emerald-100/70 border border-emerald-300 px-2 py-0.5 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
            <span>UPMS ম্যাচ: <strong>{activeCitizen.name}</strong></span>
            {activeCitizen.lastApplication && (
              <span className="text-emerald-700">| শেষ সেবা: {activeCitizen.lastApplication}</span>
            )}
          </div>
        )}
      </div>

      {/* Visual 7-Stage Step Indicator for Automated Enquiry Flow */}
      {(flowchartState.active || flowchartState.step === 'completed' || selectedChannel === 'whatsapp') && (
        <div className="px-3 sm:px-4 pt-3 pb-1 shrink-0 bg-slate-100/60 border-b border-slate-200">
          <FlowStepIndicator
            currentStep={flowchartState.step}
            stepNumber={flowchartState.stepNumber || 1}
            isActive={flowchartState.active}
            capturedData={{
              q1_name: flowchartState.q1_name || flowchartState.citizenName,
              q2_mobile: flowchartState.q2_mobile || flowchartState.mobile,
              q3_previous_contact: flowchartState.q3_previous_contact,
              q4_service: flowchartState.q4_service,
              q5_purpose: flowchartState.q5_purpose,
              q6_documents_time: flowchartState.q6_documents_time,
              q7_prior_submission: flowchartState.q7_prior_submission
            }}
            generatedReportNumber={flowchartState.reportNumber}
            onStartFlow={startWhatsAppFlow}
            onRestart={startWhatsAppFlow}
            onCancel={() => setFlowchartState(prev => ({ ...prev, active: false, step: 'completed' }))}
          />
        </div>
      )}

      {/* Messages Thread Container */}
      <div className="flex-1 overflow-y-auto p-3.5 sm:p-4 space-y-4 bg-slate-50/50">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-2.5 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              {/* Avatar */}
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-xs ${
                  isUser
                    ? 'bg-blue-600 text-white'
                    : 'bg-emerald-600 text-white shadow-sm'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div className={`max-w-[88%] sm:max-w-[80%] space-y-2`}>
                <div
                  className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-sm relative group ${
                    isUser
                      ? 'bg-blue-600 text-white rounded-tr-none'
                      : msg.isError
                      ? 'bg-red-50 text-red-900 border border-red-200 rounded-tl-none'
                      : 'bg-white text-slate-800 border border-slate-200/90 rounded-tl-none'
                  }`}
                >
                  {/* AI Metadata Tags Header if available */}
                  {!isUser && (msg.intent || msg.category) && (
                    <div className="flex flex-wrap items-center gap-1.5 mb-2.5 pb-2 border-b border-slate-100 text-[10px]">
                      {msg.intent && (
                        <span className={`px-2 py-0.5 rounded font-semibold ${
                          msg.intent === 'complaint' 
                            ? 'bg-red-100 text-red-800 border border-red-200'
                            : msg.intent === 'suggestion'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : (msg.intent === 'statuscheck' || msg.intent === 'status_check')
                            ? 'bg-blue-100 text-blue-800 border border-blue-200'
                            : (msg.intent === 'servicequery' || msg.intent === 'generalquery' || msg.intent === 'general_query')
                            ? 'bg-indigo-100 text-indigo-800 border border-indigo-200'
                            : msg.intent === 'contactrequest'
                            ? 'bg-amber-100 text-amber-800 border border-amber-200'
                            : 'bg-slate-100 text-slate-700 border border-slate-200'
                        }`}>
                          {msg.intent === 'complaint' && '📋 অভিযোগ (Complaint)'}
                          {msg.intent === 'suggestion' && '💡 পরামর্শ (Suggestion)'}
                          {(msg.intent === 'statuscheck' || msg.intent === 'status_check') && '🔍 স্ট্যাটাস চেক (Status Check)'}
                          {(msg.intent === 'servicequery' || msg.intent === 'generalquery' || msg.intent === 'general_query') && 'ℹ️ সেবা তথ্য (Service Query)'}
                          {msg.intent === 'contactrequest' && '📞 যোগাযোগ (Contact Request)'}
                          {msg.intent === 'other' && '❓ অন্যান্য (Other)'}
                        </span>
                      )}

                      {msg.category && msg.category !== 'none' && (
                        <span className="px-2 py-0.5 rounded bg-teal-50 text-teal-800 border border-teal-200 font-medium">
                          {msg.category}
                        </span>
                      )}

                      {typeof msg.confidence_score === 'number' && (
                        <span className={`px-1.5 py-0.5 rounded font-mono ${
                          msg.confidence_score >= 0.6
                            ? 'bg-slate-100 text-slate-600'
                            : 'bg-amber-100 text-amber-800 font-bold'
                        }`}>
                          কনফিডেন্স: {(msg.confidence_score * 100).toFixed(0)}%
                        </span>
                      )}
                    </div>
                  )}

                  {/* Message formatted content */}
                  <div className="whitespace-pre-line space-y-1">
                    {msg.content.split('\n').map((line, idx) => {
                      if (line.startsWith('**') && line.endsWith('**')) {
                        return (
                          <div key={idx} className="font-bold text-slate-900 my-1">
                            {line.replace(/\*\*/g, '')}
                          </div>
                        );
                      }
                      if (line.includes('**')) {
                        const parts = line.split('**');
                        return (
                          <div key={idx} className="my-0.5">
                            {parts.map((p, i) => (i % 2 === 1 ? <strong key={i} className="font-semibold text-slate-950">{p}</strong> : p))}
                          </div>
                        );
                      }
                      return <div key={idx}>{line}</div>;
                    })}
                  </div>

                  {/* Registered Ticket Notification Card */}
                  {!isUser && msg.ticket_id && (
                    <div className="mt-3 p-3 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-300 rounded-xl text-xs text-emerald-950 shadow-2xs">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5 font-bold text-emerald-900">
                          <Ticket className="w-4 h-4 text-emerald-700" />
                          <span>টিকেট আইডি: {msg.ticket_id}</span>
                        </div>
                        <span className="bg-emerald-600 text-white text-[10px] px-2 py-0.5 rounded-full font-medium">
                          স্ট্যাটাস: গৃহীত
                        </span>
                      </div>
                      <p className="text-[11px] text-emerald-800 mt-1">
                        আপনার বিষয়টি ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ সিস্টেমে রেকর্ড করা হয়েছে। ট্র্যাকিং করতে টিকেট আইডি সংরক্ষণ করুন।
                      </p>
                      <div className="mt-2 pt-1.5 border-t border-emerald-200/80 flex items-center justify-between">
                        <button
                          onClick={() => setIsTicketModalOpen(true)}
                          className="text-[11px] font-semibold text-emerald-800 hover:underline flex items-center gap-1"
                        >
                          <span>টিকেট ট্র্যাকার ওপেন করুন</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleCopy(msg.ticket_id!, msg.ticket_id!)}
                          className="text-[11px] text-emerald-800 hover:text-emerald-950 flex items-center gap-1 font-medium bg-white px-2 py-0.5 rounded border border-emerald-300"
                        >
                          <Copy className="w-3 h-3" />
                          <span>আইডি কপি</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Escalation Queue Alert */}
                  {!isUser && msg.needs_escalation && (
                    <div className="mt-2.5 p-2 bg-amber-50 border border-amber-300 rounded-lg text-[11px] text-amber-900 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>
                        সঠিকতা নিশ্চিত করতে বার্তাটি ইউনিয়ন পরিষদ স্টাফ এসকেলেশন কিউতে পাঠানো হয়েছে।
                      </span>
                    </div>
                  )}

                  {/* Actions under AI Bubble */}
                  {!isUser && (
                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                      <span>০২নং বহেড়াতৈল ইউনিয়ন পরিষদ সহকারী</span>
                      <button
                        onClick={() => handleCopy(msg.id, msg.content)}
                        className="hover:text-slate-700 flex items-center gap-1 p-1 rounded"
                        title="উত্তর কপি করুন"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span className="text-emerald-600 font-medium">কপি হয়েছে</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>কপি</span>
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>

                {/* Suggested Questions Pills if present */}
                {msg.suggestedQuestions && msg.suggestedQuestions.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {msg.suggestedQuestions.map((q, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleSendMessage(q)}
                        className="text-[11px] bg-white hover:bg-emerald-50 text-slate-700 hover:text-emerald-800 border border-slate-200 hover:border-emerald-300 px-2.5 py-1 rounded-full shadow-2xs transition-all flex items-center gap-1 text-left"
                      >
                        <span>{q}</span>
                        <ChevronRight className="w-3 h-3 text-slate-400" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4" />
            </div>
            <div className="p-3 bg-white rounded-2xl rounded-tl-none border border-slate-200 shadow-sm flex items-center gap-2 text-xs text-slate-500">
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-bounce"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-bounce [animation-delay:0.4s]"></span>
              </div>
              <span>তথ্য যাচাই ও বিশ্লেষণ হচ্ছে...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Box Footer */}
      <div className="p-3 sm:p-4 bg-white border-t border-slate-200">
        {/* Speech Error Banner */}
        {speechError && (
          <div className="mb-2 px-3 py-1.5 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-700 flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
              <span>{speechError}</span>
            </div>
            <button
              type="button"
              onClick={() => setSpeechError(null)}
              className="text-rose-500 hover:text-rose-700 text-xs font-bold ml-2"
            >
              ✕
            </button>
          </div>
        )}

        {/* Listening Active Live Indicator */}
        {isListening && (
          <div className="mb-2 px-3 py-1.5 bg-emerald-50 border border-emerald-300 rounded-lg text-xs text-emerald-900 flex items-center justify-between animate-pulse shadow-2xs">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-600"></span>
              </span>
              <span className="font-semibold">
                মাইক্রোফোন সক্রিয় — পরিষ্কারভাবে আপনার প্রশ্ন বা অভিযোগ বলুন...
              </span>
            </div>
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              className="text-[11px] bg-red-100 hover:bg-red-200 text-red-700 px-2 py-0.5 rounded font-medium transition-colors"
            >
              থামান
            </button>
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <div className="relative flex-1 flex items-center">
            <input
              id="ai-chat-input-field"
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder={isListening ? "আপনার কথা স্বয়ংক্রিয়ভাবে টেক্সট হিসেবে উঠছে..." : "আপনার প্রশ্ন বা অভিযোগ লিখুন বা মাইকে বলুন..."}
              className={`w-full pl-4 pr-11 py-2.5 text-xs sm:text-sm bg-slate-50 border ${isListening ? 'border-emerald-500 ring-2 ring-emerald-400/40 bg-emerald-50/20' : 'border-slate-300'} rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent text-slate-800 placeholder-slate-400 transition-all`}
              disabled={isLoading}
            />

            {/* Web Speech Microphone Button */}
            <button
              id="ai-chat-mic-btn"
              type="button"
              onClick={toggleSpeechRecognition}
              disabled={isLoading}
              title={isListening ? "ভয়েস রেকর্ডিং বন্ধ করুন" : "মুখে বলে প্রশ্ন করুন (Web Speech API)"}
              className={`absolute right-2 p-1.5 rounded-lg transition-all flex items-center justify-center ${
                isListening
                  ? 'bg-red-600 text-white shadow-sm ring-2 ring-red-300 animate-pulse'
                  : 'text-slate-500 hover:text-emerald-700 hover:bg-emerald-50'
              }`}
            >
              {isListening ? (
                <MicOff className="w-4 h-4" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>
          </div>

          <button
            id="ai-chat-send-btn"
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-medium text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-sm transition-all shrink-0"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">পাঠান</span>
          </button>
        </form>

        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
          <span>০২নং বহেড়াতৈল ইউনিয়ন পরিষদ হেল্পডেস্ক</span>
          <span>সরাসরি যোগাযোগ: {operator.phone}</span>
        </div>
      </div>
    </div>
  );
};
