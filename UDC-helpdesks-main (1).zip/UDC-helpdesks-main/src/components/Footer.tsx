import React from 'react';
import { Shield, Phone, MessageCircle, Mail, Globe, Heart, Building2 } from 'lucide-react';
import { OperatorProfile } from '../types';

interface FooterProps {
  operator: OperatorProfile;
}

export const Footer: React.FC<FooterProps> = ({ operator }) => {
  return (
    <footer className="bg-[#09172a] text-slate-300 border-t border-slate-800 pt-10 pb-8 px-4 mt-12 text-xs">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Main Brand & Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
          
          {/* Identity */}
          <div className="space-y-2">
            <div className="flex items-center justify-center md:justify-start gap-2 text-white">
              <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-slate-950 font-bold">
                <Shield className="w-4 h-4" />
              </div>
              <h4 className="font-bold text-sm text-white">
                ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্ক
              </h4>
            </div>
            <p className="text-slate-400 leading-relaxed">
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ<br />
              উপজেলা: সখিপুর, জেলা: টাঙ্গাইল, বাংলাদেশ।
            </p>
            <p className="text-emerald-400 font-medium italic pt-1">
              “আপনার সেবায় প্রযুক্তির ছোঁয়া — ডিজিটাল ইউনিয়ন পরিষদ 🏛️”
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <h5 className="font-bold text-white text-xs uppercase tracking-wider">
              ডিজিটাল সেবা সমূহ
            </h5>
            <ul className="space-y-1.5 text-slate-400">
              <li>• নতুন ও সংশোধিত জন্ম নিবন্ধন</li>
              <li>• নাগরিক ও চারিত্রিক সনদপত্র</li>
              <li>• অবিবাহিত ও ওয়ারিশ সনদ</li>
              <li>• সামাজিক নিরাপত্তা ও ভাতা আবেদন</li>
              <li>• সরকারি ফি ও অনলাইন ট্র্যাকিং</li>
            </ul>
          </div>

          {/* Helpdesk Contacts */}
          <div className="space-y-2.5">
            <h5 className="font-bold text-white text-xs uppercase tracking-wider">
              হেল্পডেস্ক যোগাযোগ
            </h5>
            <p className="text-slate-400">
              অপারেটর: <strong className="text-slate-200">{operator.name}</strong>
            </p>

            <div className="space-y-1.5">
              <a
                href={operator.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center md:justify-start gap-1.5 text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span>WhatsApp চ্যাট লিংক</span>
              </a>

              <a
                href={`sms:${operator.phone}`}
                className="flex items-center justify-center md:justify-start gap-1.5 text-slate-300 hover:text-white transition-colors"
              >
                <Phone className="w-4 h-4 text-blue-400" />
                <span>SMS/মোবাইল: {operator.phone}</span>
              </a>

              <a
                href={`mailto:${operator.email}`}
                className="flex items-center justify-center md:justify-start gap-1.5 text-slate-300 hover:text-white transition-colors"
              >
                <Mail className="w-4 h-4 text-red-400" />
                <span>Gmail: {operator.email}</span>
              </a>

              <a
                href={operator.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center md:justify-start gap-1.5 text-slate-300 hover:text-white transition-colors"
              >
                <Globe className="w-4 h-4 text-blue-500" />
                <span>Facebook প্রোফাইল</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-500 text-[11px] text-center">
          <p>© {new Date().getFullYear()} ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ। সর্বস্বত্ব সংরক্ষিত।</p>
          <p className="flex items-center gap-1 justify-center">
            <span>ডিজিটাল বাংলাদেশ ভিশন বাস্তবায়নে নিবেদিতপ্রাণ</span>
          </p>
        </div>
      </div>
    </footer>
  );
};
