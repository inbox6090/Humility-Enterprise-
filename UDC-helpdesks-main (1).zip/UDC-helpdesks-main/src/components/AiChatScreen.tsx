import React from 'react';
import { AiChatView } from './AiChatView';
import { ServiceItem, OperatorProfile } from '../types';

interface AiChatScreenProps {
  operator: OperatorProfile;
  serviceContext?: ServiceItem | null;
  initialQuery?: string | null;
  onClearServiceContext?: () => void;
  onBackToHome: () => void;
}

export const AiChatScreen: React.FC<AiChatScreenProps> = ({
  operator,
  serviceContext,
  initialQuery,
  onClearServiceContext,
  onBackToHome,
}) => {
  return (
    <div className="space-y-4">
      <AiChatView
        operator={operator}
        initialServiceContext={serviceContext}
        initialQuery={initialQuery}
        onClearServiceContext={onClearServiceContext}
        onBackToHome={onBackToHome}
      />
    </div>
  );
};

export { FlowStepIndicator } from './FlowStepIndicator';
export type { FlowStepIndicatorProps, CapturedFlowData, StageDefinition } from './FlowStepIndicator';
