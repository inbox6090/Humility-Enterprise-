import React from 'react';
import { 
  X, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Banknote, 
  Building, 
  ArrowRight,
  MessageCircle,
  FileCheck
} from 'lucide-react';
import { ServiceItem, OperatorProfile } from '../types';

interface ServiceDetailModalProps {
  service: ServiceItem | null;
  operator: OperatorProfile;
  onClose: () => void;
  onAskAi: (service: ServiceItem, specificQuery?: string) => void;
}

export const ServiceDetailModal: React.FC<ServiceDetailModalProps> = ({
  service,
  operator,
  onClose,
  onAskAi
}) => {
  if (!service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div 
        id="service-detail-modal-box"
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 flex flex-col"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#0c1e36] to-[#16355d] text-white flex items-center justify-between sticky top-0 z-10 border-b border-slate-700">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ
              </span>
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-white leading-tight">
              {service.name}
            </h3>
          </div>
          <button
            id="close-service-modal-btn"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-5 text-slate-700 text-sm">
          {/* Summary Box */}
          <div className="p-3.5 rounded-xl bg-blue-50/80 border border-blue-100 text-blue-950 leading-relaxed">
            <p className="font-medium text-xs sm:text-sm">{service.shortDescription}</p>
          </div>

          {/* Quick Specs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 flex items-center gap-1 mb-1">
                <Banknote className="w-3.5 h-3.5 text-emerald-600" /> সরকারি ফি
              </span>
              <p className="text-xs font-semibold text-slate-800">{service.fee}</p>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 flex items-center gap-1 mb-1">
                <Clock className="w-3.5 h-3.5 text-blue-600" /> সম্ভাব্য সময়
              </span>
              <p className="text-xs font-semibold text-slate-800">{service.processingTime}</p>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 flex items-center gap-1 mb-1">
                <Building className="w-3.5 h-3.5 text-indigo-600" /> কাউন্টার / দায়িত্ব
              </span>
              <p className="text-xs font-semibold text-slate-800">{service.counter}</p>
            </div>
          </div>

          {/* Required Documents */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-2.5">
              <FileCheck className="w-4 h-4 text-emerald-600" />
              প্রয়োজনীয় কাগজপত্র (Required Documents)
            </h4>
            <ul className="space-y-2 bg-slate-50/60 p-3.5 rounded-xl border border-slate-200/80">
              {service.requiredDocuments.map((doc, i) => (
                <li key={i} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{doc}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Application Steps */}
          <div>
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2 mb-2.5">
              <ArrowRight className="w-4 h-4 text-blue-600" />
              আবেদন পদ্ধতি ও ধাপসমূহ (Step-by-step Process)
            </h4>
            <div className="space-y-2">
              {service.applicationProcess.map((step, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                  <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 font-bold flex items-center justify-center text-xs shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <p className="flex-1">{step}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Common Mistakes */}
          {service.commonMistakes.length > 0 && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs sm:text-sm">
              <h5 className="font-bold flex items-center gap-1.5 text-amber-800 mb-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                যেসব সাধারণ ভুল এড়ানো উচিত
              </h5>
              <ul className="list-disc list-inside space-y-1 text-slate-700">
                {service.commonMistakes.map((mistake, i) => (
                  <li key={i}>{mistake}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Important Notes */}
          {service.importantNotes.length > 0 && (
            <div className="p-3 rounded-xl bg-slate-100 border border-slate-200 text-xs text-slate-700 space-y-1">
              <span className="font-bold text-slate-800 block">গুরুত্বপূর্ণ নির্দেশনা:</span>
              {service.importantNotes.map((note, i) => (
                <p key={i}>• {note}</p>
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 sticky bottom-0">
          <a
            id="modal-whatsapp-contact-link"
            href={operator.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp-এ লিখুন</span>
          </a>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              id="modal-close-action-btn"
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl border border-slate-300 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors"
            >
              বন্ধ করুন
            </button>
            <button
              id="modal-ask-ai-service-btn"
              onClick={() => {
                onClose();
                onAskAi(service);
              }}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-all"
            >
              <Sparkles className="w-4 h-4" />
              <span>AI সহকারীকে প্রশ্ন করুন</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
