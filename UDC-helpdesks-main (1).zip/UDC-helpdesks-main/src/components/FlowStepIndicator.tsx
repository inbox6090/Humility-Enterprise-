import React, { useState } from 'react';
import { 
  User, 
  Phone, 
  History, 
  FileText, 
  Target, 
  FolderCheck, 
  Send, 
  Check, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  RotateCcw, 
  X, 
  MessageCircle,
  ShieldAlert
} from 'lucide-react';

export interface CapturedFlowData {
  q1_name?: string;
  q2_mobile?: string;
  q3_previous_contact?: string;
  q4_service?: string;
  q5_purpose?: string;
  q6_documents_time?: string;
  q7_prior_submission?: string;
}

export interface FlowStepIndicatorProps {
  currentStep: 'q1_name' | 'q2_mobile' | 'q3_previous_contact' | 'q4_service' | 'q5_purpose' | 'q6_documents_time' | 'q7_prior_submission' | 'completed' | string;
  stepNumber: number; // 1 to 7, or 8 when completed
  isActive: boolean;
  capturedData?: CapturedFlowData;
  generatedReportNumber?: string;
  onCancel?: () => void;
  onRestart?: () => void;
  onStartFlow?: () => void;
  className?: string;
}

export interface StageDefinition {
  step: number;
  key: keyof CapturedFlowData;
  stepId: string;
  titleBn: string;
  titleEn: string;
  shortDesc: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const ENQUIRY_STAGES: StageDefinition[] = [
  {
    step: 1,
    key: 'q1_name',
    stepId: 'q1_name',
    titleBn: 'নাম',
    titleEn: 'Name',
    shortDesc: 'নাগরিকের শুভ নাম',
    icon: User
  },
  {
    step: 2,
    key: 'q2_mobile',
    stepId: 'q2_mobile',
    titleBn: 'মোবাইল',
    titleEn: 'Mobile',
    shortDesc: 'WhatsApp / ফোন',
    icon: Phone
  },
  {
    step: 3,
    key: 'q3_previous_contact',
    stepId: 'q3_previous_contact',
    titleBn: 'ইতিহাস',
    titleEn: 'History',
    shortDesc: 'পূর্বে যোগাযোগ?',
    icon: History
  },
  {
    step: 4,
    key: 'q4_service',
    stepId: 'q4_service',
    titleBn: 'সেবা',
    titleEn: 'Service',
    shortDesc: 'কাঙ্ক্ষিত সেবা বাছাই',
    icon: FileText
  },
  {
    step: 5,
    key: 'q5_purpose',
    stepId: 'q5_purpose',
    titleBn: 'উদ্দেশ্য',
    titleEn: 'Purpose',
    shortDesc: 'আবেদন / সংশোধন',
    icon: Target
  },
  {
    step: 6,
    key: 'q6_documents_time',
    stepId: 'q6_documents_time',
    titleBn: 'কাগজপত্র ও সময়',
    titleEn: 'Docs & Time',
    shortDesc: 'কাগজ প্রস্তুতি ও সময়সীমা',
    icon: FolderCheck
  },
  {
    step: 7,
    key: 'q7_prior_submission',
    stepId: 'q7_prior_submission',
    titleBn: 'পূর্বের কাজ',
    titleEn: 'Prior Work',
    shortDesc: 'পূর্বে জমাকৃত আবেদন',
    icon: Send
  }
];

export const FlowStepIndicator: React.FC<FlowStepIndicatorProps> = ({
  currentStep,
  stepNumber = 1,
  isActive,
  capturedData = {},
  generatedReportNumber,
  onCancel,
  onRestart,
  onStartFlow,
  className = ''
}) => {
  const [isMobileExpanded, setIsMobileExpanded] = useState<boolean>(false);

  // Map step number to 1-7 (or 8 for completed)
  const activeStepNum = currentStep === 'completed' ? 8 : (stepNumber || 1);
  const isCompleted = currentStep === 'completed' || activeStepNum > 7;
  const progressPercent = Math.min(100, Math.round(((Math.max(1, activeStepNum) - 1) / 7) * 100));

  // If the flow is NOT active and not just completed, show a compact banner to start enquiry
  if (!isActive && !isCompleted) {
    return (
      <div className={`bg-white border border-emerald-200/80 rounded-xl p-3.5 shadow-xs transition-all ${className}`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
              <MessageCircle className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-xs sm:text-sm text-slate-800">
                  ৭-ধাপ বিশিষ্ট স্বয়ংক্রিয় সেবা অনুসন্ধান (Automated Enquiry Flow)
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-medium bg-emerald-100 text-emerald-800 rounded">
                  Q1–Q7
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-0.5">
                নাম ➔ মোবাইল ➔ ইতিহাস ➔ সেবা ➔ উদ্দেশ্য ➔ কাগজপত্র ➔ পূর্বের কাজ ➔ অফিসিয়াল রিপোর্ট
              </p>
            </div>
          </div>

          {onStartFlow && (
            <button
              id="start-enquiry-flow-btn"
              onClick={onStartFlow}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-lg shadow-xs transition-all whitespace-nowrap"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-200" />
              <span>ফ্লো শুরু করুন</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  // Active or Completed Step View
  const currentStage = ENQUIRY_STAGES.find((s) => s.step === activeStepNum) || ENQUIRY_STAGES[0];

  return (
    <div
      id="automated-flow-step-indicator"
      className={`bg-white border border-emerald-200 rounded-xl shadow-xs overflow-hidden transition-all ${className}`}
    >
      {/* Top Status Header */}
      <div className="px-4 py-2.5 bg-gradient-to-r from-[#0c1e36] via-[#11294a] to-[#0c1e36] text-white flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="relative flex h-2.5 w-2.5">
            {!isCompleted ? (
              <>
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </>
            ) : (
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400"></span>
            )}
          </span>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-emerald-200 uppercase tracking-wide">
              {isCompleted ? 'অনবোর্ডিং সম্পন্ন' : 'স্বয়ংক্রিয় অনবোর্ডিং ফ্লো'}
            </span>
            <span className="text-slate-400 text-xs hidden sm:inline">•</span>
            <span className="text-xs font-mono text-slate-200">
              {isCompleted ? (
                <span className="text-emerald-300 font-semibold flex items-center gap-1">
                  <Check className="w-3 h-3 text-emerald-400" /> ৭/৭ ধাপ সম্পন্ন
                </span>
              ) : (
                `ধাপ ${activeStepNum}/৭: ${currentStage.titleBn} (${currentStage.titleEn})`
              )}
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5">
          {generatedReportNumber && (
            <span className="px-2 py-0.5 bg-amber-400/20 text-amber-300 border border-amber-400/40 rounded text-[11px] font-mono font-bold">
              রিপোর্ট #{generatedReportNumber}
            </span>
          )}

          {/* Mobile Collapse Toggle */}
          <button
            onClick={() => setIsMobileExpanded(!isMobileExpanded)}
            className="sm:hidden p-1 text-slate-300 hover:text-white rounded hover:bg-white/10 text-xs flex items-center gap-0.5"
            title={isMobileExpanded ? 'সংক্ষেপ করুন' : 'সব ধাপ দেখুন'}
          >
            <span className="text-[11px]">{isMobileExpanded ? 'সংক্ষেপ' : 'বিস্তারিত'}</span>
            {isMobileExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>

          {/* Restart Flow */}
          {onRestart && (
            <button
              onClick={onRestart}
              className="p-1 text-slate-300 hover:text-white rounded hover:bg-white/10"
              title="নতুন করে শুরু করুন"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Cancel Flow */}
          {onCancel && (
            <button
              onClick={onCancel}
              className="p-1 text-slate-300 hover:text-red-300 rounded hover:bg-red-500/20"
              title="ফ্লো বন্ধ করুন"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Progress Bar Track */}
      <div className="w-full bg-slate-100 h-1.5 relative overflow-hidden">
        <div
          className={`h-full transition-all duration-500 ease-out ${
            isCompleted
              ? 'bg-emerald-500 w-full'
              : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600'
          }`}
          style={{ width: `${isCompleted ? 100 : Math.max(8, progressPercent)}%` }}
        />
      </div>

      {/* Main 7 Stages Visualization - Responsive Grid / Flex */}
      <div className={`p-3.5 sm:p-4 bg-slate-50/70 ${isMobileExpanded ? 'block' : 'hidden sm:block'}`}>
        <div className="relative">
          {/* Connecting Line (Desktop) */}
          <div
            className="hidden sm:block absolute top-5 left-6 right-6 h-0.5 bg-slate-200 -z-0"
            style={{ top: '20px' }}
          >
            <div
              className="h-full bg-emerald-500 transition-all duration-500"
              style={{
                width: isCompleted
                  ? '100%'
                  : `${Math.max(0, ((activeStepNum - 1) / 6) * 100)}%`
              }}
            />
          </div>

          {/* 7 Stage Nodes */}
          <div className="grid grid-cols-1 sm:grid-cols-7 gap-2 sm:gap-1 relative z-10">
            {ENQUIRY_STAGES.map((stage) => {
              const Icon = stage.icon;
              const isPast = isCompleted || stage.step < activeStepNum;
              const isCurrent = !isCompleted && stage.step === activeStepNum;
              const isFuture = !isCompleted && stage.step > activeStepNum;
              const capturedVal = capturedData[stage.key];

              return (
                <div
                  key={stage.stepId}
                  className={`flex sm:flex-col items-center sm:items-center text-left sm:text-center p-2 sm:p-1 rounded-lg transition-all ${
                    isCurrent
                      ? 'bg-emerald-50/90 sm:bg-transparent border border-emerald-300 sm:border-transparent shadow-xs sm:shadow-none'
                      : isPast
                      ? 'opacity-95'
                      : 'opacity-60'
                  }`}
                >
                  {/* Step Node Icon / Circle */}
                  <div className="relative shrink-0 mr-3 sm:mr-0 sm:mb-1.5">
                    <div
                      className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-semibold text-xs transition-all ${
                        isPast
                          ? 'bg-emerald-600 text-white shadow-xs border-2 border-emerald-500'
                          : isCurrent
                          ? 'bg-emerald-600 text-white ring-4 ring-emerald-200 border-2 border-emerald-700 shadow-md scale-105 animate-pulse'
                          : 'bg-white text-slate-400 border-2 border-slate-300'
                      }`}
                    >
                      {isPast ? (
                        <Check className="w-4 h-4 sm:w-5 sm:h-5 text-white stroke-[2.5]" />
                      ) : (
                        <Icon className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                      )}
                    </div>

                    {/* Step Number Badge */}
                    <span
                      className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full text-[10px] font-mono flex items-center justify-center font-bold ${
                        isPast
                          ? 'bg-emerald-800 text-emerald-100'
                          : isCurrent
                          ? 'bg-emerald-700 text-white'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {stage.step}
                    </span>
                  </div>

                  {/* Stage Text & Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center sm:justify-center gap-1.5">
                      <span
                        className={`text-xs font-bold leading-tight truncate ${
                          isCurrent
                            ? 'text-emerald-900 font-extrabold'
                            : isPast
                            ? 'text-slate-800'
                            : 'text-slate-500'
                        }`}
                      >
                        {stage.titleBn}
                      </span>
                    </div>

                    <div className="text-[10px] text-slate-400 leading-tight hidden sm:block truncate">
                      {stage.titleEn}
                    </div>

                    {/* Captured Data Pill (if available) */}
                    {capturedVal ? (
                      <div
                        className="mt-1 inline-block max-w-full px-1.5 py-0.5 bg-emerald-100/90 text-emerald-900 border border-emerald-200 rounded text-[10px] font-medium truncate"
                        title={capturedVal}
                      >
                        {capturedVal}
                      </div>
                    ) : isCurrent ? (
                      <div className="mt-1 inline-block px-1.5 py-0.5 bg-emerald-600 text-white rounded text-[10px] font-semibold animate-pulse">
                        চলমান
                      </div>
                    ) : (
                      <div className="mt-1 text-[10px] text-slate-400 sm:block hidden truncate">
                        {stage.shortDesc}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Completed State Banner */}
        {isCompleted && (
          <div className="mt-3 p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-xs text-emerald-900">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                <strong>৭টি ধাপ সম্পূর্ণ হয়েছে!</strong> আপনার ইউনিক রিপোর্ট নম্বর তৈরি হয়েছে এবং নিচে বিস্তারিত সরকারি গাইড প্রদান করা হয়েছে।
              </span>
            </div>
            {onRestart && (
              <button
                onClick={onRestart}
                className="px-2 py-1 text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 bg-white border border-emerald-300 rounded shadow-2xs hover:bg-emerald-50 transition-all shrink-0 ml-2"
              >
                নতুন অনুসন্ধান
              </button>
            )}
          </div>
        )}
      </div>

      {/* Mobile Compact Bar (When Collapsed) */}
      {!isMobileExpanded && (
        <div className="sm:hidden px-3.5 py-2 bg-slate-50 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-[11px] shrink-0">
              {isCompleted ? <Check className="w-3.5 h-3.5" /> : activeStepNum}
            </span>
            <div className="min-w-0 truncate">
              <span className="font-bold text-slate-800">
                {isCompleted ? '৭টি ধাপ সম্পন্ন' : `${currentStage.titleBn} (${currentStage.titleEn})`}
              </span>
              <span className="text-[11px] text-slate-500 block truncate">
                {isCompleted ? 'রিপোর্ট ও গাইড প্রস্তুত' : currentStage.shortDesc}
              </span>
            </div>
          </div>

          {/* Mini Step Dots */}
          <div className="flex items-center gap-1 shrink-0 ml-2">
            {ENQUIRY_STAGES.map((s) => (
              <span
                key={s.step}
                className={`w-2 h-2 rounded-full transition-all ${
                  isCompleted || s.step < activeStepNum
                    ? 'bg-emerald-600'
                    : s.step === activeStepNum
                    ? 'bg-emerald-500 scale-125 ring-2 ring-emerald-200'
                    : 'bg-slate-300'
                }`}
                title={`ধাপ ${s.step}: ${s.titleBn}`}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
