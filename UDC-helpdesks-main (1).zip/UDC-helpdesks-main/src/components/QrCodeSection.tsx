import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { 
  QrCode, 
  Download, 
  Share2, 
  Copy, 
  Check, 
  MessageCircle, 
  Globe, 
  Smartphone,
  ExternalLink
} from 'lucide-react';

interface QrCodeSectionProps {
  appUrl?: string;
}

export const QrCodeSection: React.FC<QrCodeSectionProps> = ({ appUrl }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [currentUrl, setCurrentUrl] = useState<string>(appUrl || '');
  const [copied, setCopied] = useState<boolean>(false);
  const [showQrModal, setShowQrModal] = useState<boolean>(false);

  useEffect(() => {
    const url = appUrl || window.location.href;
    setCurrentUrl(url);

    if (canvasRef.current) {
      QRCode.toCanvas(
        canvasRef.current,
        url,
        {
          width: 220,
          margin: 2,
          color: {
            dark: '#0c1e36',
            light: '#ffffff'
          }
        },
        (error) => {
          if (error) console.error('QR code generation error:', error);
        }
      );
    }
  }, [appUrl]);

  // Download QR Code Image as PNG
  const handleDownloadQr = () => {
    if (!canvasRef.current) return;
    
    // Create a larger canvas with branding for printing
    const printCanvas = document.createElement('canvas');
    printCanvas.width = 600;
    printCanvas.height = 750;
    const ctx = printCanvas.getContext('2d');
    if (!ctx) return;

    // White background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 600, 750);

    // Header Navy Bar
    ctx.fillStyle = '#0c1e36';
    ctx.fillRect(0, 0, 600, 130);

    // Text header
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('০২নং বহেড়াতৈল ইউনিয়ন পরিষদ', 300, 50);

    ctx.font = 'normal 18px sans-serif';
    ctx.fillStyle = '#34d399';
    ctx.fillText('ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্ক', 300, 85);

    ctx.font = 'normal 14px sans-serif';
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText('সখিপুর, টাঙ্গাইল • ডিজিটাল নাগরিক সেবা', 300, 112);

    // Subtitle
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 20px sans-serif';
    ctx.fillText('যেকোনো মোবাইল থেকে স্ক্যান করুন', 300, 175);

    // Draw QR Code
    ctx.drawImage(canvasRef.current, 100, 200, 400, 400);

    // Footer info
    ctx.fillStyle = '#475569';
    ctx.font = 'normal 15px sans-serif';
    ctx.fillText('AI সহকারী • WhatsApp চ্যাট • সেবা নির্দেশিকা', 300, 640);

    ctx.fillStyle = '#059669';
    ctx.font = 'bold 16px sans-serif';
    ctx.fillText('মোবাইল / WhatsApp: +8801834333300', 300, 675);

    ctx.fillStyle = '#94a3b8';
    ctx.font = 'italic 13px sans-serif';
    ctx.fillText('“আপনার সেবায় প্রযুক্তির ছোঁয়া — ডিজিটাল ইউনিয়ন পরিষদ”', 300, 715);

    const image = printCanvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = image;
    link.download = 'baheratail-union-parishad-helpdesk-qr.png';
    link.click();
  };

  // Share functionality with Web Share API and fallbacks
  const handleNativeShare = async () => {
    const shareData = {
      title: 'ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্ক',
      text: '০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল - ডিজিটাল নাগরিক সেবা হেল্পডেস্ক ও AI সহকারী।',
      url: currentUrl
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log('Share canceled or failed', err);
      }
    } else {
      handleCopyLink();
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-md mb-8">
      <div className="max-w-2xl mx-auto space-y-4">
        {/* Title */}
        <div className="text-center space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-semibold border border-emerald-200">
            <QrCode className="w-3.5 h-3.5" />
            <span>QR কোড সংযোগ</span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-800">
            এই সেবাটি অন্যদের সাথে শেয়ার করুন
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 max-w-lg mx-auto">
            “QR Code স্ক্যান করে যেকোনো মোবাইল থেকে Digital Union Parishad Helpdesk-এ প্রবেশ করা যাবে।”
          </p>
        </div>

        {/* QR Code Canvas Card */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 py-3">
          <div className="p-3 bg-white rounded-2xl border-2 border-slate-200 shadow-sm flex flex-col items-center">
            <canvas ref={canvasRef} className="rounded-lg max-w-[200px] h-auto" />
            <span className="text-[11px] text-slate-500 font-mono mt-2 flex items-center gap-1">
              <Smartphone className="w-3 h-3 text-emerald-600" />
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ
            </span>
          </div>

          <div className="space-y-2.5 text-center sm:text-left w-full sm:w-auto">
            <div className="text-xs text-slate-600 space-y-1">
              <p className="font-semibold text-slate-800">ব্যবহার পদ্ধতি:</p>
              <p>১. মোবাইল ক্যামেরা দিয়ে সরাসরি স্ক্যান করুন।</p>
              <p>২. তাৎক্ষণিক হেল্পডেস্ক ওয়েব অ্যাপে প্রবেশ করুন।</p>
              <p>৩. AI সহকারী বা WhatsApp-এ সেবা গ্রহণ করুন।</p>
            </div>

            {/* Main Buttons */}
            <div className="flex flex-col gap-2 pt-2">
              <button
                id="btn-download-qr"
                onClick={handleDownloadQr}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>QR Code Download করুন (PNG)</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  id="btn-view-large-qr"
                  onClick={() => setShowQrModal(true)}
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5 border border-slate-300 transition-colors"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>QR Code দেখুন</span>
                </button>

                <button
                  id="btn-native-share"
                  onClick={handleNativeShare}
                  className="flex-1 px-3 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share করুন</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Fallback Share Channels */}
        <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-center gap-2 text-xs">
          <button
            id="btn-copy-helpdesk-link"
            onClick={handleCopyLink}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium flex items-center gap-1.5 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'লিংক কপি হয়েছে!' : 'লিংক কপি করুন'}</span>
          </button>

          <a
            id="btn-whatsapp-share"
            href={`https://api.whatsapp.com/send?text=${encodeURIComponent(`০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল হেল্পডেস্ক ও AI সহকারী: ${currentUrl}`)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200 font-medium flex items-center gap-1.5 transition-colors"
          >
            <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
            <span>WhatsApp Share</span>
          </a>

          <a
            id="btn-facebook-share"
            href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-800 hover:bg-blue-100 border border-blue-200 font-medium flex items-center gap-1.5 transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-blue-600" />
            <span>Facebook Share</span>
          </a>
        </div>
      </div>

      {/* Large QR Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl border border-slate-200">
            <h4 className="font-bold text-slate-800 text-base">
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ হেল্পডেস্ক QR কোড
            </h4>
            <div className="p-4 bg-white rounded-xl border border-slate-200 inline-block shadow-inner">
              <canvas ref={canvasRef} className="w-56 h-56 mx-auto" />
            </div>
            <p className="text-xs text-slate-500">
              যে কোনো স্মার্টফোন ক্যামেরা দিয়ে স্ক্যান করলেই সরাসরি এই হেল্পডেস্কে প্রবেশ করা যাবে।
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowQrModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold hover:bg-slate-200"
              >
                বন্ধ করুন
              </button>
              <button
                onClick={handleDownloadQr}
                className="flex-1 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>ডাউনলোড</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
