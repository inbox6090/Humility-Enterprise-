import React from 'react';
import { Sparkles, MessageSquare, Info, AlertCircle, Building2 } from 'lucide-react';

interface WelcomeBannerProps {
  onStartChat: () => void;
  whatsappUrl: string;
}

export const WelcomeBanner: React.FC<WelcomeBannerProps> = ({ onStartChat, whatsappUrl }) => {
  return (
    <section className="bg-gradient-to-b from-[#0c1e36] to-[#122b4d] text-white pt-6 pb-7 px-4 rounded-2xl shadow-lg border border-slate-700/60 mb-6">
      <div className="max-w-3xl mx-auto text-center space-y-4">
        
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-medium">
          <Building2 className="w-3.5 h-3.5" />
          <span>০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল</span>
        </div>

        {/* Heading */}
        <div className="space-y-1">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-bold tracking-tight text-white">
            আসসালামু আলাইকুম!
          </h2>
          <p className="text-sm sm:text-base font-semibold text-emerald-300">
            ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্কে আপনাকে স্বাগতম। 🤝
          </p>
          <p className="text-xs sm:text-sm text-slate-300 italic">
            “আপনার সেবায় প্রযুক্তির ছোঁয়া — ডিজিটাল ইউনিয়ন পরিষদ”
          </p>
        </div>

        {/* Official Welcome Message Card */}
        <div className="bg-slate-900/60 backdrop-blur-sm p-4 sm:p-5 rounded-xl border border-slate-700/80 text-left text-xs sm:text-sm leading-relaxed text-slate-200 space-y-2.5">
          <p>
            আমাদের যেকোনো সেবা—যেমন <strong>জন্ম নিবন্ধন</strong>, <strong>নাগরিক সনদ</strong>, <strong>প্রত্যয়নপত্র</strong>, <strong>ভাতার আবেদন</strong> বা আপনার <strong>আবেদনের বর্তমান অবস্থা</strong> সম্পর্কে জানতে আপনার প্রশ্নটি পরিষ্কার করে লিখুন।
          </p>
          <p>
            আমাদের <strong>AI সহকারী</strong> সাধারণ সেবা-সংক্রান্ত তথ্য দিয়ে আপনাকে প্রয়োজনীয় দিকনির্দেশনা দেওয়ার চেষ্টা করবে। প্রয়োজনে সরাসরি <strong>WhatsApp</strong>-এর মাধ্যমে লিখিতভাবে যোগাযোগ করতে পারবেন।
          </p>
          
          <div className="p-2.5 rounded-lg bg-amber-500/15 border border-amber-400/30 text-amber-200 flex items-start gap-2 text-xs">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <p>
              <strong>বিঃদ্রঃ</strong> অনুগ্রহ করে কল বা ভয়েস মেসেজ দেবেন না। লিখিতভাবে যোগাযোগ করলে তথ্য যাচাই ও সেবা প্রদান আরও সহজ ও গতিশীল হবে। সুস্থ ও ভালো থাকুন। 🥰
            </p>
          </div>

          <p className="text-center font-medium text-emerald-300 pt-1 text-xs sm:text-sm">
            “আপনার সেবায় প্রযুক্তির ছোঁয়া — ডিজিটাল ইউনিয়ন পরিষদ। 🏛️”
          </p>
        </div>

        {/* Prompt guidance */}
        <p className="text-xs text-slate-300 max-w-xl mx-auto">
          জন্ম নিবন্ধন, নাগরিক সনদ, প্রত্যয়নপত্র, ভাতা আবেদন অথবা আপনার আবেদনের বর্তমান অবস্থা সম্পর্কে জানতে নিচের অপশন নির্বাচন করুন অথবা AI Assistant-কে প্রশ্ন করুন।
        </p>
      </div>
    </section>
  );
};
