import React, { useState } from 'react';
import { Search, CheckCircle2, Clock, AlertCircle, FileText, MessageCircle, AlertTriangle, ArrowRight } from 'lucide-react';
import { ApplicationStatusResult, OperatorProfile } from '../types';

interface ApplicationStatusSectionProps {
  operator: OperatorProfile;
  onOpenWhatsApp: () => void;
  onAskAiAboutReport?: (reportNo: string) => void;
}

export const ApplicationStatusSection: React.FC<ApplicationStatusSectionProps> = ({
  operator,
  onOpenWhatsApp,
  onAskAiAboutReport
}) => {
  const [reportInput, setReportInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<ApplicationStatusResult | null>(null);

  const handleSearch = async (overrideId?: string) => {
    const id = (overrideId || reportInput).trim();
    if (!id) return;

    setIsLoading(true);
    setResult(null);

    try {
      const response = await fetch(`/api/application-status?reportNo=${encodeURIComponent(id)}`);
      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error(err);
      setResult({
        found: false,
        message: 'সার্ভার সংযোগে ত্রুটি দেখা দিয়েছে। অনুগ্রহ করে হেল্পডেস্কে সরাসরি যোগাযোগ করুন।'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-md mb-8">
      <div className="max-w-2xl mx-auto space-y-4">
        <div className="text-center space-y-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold border border-blue-200">
            <Search className="w-3.5 h-3.5" />
            <span>নাগরিক রিপোর্ট ও সমস্যা ট্র্যাকিং</span>
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-slate-800">
            রিপোর্ট নং দিয়ে সমস্যা ও অগ্রগতি যাচাই
          </h3>
          <p className="text-xs sm:text-sm text-slate-500">
            আপনার প্রদত্ত "রিপোর্ট নং" লিখলে পূর্বের সমস্যা, যোগাযোগের কারণ ও আটকে থাকা ধাপ বিশ্লেষণ করে দিকনির্দেশনা পাওয়া যাবে
          </p>
        </div>

        {/* Input Box */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSearch();
          }}
          className="flex flex-col sm:flex-row gap-2.5 pt-2"
        >
          <div className="relative flex-1">
            <input
              id="report-no-input"
              type="text"
              value={reportInput}
              onChange={(e) => setReportInput(e.target.value)}
              placeholder="আপনার রিপোর্ট নং লিখুন (যেমন: BT-REP-01)..."
              className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent font-medium"
            />
            <FileText className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          </div>

          <button
            id="search-report-status-btn"
            type="submit"
            disabled={!reportInput.trim() || isLoading}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            {isLoading ? (
              <Clock className="w-4 h-4 animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
            <span>রিপোর্ট অনুসন্ধান</span>
          </button>
        </form>

        {/* Quick Demo Report Pills for testing */}
        <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500 pt-1">
          <span className="font-medium">যাচাইযোগ্য স্যাম্পল রিপোর্ট নং:</span>
          {['BT-REP-01', 'BT-REP-02', 'BT-REP-03', 'BT-REP-04'].map((demoNo) => (
            <button
              key={demoNo}
              type="button"
              onClick={() => {
                setReportInput(demoNo);
                handleSearch(demoNo);
              }}
              className="px-2 py-0.5 rounded-md bg-slate-100 hover:bg-blue-100 hover:text-blue-800 text-slate-700 font-mono text-[11px] transition-colors border border-slate-200"
            >
              {demoNo}
            </button>
          ))}
        </div>

        {/* Search Result Card */}
        {result && (
          <div
            id="report-result-box"
            className={`mt-4 p-4 sm:p-5 rounded-xl border text-xs sm:text-sm leading-relaxed transition-all ${
              result.found
                ? 'bg-emerald-50/70 border-emerald-300 text-emerald-950'
                : 'bg-amber-50/70 border-amber-300 text-amber-950'
            }`}
          >
            {result.found ? (
              <div className="space-y-3.5">
                <div className="flex items-center justify-between border-b border-emerald-200 pb-2.5">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{result.applicantName}</h4>
                      <p className="text-xs text-slate-600 font-mono">রিপোর্ট নং: {result.reportNo || result.trackingId}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-600 text-white shadow-2xs">
                    {result.statusText}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-slate-700 bg-white/70 p-3 rounded-lg border border-emerald-100">
                  <p><strong>সংশ্লিষ্ট সেবা:</strong> {result.serviceName}</p>
                  <p><strong>কাউন্টার:</strong> {result.counter}</p>
                  
                  {result.previousIssue && (
                    <div className="sm:col-span-2 pt-1 border-t border-slate-100">
                      <p className="text-amber-900 font-medium flex items-start gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span><strong>পূর্বের সমস্যা:</strong> {result.previousIssue}</span>
                      </p>
                    </div>
                  )}

                  {result.reasonForContact && (
                    <div className="sm:col-span-2">
                      <p className="text-slate-800">
                        <strong>যোগাযোগের কারণ:</strong> {result.reasonForContact}
                      </p>
                    </div>
                  )}

                  {result.stuckStep && (
                    <div className="sm:col-span-2">
                      <p className="text-blue-900">
                        <strong>আটকে থাকা ধাপ:</strong> {result.stuckStep}
                      </p>
                    </div>
                  )}

                  {result.relatedDocuments && result.relatedDocuments.length > 0 && (
                    <div className="sm:col-span-2 pt-1">
                      <strong className="block text-slate-800 mb-1">সম্পর্কিত প্রয়োজনীয় কাগজপত্র:</strong>
                      <ul className="list-disc list-inside space-y-0.5 text-slate-600 pl-1">
                        {result.relatedDocuments.map((doc, i) => (
                          <li key={i}>{doc}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {result.recommendedAction && (
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200 text-blue-950 text-xs font-medium space-y-1">
                    <p className="font-bold text-blue-900">📌 পরবর্তী করণীয় পদক্ষেপ:</p>
                    <p>{result.recommendedAction}</p>
                  </div>
                )}

                {/* Direct Action with AI or WhatsApp */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  {onAskAiAboutReport && (
                    <button
                      type="button"
                      onClick={() => onAskAiAboutReport(result.reportNo || result.trackingId || '')}
                      className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors"
                    >
                      <span>এই রিপোর্ট নিয়ে AI পরামর্শ নিন</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <a
                    href={operator.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-[#25D366] text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs hover:bg-[#20ba59] transition-colors ml-auto"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp-এ যোগাযোগ</span>
                  </a>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-amber-900 text-sm">রিপোর্ট পাওয়া যায়নি</h4>
                    <p className="text-xs text-amber-800 mt-1 font-medium">{result.message}</p>
                  </div>
                </div>

                <div className="pt-2 border-t border-amber-200 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] text-amber-900">
                    আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন:
                  </span>
                  <a
                    href={operator.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-[#25D366] text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs hover:bg-[#20ba59] transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp-এ মেসেজ দিন</span>
                  </a>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

