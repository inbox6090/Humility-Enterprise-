import React, { useState, useEffect } from 'react';
import { 
  Lightbulb, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles,
  Info,
  FileCheck2,
  Clock
} from 'lucide-react';

export interface ServiceTip {
  id: string;
  category: 'all' | 'civil' | 'certificate' | 'social_welfare' | 'general';
  title: string;
  description: string;
  tag: string;
  badgeColor: 'amber' | 'blue' | 'emerald' | 'purple';
  actionPrompt?: string;
}

const DEFAULT_TIPS: ServiceTip[] = [
  {
    id: 'tip-nid-ready',
    category: 'all',
    title: 'আবেদনের পূর্বে NID ও জন্ম নিবন্ধন হাতের কাছে রাখুন',
    description: 'যেকোনো সেবা আবেদনের সময় আবেদনকারী এবং পিতা-মাতার সচল জাতীয় পরিচয়পত্র (NID) নম্বর ও ১৭ ডিজিটের ডিজিটাল জন্ম নিবন্ধন নম্বর সাথে রাখুন। এতে আবেদন বাতিল হওয়ার ঝুঁকি কমে।',
    tag: 'ভুল এড়ানোর টিপস',
    badgeColor: 'amber',
    actionPrompt: 'অনলাইন আবেদনের জন্য NID ও জন্ম নিবন্ধনের কোন কোন তথ্য হুবহু মিলাতে হয়?'
  },
  {
    id: 'tip-spelling-match',
    category: 'all',
    title: 'বাংলা ও ইংরেজি নামের বানান হুবহু মিলিয়ে নিন',
    description: 'অনলাইন ফরমে নাম, পিতা-মাতার নাম ও স্থায়ী ঠিকানার বানান পূর্বের শিক্ষাগত সনদ ও NID-এর সাথে হুবহু এক হতে হবে। নামের আংশিক পার্থক্যেও আবেদন আটকে যেতে পারে।',
    tag: 'বানান যাচাই',
    badgeColor: 'blue',
    actionPrompt: 'নামের বানান ভুল হলে কি জন্ম নিবন্ধন বা সনদ বাতিল হতে পারে?'
  },
  {
    id: 'tip-member-sign',
    category: 'certificate',
    title: 'নাগরিক ও চারিত্রিক সনদে ওয়ার্ড মেম্বারের সুপারিশ আবশ্যক',
    description: 'ইউপি সচিব বা চেয়ারম্যান মহোদয়ের স্বাক্ষরের আগে সংশ্লিষ্ট ওয়ার্ড মেম্বারের (ইউপি সদস্য) স্বাক্ষর ও সিল নিশ্চিত করে নিন। অন্যথায় কাউন্টারে ফাইল বিলম্বিত হবে।',
    tag: 'সুপারিশ নিয়ম',
    badgeColor: 'emerald',
    actionPrompt: 'নাগরিক সনদে ওয়ার্ড মেম্বারের স্বাক্ষর নিতে কী কী কাগজ সাথে নেওয়া প্রয়োজন?'
  },
  {
    id: 'tip-birth-free-window',
    category: 'civil',
    title: 'জন্মের ৪৫ দিনের মধ্যে নিবন্ধন সম্পূর্ণ বিনামূল্যে',
    description: 'নবজাতক শিশুর বয়স ৪৫ দিন পার হওয়ার আগেই জন্ম নিবন্ধন আবেদন জমা দিলে কোনো সরকারি ফি দিতে হয় না। সাথে শিশুর ইপিআই (EPI) টিকা কার্ডের স্পষ্ট কপি রাখুন।',
    tag: 'বিনামূল্যে সেবা',
    badgeColor: 'emerald',
    actionPrompt: '৪৫ দিনের মধ্যে জন্ম নিবন্ধনে সরকারি ফি ও ইপিআই কার্ডের নিয়ম কী?'
  },
  {
    id: 'tip-allowance-age',
    category: 'social_welfare',
    title: 'ভাতা আবেদনের ক্ষেত্রে বয়সসীমা ও শর্তাবলি নিশ্চিত হন',
    description: 'বয়স্ক ভাতার জন্য পুরুষের বয়স সর্বনিম্ন ৬৫ এবং নারীদের ক্ষেত্রে সর্বনিম্ন ৬২ বছর হওয়া বাধ্যতামূলক। সাথে জাতীয় পরিচয়পত্র ও রঙিন পাসপোর্ট সাইজ ছবি প্রস্তুত রাখুন।',
    tag: 'বয়স যাচাই',
    badgeColor: 'purple',
    actionPrompt: 'বয়স্ক ভাতা ও বিধবা ভাতার আবেদনের সরকারি যোগ্যতা কী কী?'
  },
  {
    id: 'tip-warish-docs',
    category: 'certificate',
    title: 'ওয়ারিশ সনদে সকল জীবিত ও মৃত ওয়ারিশের তথ্য প্রস্তুত রাখুন',
    description: 'উত্তরাধিকার সনদের জন্য পারিবারিক ওয়ারিশান বণ্টননামা, মৃত ব্যক্তির মৃত্যু সনদ এবং জীবিত সকল ওয়ারিশের জাতীয় পরিচয়পত্র/জন্ম নিবন্ধনের কপি প্রস্তুত রাখুন।',
    tag: 'ওয়ারিশ সনদ',
    badgeColor: 'amber',
    actionPrompt: 'ওয়ারিশ সনদ নেওয়ার সঠিক নিয়ম ও প্রয়োজনীয় কাগজপত্র কী কী?'
  }
];

interface ServiceTipBannerProps {
  currentCategory?: string;
  onAskAiPrompt?: (promptText: string) => void;
}

export const ServiceTipBanner: React.FC<ServiceTipBannerProps> = ({
  currentCategory = 'all',
  onAskAiPrompt,
}) => {
  // Filter tips based on selected category if matching, otherwise show all
  const filteredTips = React.useMemo(() => {
    if (currentCategory === 'all' || !currentCategory) {
      return DEFAULT_TIPS;
    }
    const matching = DEFAULT_TIPS.filter(
      (t) => t.category === currentCategory || t.category === 'all'
    );
    return matching.length > 0 ? matching : DEFAULT_TIPS;
  }, [currentCategory]);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Auto-advance tip every 7 seconds when not hovered
  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % filteredTips.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [isPaused, filteredTips.length]);

  // Adjust index if filtered tips list shrinks
  useEffect(() => {
    if (currentIndex >= filteredTips.length) {
      setCurrentIndex(0);
    }
  }, [filteredTips, currentIndex]);

  const currentTip = filteredTips[currentIndex] || DEFAULT_TIPS[0];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + filteredTips.length) % filteredTips.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % filteredTips.length);
  };

  const getBadgeStyle = (color: ServiceTip['badgeColor']) => {
    switch (color) {
      case 'amber':
        return 'bg-amber-100 text-amber-900 border-amber-300';
      case 'emerald':
        return 'bg-emerald-100 text-emerald-900 border-emerald-300';
      case 'purple':
        return 'bg-purple-100 text-purple-900 border-purple-300';
      case 'blue':
      default:
        return 'bg-blue-100 text-blue-900 border-blue-300';
    }
  };

  return (
    <div 
      id="service-tip-banner"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className="mb-4 bg-gradient-to-r from-amber-50/90 via-orange-50/70 to-amber-50/90 border border-amber-200/90 rounded-2xl p-3.5 sm:p-4 shadow-sm transition-all relative overflow-hidden"
    >
      {/* Background soft accent badge */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        {/* Left Side: Icon & Content */}
        <div className="flex items-start gap-3 flex-1">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-800 shrink-0 mt-0.5">
            <Lightbulb className="w-5 h-5 text-amber-700 animate-pulse" />
          </div>

          <div className="space-y-1 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[10px] sm:text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border flex items-center gap-1 bg-amber-200/70 text-amber-900 border-amber-300">
                <AlertTriangle className="w-3 h-3 text-amber-700" />
                আবেদনের পূর্বে জরুরি স্মরণীয়
              </span>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${getBadgeStyle(currentTip.badgeColor)}`}>
                {currentTip.tag}
              </span>
            </div>

            <h4 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug">
              {currentTip.title}
            </h4>

            <p className="text-xs text-slate-700 leading-relaxed max-w-2xl">
              {currentTip.description}
            </p>
          </div>
        </div>

        {/* Right Side: Quick Action & Slide Controls */}
        <div className="flex items-center justify-between sm:justify-end gap-2 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-amber-200/60 shrink-0">
          {/* Ask AI shortcut for this tip */}
          {currentTip.actionPrompt && onAskAiPrompt && (
            <button
              id="service-tip-ask-ai-btn"
              onClick={() => onAskAiPrompt(currentTip.actionPrompt!)}
              className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-amber-100/80 text-amber-950 text-xs font-semibold border border-amber-300 flex items-center gap-1 shadow-2xs transition-colors"
              title="এই টিপস সম্পর্কে AI সহকারীকে প্রশ্ন করুন"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span className="text-[11px]">AI পরামর্শ</span>
            </button>
          )}

          {/* Navigation Controls */}
          <div className="flex items-center gap-1">
            <button
              id="service-tip-prev-btn"
              onClick={handlePrev}
              aria-label="পূর্ববর্তী পরামর্শ"
              className="p-1 rounded-lg hover:bg-amber-200/60 text-slate-700 transition-colors"
              title="পূর্ববর্তী পরামর্শ"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <span className="text-[11px] font-mono text-amber-900 px-1 font-medium">
              {currentIndex + 1}/{filteredTips.length}
            </span>

            <button
              id="service-tip-next-btn"
              onClick={handleNext}
              aria-label="পরবর্তী পরামর্শ"
              className="p-1 rounded-lg hover:bg-amber-200/60 text-slate-700 transition-colors"
              title="পরবর্তী পরামর্শ"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Progress Dots Indicator */}
      <div className="flex items-center justify-center gap-1 mt-2.5 pt-1">
        {filteredTips.map((tip, idx) => (
          <button
            key={tip.id}
            id={`service-tip-dot-${idx}`}
            onClick={() => setCurrentIndex(idx)}
            aria-label={`পরামর্শ ${idx + 1}`}
            className={`h-1.5 rounded-full transition-all ${
              idx === currentIndex
                ? 'w-6 bg-amber-600'
                : 'w-1.5 bg-amber-300 hover:bg-amber-400'
            }`}
          />
        ))}
      </div>
    </div>
  );
};
