import React, { useState } from 'react';
import { Search, FileSearch, Sparkles, ArrowRight, Clock, UserCheck } from 'lucide-react';
import { CITIZEN_REPORTS_DATA } from '../data/knowledgeBase';

interface ReportNumberSectionProps {
  onAnalyzeReport: (reportNo: string) => void;
}

export const ReportNumberSection: React.FC<ReportNumberSectionProps> = ({ onAnalyzeReport }) => {
  const [reportInput, setReportInput] = useState('');
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (reportInput.trim()) {
      onAnalyzeReport(reportInput.trim().toUpperCase());
    }
  };

  const handleSelectQuick = (repNo: string) => {
    setReportInput(repNo);
    setSelectedReportId(repNo);
    onAnalyzeReport(repNo);
  };

  return (
    <section id="report-number-section" className="mb-8">
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600">
              <FileSearch className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-1.5">
                <span>রিপোর্ট নম্বর দিয়ে অনুসন্ধান ও AI বিশ্লেষণ</span>
              </h3>
              <p className="text-xs text-slate-500">
                আবেদনের পূর্বের সমস্যা ও পরবর্তী করণীয় জানতে রিপোর্ট নম্বর লিখুন
              </p>
            </div>
          </div>
          <span className="hidden sm:inline-flex text-[11px] font-semibold bg-blue-100 text-blue-800 px-2.5 py-1 rounded-full border border-blue-200">
            UPMS ট্র্যাকিং
          </span>
        </div>

        {/* Input Form matching wireframe: [ রিপোর্ট নং দিন: _____ ] [ বিশ্লেষণ করুন ] */}
        <form onSubmit={handleSubmit} className="mt-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            <div className="relative flex-1">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-semibold text-slate-400">
                রিপোর্ট নং:
              </span>
              <input
                type="text"
                id="report-input-field"
                value={reportInput}
                onChange={(e) => setReportInput(e.target.value)}
                placeholder="যেমন: BT-REP-01"
                className="w-full pl-24 pr-4 py-3 text-sm font-mono tracking-wider font-semibold text-slate-800 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all uppercase placeholder:normal-case placeholder:font-normal placeholder:text-slate-400"
              />
            </div>

            <button
              type="submit"
              id="analyze-report-btn"
              disabled={!reportInput.trim()}
              className="px-6 py-3 bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 disabled:opacity-50 text-white font-bold text-sm rounded-xl shadow-sm flex items-center justify-center gap-2 transition-all active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-blue-200" />
              <span>বিশ্লেষণ করুন</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>

        {/* Quick Sample Report Numbers from Knowledge Base */}
        <div className="mt-4 pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span className="font-medium">নমুনা ডাটাবেস রেকর্ড (ক্লিক করে তাৎক্ষণিক দেখুন):</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {CITIZEN_REPORTS_DATA.slice(0, 3).map((item) => (
              <button
                key={item.reportNo}
                type="button"
                onClick={() => handleSelectQuick(item.reportNo)}
                className="p-2.5 rounded-xl border border-slate-200 hover:border-blue-400 bg-slate-50/70 hover:bg-blue-50/50 text-left transition-all flex flex-col justify-between group"
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-mono text-xs font-bold text-blue-700 group-hover:underline">
                    {item.reportNo}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold border border-amber-200">
                    {item.currentStatus}
                  </span>
                </div>
                <p className="text-xs text-slate-800 font-semibold mt-1 truncate">
                  {item.citizenName} • {item.serviceName}
                </p>
                <p className="text-[11px] text-slate-500 truncate mt-0.5">
                  আটকে থাকা ধাপ: {item.stuckStep}
                </p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
