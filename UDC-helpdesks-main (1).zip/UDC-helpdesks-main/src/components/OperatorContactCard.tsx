import React, { useState } from 'react';
import { 
  Phone, 
  MessageCircle, 
  Mail, 
  Globe, 
  MapPin, 
  ShieldCheck, 
  Camera, 
  Edit3, 
  X, 
  Save, 
  Check, 
  Upload,
  AlertCircle
} from 'lucide-react';
import { OperatorProfile } from '../types';

interface OperatorContactCardProps {
  operator: OperatorProfile;
  onUpdateOperator: (updated: Partial<OperatorProfile>) => Promise<void>;
  showEditModal: boolean;
  setShowEditModal: (show: boolean) => void;
  onCallWarningModal: () => void;
}

export const OperatorContactCard: React.FC<OperatorContactCardProps> = ({
  operator,
  onUpdateOperator,
  showEditModal,
  setShowEditModal,
  onCallWarningModal
}) => {
  const [photoPreview, setPhotoPreview] = useState<string>(operator.photoUrl);
  const [customPhone, setCustomPhone] = useState<string>(operator.phone);
  const [customEmail, setCustomEmail] = useState<string>(operator.email);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveOperatorConfig = async () => {
    setIsSaving(true);
    try {
      await onUpdateOperator({
        photoUrl: photoPreview,
        phone: customPhone,
        email: customEmail
      });
      setSaveSuccess(true);
      setTimeout(() => {
        setSaveSuccess(false);
        setShowEditModal(false);
      }, 1200);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-md mb-8">
      <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <h3 className="text-base font-bold text-slate-800">
            হেল্পডেস্ক অপারেটর ও ডিজিটাল সেবা প্রতিনিধি
          </h3>
        </div>
        <button
          id="open-operator-edit-modal-btn"
          onClick={() => {
            setPhotoPreview(operator.photoUrl);
            setShowEditModal(true);
          }}
          className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200 hover:bg-blue-100 transition-colors"
        >
          <Camera className="w-3.5 h-3.5" />
          <span>ছবি পরিবর্তন / এডিট</span>
        </button>
      </div>

      <div className="flex flex-col md:flex-row items-center md:items-start gap-5">
        {/* Profile Image with status badge */}
        <div className="relative group shrink-0">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border-2 border-emerald-500 shadow-md bg-slate-100">
            <img
              id="operator-profile-image"
              src={operator.photoUrl}
              alt={operator.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=MD+Jubaer+Hossen&background=0D8ABC&color=fff';
              }}
            />
          </div>
          <button
            onClick={() => setShowEditModal(true)}
            className="absolute -bottom-2 -right-2 p-1.5 rounded-full bg-slate-900 text-white shadow-md hover:bg-slate-800 border-2 border-white transition-colors"
            title="ছবি পরিবর্তন করুন"
          >
            <Camera className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Profile Information */}
        <div className="text-center md:text-left space-y-1.5 flex-1">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
            <h4 className="text-lg sm:text-xl font-bold text-slate-900">
              {operator.name}
            </h4>
            <span className="text-[11px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full border border-emerald-300">
              ভেরিফায়েড প্রতিনিধি
            </span>
          </div>

          <p className="text-xs sm:text-sm font-semibold text-slate-600">
            {operator.role}
          </p>

          <p className="text-xs text-slate-500 flex items-center justify-center md:justify-start gap-1">
            <MapPin className="w-3.5 h-3.5 text-red-500" />
            <span>{operator.unionName}, {operator.upazila}, {operator.district}</span>
          </p>

          {/* Guidelines reminder */}
          <div className="mt-2 p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p>
              <strong>যোগাযোগের নিয়ম:</strong> অনুগ্রহ করে কল বা ভয়েস মেসেজ না দিয়ে <strong>SMS অথবা WhatsApp Text Message</strong>-এর মাধ্যমে যোগাযোগ করুন।
            </p>
          </div>

          {/* Contact Action Buttons */}
          <div className="pt-3 flex flex-wrap items-center justify-center md:justify-start gap-2">
            <a
              id="operator-btn-whatsapp"
              href={operator.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp চ্যাট</span>
              <span className="bg-black/20 text-[10px] font-bold px-1.5 py-0.5 rounded ml-1">📞 ১০:০০–৫:০০ (শনি–বৃহঃ)</span>
            </a>

            <button
              id="operator-btn-phone"
              onClick={onCallWarningModal}
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 border border-slate-300 transition-colors"
            >
              <Phone className="w-4 h-4 text-slate-600" />
              <span>{operator.phone}</span>
            </button>

            <a
              id="operator-btn-gmail"
              href={`mailto:${operator.email}`}
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 border border-slate-300 transition-colors"
            >
              <Mail className="w-4 h-4 text-red-600" />
              <span>Gmail</span>
            </a>

            <a
              id="operator-btn-facebook"
              href={operator.facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 border border-slate-300 transition-colors"
            >
              <Globe className="w-4 h-4 text-blue-600" />
              <span>Facebook</span>
            </a>
          </div>

          <div className="mt-2 flex items-center gap-1.5 text-xs text-emerald-800 font-semibold bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>📞 অফিস আওয়ার: ১০:০০–৫:০০ (শনি–বৃহঃ) | শুক্রবার বন্ধ</span>
          </div>
        </div>
      </div>

      {/* Profile Edit / Image Upload Modal */}
      {showEditModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div 
            id="operator-edit-modal-box"
            className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <Camera className="w-4 h-4 text-blue-600" />
                <span>অপারেটর প্রোফাইল ছবি ও তথ্য পরিবর্তন</span>
              </h4>
              <button
                onClick={() => setShowEditModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Photo preview & file upload */}
            <div className="flex flex-col items-center gap-3">
              <div className="w-28 h-28 rounded-2xl overflow-hidden border-2 border-blue-500 shadow-md bg-slate-100">
                <img
                  src={photoPreview}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
              </div>

              <label 
                id="upload-photo-label"
                className="cursor-pointer px-4 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold border border-blue-200 flex items-center gap-2 transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span>মোবাইল বা পিসি থেকে ছবি আপলোড করুন</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
              <span className="text-[11px] text-slate-400">JPG, PNG বা WebP ফরম্যাট সমর্থন করে</span>
            </div>

            {/* Contact numbers config */}
            <div className="space-y-3 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  মোবাইল নম্বর
                </label>
                <input
                  type="text"
                  value={customPhone}
                  onChange={(e) => setCustomPhone(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  অফিসিয়াল ইমেইল
                </label>
                <input
                  type="email"
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Save Buttons */}
            <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
              <button
                onClick={() => setShowEditModal(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
              >
                বাতিল
              </button>
              <button
                id="save-operator-profile-btn"
                onClick={handleSaveOperatorConfig}
                disabled={isSaving}
                className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm"
              >
                {saveSuccess ? (
                  <>
                    <Check className="w-4 h-4 text-white" />
                    <span>সংরক্ষিত হয়েছে!</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>{isSaving ? 'সংরক্ষণ হচ্ছে...' : 'সংরক্ষণ করুন'}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
