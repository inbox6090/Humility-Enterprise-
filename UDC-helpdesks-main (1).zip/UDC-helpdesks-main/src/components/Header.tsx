import React from 'react';
import { Shield, Sparkles, MessageCircle, WifiOff, Home, Users, ArrowLeft } from 'lucide-react';
import { OperatorProfile, Route } from '../types';

interface HeaderProps {
  operator: OperatorProfile;
  currentRoute: Route;
  onNavigate: (route: Route) => void;
  isOnline: boolean;
  onOpenOperatorModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  operator,
  currentRoute,
  onNavigate,
  isOnline,
  onOpenOperatorModal
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0c1e36]/95 backdrop-blur-md text-white border-b border-slate-700/80 shadow-md">
      {/* Offline banner if disconnected (matching wireframe: ❗ ইন্টারনেট সংযোগ পাওয়া যাচ্ছে না) */}
      {!isOnline && (
        <div id="offline-alert-banner" className="bg-amber-600 text-white text-xs py-1.5 px-3 text-center flex items-center justify-center gap-1.5 font-medium">
          <WifiOff className="w-3.5 h-3.5 animate-pulse" />
          <span>❗ ইন্টারনেট সংযোগ পাওয়া যাচ্ছে না। অনুগ্রহ করে সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।</span>
        </div>
      )}

      {/* Main Bar */}
      <div className="max-w-4xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
        <div 
          onClick={() => onNavigate('Home')} 
          className="flex items-center gap-2.5 cursor-pointer group"
          id="header-brand-logo"
        >
          {/* Official Emblem/Govt Badge Icon */}
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-inner border border-emerald-400/40 shrink-0 group-hover:scale-105 transition-transform">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-medium tracking-wide uppercase px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                ০২নং বহেড়াতৈল
              </span>
              <span className="text-[11px] text-slate-300">সখিপুর, টাঙ্গাইল</span>
            </div>
            <h1 className="text-sm md:text-base font-bold text-white tracking-tight leading-tight">
              ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্ক
            </h1>
          </div>
        </div>

        {/* Operator Profile Thumbnail & Direct AI Trigger */}
        <div className="flex items-center gap-2">
          <button
            id="header-quick-ai-btn"
            onClick={() => onNavigate('AiChat')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
              currentRoute === 'AiChat'
                ? 'bg-emerald-500 text-slate-950 shadow-sm shadow-emerald-500/30'
                : 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 border border-emerald-500/40'
            }`}
            title="AI সহকারীকে প্রশ্ন করুন"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-spin-slow" />
            <span className="inline">AI সহকারী</span>
          </button>

          <button
            id="header-operator-avatar-btn"
            onClick={onOpenOperatorModal}
            className="flex items-center gap-1.5 p-1 rounded-full hover:bg-white/10 transition-colors border border-slate-600/70"
            title="হেল্পডেস্ক অপারেটর ও যোগাযোগ তথ্য"
          >
            <img
              src={operator.photoUrl}
              alt={operator.name}
              className="w-8 h-8 rounded-full object-cover border border-emerald-400/60"
              onError={(e) => {
                // Fallback avatar
                (e.target as HTMLImageElement).src = 'https://ui-avatars.com/api/?name=MD+Jubaer+Hossen&background=0D8ABC&color=fff';
              }}
            />
          </button>
        </div>
      </div>

      {/* Navigation Tabs - Mobile Optimized matching Screens: HomeScreen, AiChatScreen, ContactDirectoryScreen */}
      <nav className="max-w-4xl mx-auto px-2 flex items-center justify-around border-t border-slate-700/50 bg-[#09172a] text-xs">
        <button
          id="nav-tab-home"
          onClick={() => onNavigate('Home')}
          className={`flex-1 py-2.5 text-center font-bold border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
            currentRoute === 'Home'
              ? 'border-emerald-400 text-emerald-400 bg-white/5'
              : 'border-transparent text-slate-300 hover:text-white'
          }`}
        >
          <Home className="w-3.5 h-3.5" />
          <span>হোম (Home)</span>
        </button>

        <button
          id="nav-tab-chat"
          onClick={() => onNavigate('AiChat')}
          className={`flex-1 py-2.5 text-center font-bold border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
            currentRoute === 'AiChat'
              ? 'border-emerald-400 text-emerald-400 bg-white/5'
              : 'border-transparent text-slate-300 hover:text-white'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          <span>AI সহকারী (Chat)</span>
        </button>

        <button
          id="nav-tab-contact"
          onClick={() => onNavigate('ContactDirectory')}
          className={`flex-1 py-2.5 text-center font-bold border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
            currentRoute === 'ContactDirectory'
              ? 'border-emerald-400 text-emerald-400 bg-white/5'
              : 'border-transparent text-slate-300 hover:text-white'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>ডিরেক্টরি (Directory)</span>
        </button>
      </nav>
    </header>
  );
};

