import React from 'react';
import { Users, Phone, ArrowRight, Shield, UserCheck, ChevronRight } from 'lucide-react';
import { CONTACT_DIRECTORY_DATA } from '../data/knowledgeBase';

interface ContactDirectoryPreviewProps {
  onViewFullDirectory: () => void;
  onCallModal?: (phone: string, name: string) => void;
}

export const ContactDirectoryPreview: React.FC<ContactDirectoryPreviewProps> = ({
  onViewFullDirectory,
}) => {
  const data = CONTACT_DIRECTORY_DATA;

  const keyLeaders = [
    {
      title: 'চেয়ারম্যান',
      name: data.chairman.name,
      phone: data.chairman.mobile,
      role: 'ইউপি চেয়ারম্যান/প্রশাসক',
      color: 'border-emerald-500 bg-emerald-50/50 text-emerald-900',
      badge: 'bg-emerald-100 text-emerald-800'
    },
    {
      title: 'সচিব',
      name: data.secretary.name,
      phone: data.secretary.mobile,
      role: 'ইউনিয়ন পরিষদ সচিব',
      color: 'border-blue-500 bg-blue-50/50 text-blue-900',
      badge: 'bg-blue-100 text-blue-800'
    },
    {
      title: 'ইউডিসি অপারেটর',
      name: data.udc_operator.name,
      phone: data.udc_operator.mobile,
      role: 'উদ্যোক্তা ও হেল্পডেস্ক',
      color: 'border-teal-500 bg-teal-50/50 text-teal-900',
      badge: 'bg-teal-100 text-teal-800'
    },
    {
      title: 'মেম্বার তালিকা',
      name: `${data.members.length} জন ওয়ার্ড মেম্বার`,
      phone: '১ থেকে ৯ নং ওয়ার্ড',
      role: 'জনপ্রতিনিধিবৃন্দ',
      color: 'border-amber-500 bg-amber-50/50 text-amber-900',
      badge: 'bg-amber-100 text-amber-800'
    }
  ];

  return (
    <section id="contact-directory-preview" className="mb-8">
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-800">
              <Users className="w-5 h-5 text-[#0c1e36]" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
                <span>কর্মকর্তা ও জনপ্রতিনিধি পরিচিতি</span>
                <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                  ডিরেক্টরি
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                চেয়ারম্যান, সচিব, মেম্বার ও গ্রাম পুলিশের সার্বক্ষণিক যোগাযোগের তালিকা
              </p>
            </div>
          </div>

          <button
            id="preview-full-directory-btn-top"
            onClick={onViewFullDirectory}
            className="self-start sm:self-center text-xs font-bold text-blue-700 hover:text-blue-900 flex items-center gap-1 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg border border-blue-200 transition-colors"
          >
            <span>সম্পূর্ণ ডিরেক্টরি দেখুন</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 4 Primary Hierarchy Cards Preview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {keyLeaders.map((item, idx) => (
            <div
              key={idx}
              className={`p-3.5 rounded-xl border ${item.color} flex flex-col justify-between transition-all hover:shadow-sm`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${item.badge}`}>
                    {item.title}
                  </span>
                  <UserCheck className="w-4 h-4 text-slate-400" />
                </div>
                <h4 className="text-sm font-bold text-slate-900 leading-snug">
                  {item.name}
                </h4>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  {item.role}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-200/60 flex items-center justify-between text-xs">
                <span className="font-mono text-slate-700 font-medium">
                  {item.phone}
                </span>
                <span className="text-[11px] text-blue-600 font-semibold group-hover:underline flex items-center gap-0.5">
                  বিস্তারিত <ChevronRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Callout: View Full Directory Button matching wireframe */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50/70 p-3 rounded-xl border border-slate-200/80">
          <div className="text-xs text-slate-600 text-center sm:text-left">
            <span className="font-semibold text-slate-800">৯ জন সাধারণ মেম্বার, ৩ জন সংরক্ষিত মহিলা সদস্য ও ১০ জন গ্রাম পুলিশের</span> নম্বর অন্তর্ভুক্ত রয়েছে।
          </div>

          <button
            id="preview-full-directory-btn"
            onClick={onViewFullDirectory}
            className="w-full sm:w-auto px-5 py-2.5 bg-[#0c1e36] hover:bg-[#142c4d] text-white font-bold text-xs rounded-xl shadow-sm flex items-center justify-center gap-2 transition-all active:scale-95 shrink-0"
          >
            <span>View Full Directory (সম্পূর্ণ ডিরেক্টরি)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </section>
  );
};
