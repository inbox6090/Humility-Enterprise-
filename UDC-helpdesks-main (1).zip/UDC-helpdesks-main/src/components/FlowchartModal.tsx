import React, { useState } from 'react';
import { GitBranch, X, Copy, Check, ArrowDown, UserCheck, ShieldCheck, FileText, PhoneCall, AlertCircle, Sparkles } from 'lucide-react';

interface FlowchartModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartFlowchartMode?: () => void;
}

export const FlowchartModal: React.FC<FlowchartModalProps> = ({
  isOpen,
  onClose,
  onStartFlowchartMode
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const markdownFlowchart = `🗺️ Digital Union Parishad Helpdesk — WhatsApp Conversation Flowchart (Q1–Q7)

Citizen → WhatsApp Message
    ↓
Q1: নাম (Name)
    ↓
Q2: মোবাইল WhatsApp থেকে পাওয়া (Mobile from WhatsApp)
    ↓
Q3: পূর্বে যোগাযোগ করেছেন? (Previous Contact?)
    ↓
Q4: কোন সেবা? (Service Selection)
    ↓
Q5: উদ্দেশ্য? (Purpose / Specific Need)
    ↓
Q6: কাগজপত্র/সময়? (Documents & Timeframe)
    ↓
Q7: পূর্বে জমা দেওয়া কাজ? (Prior Submission Check)
    ↓
AI → Summary + Report Number + Final Guidance

==================================================
📋 বিস্তারিত কার্যপ্রণালী (Step Breakdown):

1️⃣ Citizen → WhatsApp Message
- নাগরিক ইউনিয়ন পরিষদের WhatsApp নম্বরে বার্তা পাঠায় বা হেল্পডেস্কে অনবোর্ডিং শুরু করে।

2️⃣ Q1: নাম
- AI: "স্বাগতম! ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল হেল্পডেস্কে আপনাকে স্বাগতম। (প্রশ্ন ১/৭) আপনার নামটি জানাবেন?"
- Citizen: [নাম প্রদান করে]

3️⃣ Q2: মোবাইল WhatsApp থেকে পাওয়া
- AI: "[নাম], ধন্যবাদ! (প্রশ্ন ২/৭) আপনার মোবাইল নম্বরটি দিন (WhatsApp থেকে প্রাপ্ত বা আপনার সচল নম্বর)।"
- Citizen: [মোবাইল নম্বর প্রদান করে]

4️⃣ Q3: পূর্বে যোগাযোগ করেছেন?
- Backend: নাগরিক ডাটাবেস যাচাই করে পূর্বের রেকর্ড চেক করে।
- AI: "(প্রশ্ন ৩/৭) আপনি কি পূর্বে ইউনিয়ন পরিষদে বা হেল্পডেস্কে এই বিষয়ে যোগাযোগ করেছেন? [হ্যাঁ / না] (পূর্বে কোনো রিপোর্ট নং থাকলে জানাতে পারেন)"
- Citizen: [হ্যাঁ / না / রিপোর্ট নং]

5️⃣ Q4: কোন সেবা?
- AI: "(প্রশ্ন ৪/৭) আপনি ইউনিয়ন পরিষদের কোন সেবাটি গ্রহণ করতে চান? (যেমন: জন্ম নিবন্ধন, নাগরিকত্ব সনদ, ওয়ারিশান সনদ, ট্রেড লাইসেন্স, ইত্যাদি)"
- Citizen: [সেবার নাম বাছাই করে]

6️⃣ Q5: উদ্দেশ্য?
- AI: "(প্রশ্ন ৫/৭) এই সেবা গ্রহণের মূল উদ্দেশ্য বা সুনির্দিষ্ট সমস্যাটি কী? (যেমন: নতুন আবেদন, ভুল তথ্য সংশোধন, স্ট্যাটাস জানা, বা নিয়মাবলি জানা)"
- Citizen: [উদ্দেশ্য বা সমস্যার বিবরণ দেয়]

7️⃣ Q6: কাগজপত্র/সময়?
- AI: "(প্রশ্ন ৬/৭) প্রয়োজনীয় কাগজপত্র (NID, টিকা কার্ড, ট্যাক্স রশিদ ইত্যাদি) কি প্রস্তুত আছে? এবং কতদিনের মধ্যে সেবাটি প্রয়োজন?"
- Citizen: [কাগজপত্রের অবস্থা ও সময়সীমা জানায়]

8️⃣ Q7: পূর্বে জমা দেওয়া কাজ?
- AI: "(প্রশ্ন ৭/৭) পূর্বে কি এই সংক্রান্ত কোনো আবেদন বা কাগজপত্র ইউনিয়ন ডিজিটাল সেন্টার (UDC) বা সচিব/চেয়ারম্যান কার্যালয়ে জমা দেওয়া হয়েছিল? [হ্যাঁ / না / বিবরণ]"
- Citizen: [জমা দেওয়ার অবস্থা জানায়]

9️⃣ AI → Summary + Report Number + Final Guidance
- 📋 কথোপকথন সারসংক্ষেপ (WhatsApp Summary)
- 🎫 অফিসিয়াল রিপোর্ট নং (স্বয়ংক্রিয় ইউনিক ৫ ডিজিট সংখ্যা)
- 📌 সেবা, প্রয়োজনীয় কাগজপত্র, সরকারি ফি ও সময়সীমা
- 🏢 দায়িত্বপ্রাপ্ত কাউন্টার (UDC / সচিব / চেয়ারম্যান)
- 👉 পরিস্থিতি পর্যালোচনা ও সম্ভাব্য কারণ
- ✅ চূড়ান্ত দিকনির্দেশনা (Final Guidance)
- 📞 হেল্পডেস্ক কল ও WhatsApp যোগাযোগ
`;

  const handleCopyMarkdown = () => {
    navigator.clipboard.writeText(markdownFlowchart);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        id="flowchart-modal-dialog"
        className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden"
      >
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-emerald-800 to-teal-800 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center text-white">
              <GitBranch className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base">
                কথোপকথন ফ্লোচার্ট (Full Conversation Flowchart)
              </h3>
              <p className="text-xs text-emerald-100">
                নাগরিক ↔ AI সহকারী ৫-ধাপীয় যাচাই ও সেবা প্রবাহ
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyMarkdown}
              className="px-2.5 py-1 rounded-lg bg-white/15 hover:bg-white/25 text-xs text-white flex items-center gap-1.5 transition-colors border border-white/20"
              title="Markdown কপি করুন"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'কপি হয়েছে' : 'Markdown'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Flowchart Visual Cards Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3.5 text-xs sm:text-sm text-slate-700 bg-slate-50/50">
          {/* Top Banner */}
          <div className="bg-emerald-900 text-white p-3 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="font-semibold text-xs sm:text-sm">Citizen → WhatsApp Message (৭-ধাপ বিশিষ্ট ফ্লোচার্ট)</span>
            </div>
            <span className="bg-emerald-800 text-emerald-200 px-2 py-0.5 rounded text-[11px] font-mono">Q1 ➔ Q7 ➔ AI Summary</span>
          </div>

          {/* Step 1: Q1 */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-emerald-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-mono">Q1</span>
                Q1: নাম (Citizen Name)
              </span>
              <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[11px]">ধাপ ১/৭</span>
            </div>
            <p className="text-slate-600 mb-1 text-xs">
              AI নাগরিককে সম্ভাষণ জানিয়ে শুভ নাম জিজ্ঞাসা করবে:
            </p>
            <div className="bg-slate-100 p-2 rounded font-mono text-xs text-slate-800">
              AI: "স্বাগতম! ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল হেল্পডেস্কে আপনাকে স্বাগতম। আপনার নামটি জানাবেন?"
            </div>
          </div>

          <div className="flex justify-center text-slate-400">
            <ArrowDown className="w-3.5 h-3.5" />
          </div>

          {/* Step 2: Q2 */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-blue-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-mono">Q2</span>
                Q2: মোবাইল WhatsApp থেকে পাওয়া (Mobile Number)
              </span>
              <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-[11px] font-semibold">ধাপ ২/৭</span>
            </div>
            <p className="text-slate-600 mb-1 text-xs">
              WhatsApp সংযোগ থেকে স্বয়ংক্রিয়ভাবে বা নাগরিকের থেকে সচল মোবাইল নম্বর গ্রহণ:
            </p>
            <div className="bg-blue-50/70 p-2 rounded border border-blue-200 font-mono text-xs text-blue-900">
              AI: "[নাম], ধন্যবাদ! আপনার সচল মোবাইল নম্বরটি দিন (WhatsApp থেকে প্রাপ্ত বা আপনার ১১ ডিজিটের নম্বর)।"
            </div>
          </div>

          <div className="flex justify-center text-slate-400">
            <ArrowDown className="w-3.5 h-3.5" />
          </div>

          {/* Step 3: Q3 */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-indigo-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-800 flex items-center justify-center font-mono">Q3</span>
                Q3: পূর্বে যোগাযোগ করেছেন? (Returning Check)
              </span>
              <span className="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded text-[11px] font-semibold">ধাপ ৩/৭</span>
            </div>
            <p className="text-slate-600 mb-1 text-xs">
              পূর্বে ইউনিয়ন পরিষদে বা হেল্পডেস্কে যোগাযোগ করেছিলেন কিনা এবং পূর্ববর্তী কোনো রিপোর্ট নম্বর আছে কিনা যাচাই:
            </p>
            <div className="bg-indigo-50/70 p-2 rounded border border-indigo-200 font-mono text-xs text-indigo-900">
              AI: "আপনি কি পূর্বে ইউনিয়ন পরিষদে বা হেল্পডেস্কে এই বিষয়ে যোগাযোগ করেছেন? [হ্যাঁ / না / রিপোর্ট নং]"
            </div>
          </div>

          <div className="flex justify-center text-slate-400">
            <ArrowDown className="w-3.5 h-3.5" />
          </div>

          {/* Step 4: Q4 */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-amber-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center font-mono">Q4</span>
                Q4: কোন সেবা? (Service Selection)
              </span>
              <span className="bg-amber-50 text-amber-800 px-2 py-0.5 rounded text-[11px] font-semibold">ধাপ ৪/৭</span>
            </div>
            <p className="text-slate-600 mb-1 text-xs">
              কাঙ্ক্ষিত সেবা নির্দিষ্টকরণ (যেমন: জন্ম নিবন্ধন, নাগরিকত্ব সনদ, ওয়ারিশান সনদ, ট্রেড লাইসেন্স ইত্যাদি):
            </p>
            <div className="bg-amber-50/70 p-2 rounded border border-amber-200 font-mono text-xs text-amber-900">
              AI: "আপনি ইউনিয়ন পরিষদের কোন সেবাটি গ্রহণ করতে চান? (যেমন: জন্ম নিবন্ধন, নাগরিকত্ব সনদ, ওয়ারিশান সনদ, ট্রেড লাইসেন্স, ইত্যাদি)"
            </div>
          </div>

          <div className="flex justify-center text-slate-400">
            <ArrowDown className="w-3.5 h-3.5" />
          </div>

          {/* Step 5: Q5 */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-rose-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-800 flex items-center justify-center font-mono">Q5</span>
                Q5: উদ্দেশ্য? (Purpose / Specific Need)
              </span>
              <span className="bg-rose-50 text-rose-800 px-2 py-0.5 rounded text-[11px] font-semibold">ধাপ ৫/৭</span>
            </div>
            <p className="text-slate-600 mb-1 text-xs">
              সেবা গ্রহণের সুনির্দিষ্ট উদ্দেশ্য বা আটকে থাকা সমস্যার কারণ জানা:
            </p>
            <div className="bg-rose-50/70 p-2 rounded border border-rose-200 font-mono text-xs text-rose-900">
              AI: "এই সেবা সংক্রান্ত আপনার মূল উদ্দেশ্য বা সুনির্দিষ্ট আবেদনটি কী? (যেমন: নতুন আবেদন, ভুল তথ্য সংশোধন, স্ট্যাটাস জানা, ইত্যাদি)"
            </div>
          </div>

          <div className="flex justify-center text-slate-400">
            <ArrowDown className="w-3.5 h-3.5" />
          </div>

          {/* Step 6: Q6 */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-teal-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                <span className="w-5 h-5 rounded-full bg-teal-100 text-teal-800 flex items-center justify-center font-mono">Q6</span>
                Q6: কাগজপত্র/সময়? (Documents Readiness & Deadline)
              </span>
              <span className="bg-teal-50 text-teal-800 px-2 py-0.5 rounded text-[11px] font-semibold">ধাপ ৬/৭</span>
            </div>
            <p className="text-slate-600 mb-1 text-xs">
              প্রয়োজনীয় কাগজপত্র প্রস্তুত আছে কি না এবং নাগরিকের কাঙ্ক্ষিত সময়সীমা জানা:
            </p>
            <div className="bg-teal-50/70 p-2 rounded border border-teal-200 font-mono text-xs text-teal-900">
              AI: "প্রয়োজনীয় কাগজপত্র (NID, টিকা কার্ড, ট্যাক্স রশিদ ইত্যাদি) কি প্রস্তুত আছে? এবং কতদিনের মধ্যে সেবাটি প্রয়োজন?"
            </div>
          </div>

          <div className="flex justify-center text-slate-400">
            <ArrowDown className="w-3.5 h-3.5" />
          </div>

          {/* Step 7: Q7 */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="font-bold text-orange-700 flex items-center gap-1.5 text-xs uppercase tracking-wide">
                <span className="w-5 h-5 rounded-full bg-orange-100 text-orange-800 flex items-center justify-center font-mono">Q7</span>
                Q7: পূর্বে জমা দেওয়া কাজ? (Prior Submission Check)
              </span>
              <span className="bg-orange-50 text-orange-800 px-2 py-0.5 rounded text-[11px] font-semibold">ধাপ ৭/৭</span>
            </div>
            <p className="text-slate-600 mb-1 text-xs">
              পূর্বে ইউডিসি কাউন্টার বা সচিব/চেয়ারম্যান কার্যালয়ে কোনো আবেদন বা ফাইল জমা দেওয়া হয়েছিল কি না:
            </p>
            <div className="bg-orange-50/70 p-2 rounded border border-orange-200 font-mono text-xs text-orange-900">
              AI: "পূর্বে কি এই সংক্রান্ত কোনো আবেদন বা কাগজপত্র ইউডিসি কাউন্টারে বা কার্যালয়ে জমা দেওয়া হয়েছিল? [হ্যাঁ / না / বিবরণ]"
            </div>
          </div>

          <div className="flex justify-center text-slate-400">
            <ArrowDown className="w-4 h-4 text-emerald-600" />
          </div>

          {/* AI: Summary + Report Number + Final Guidance */}
          <div className="bg-gradient-to-br from-[#0c1e36] to-[#16355d] text-white p-4 rounded-xl shadow-md border border-slate-700">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-emerald-300 flex items-center gap-1.5 text-xs sm:text-sm uppercase tracking-wide">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                AI → Summary + Report Number + Final Guidance
              </span>
              <span className="bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded text-[11px] font-semibold">চূড়ান্ত সারসংক্ষেপ ও গাইড</span>
            </div>
            <p className="text-slate-300 mb-2 text-xs">
              ৭টি উত্তরের উপর ভিত্তি করে AI সম্পূর্ণ আনুষ্ঠানিক ও অফিসিয়াল গাইড তৈরি করবে:
            </p>
            <div className="bg-black/40 p-3 rounded-lg text-xs font-mono space-y-1 text-slate-200 border border-slate-700">
              <p className="text-emerald-300">📋 কথোপকথন সারসংক্ষেপ (WhatsApp Summary): নাম, মোবাইল, সেবা, উদ্দেশ্য, কাগজপত্র, পূর্বের কাজ</p>
              <p className="text-amber-300">🎫 অফিসিয়াল ইউনিক রিপোর্ট নং: [৫ ডিজিটের ট্র্যাকিং নম্বর, যেমন: 34821]</p>
              <p className="text-sky-300">📌 সেবা ও দায়িত্বপ্রাপ্ত কাউন্টার: UDC / সচিব / চেয়ারম্যান</p>
              <p className="text-slate-300">📄 প্রয়োজনীয় কাগজপত্র, সরকারি ফি ও সময়সীমা</p>
              <p className="text-blue-300">👉 পরিস্থিতি পর্যালোচনা ও সম্ভাব্য কারণ বিশ্লেষণ</p>
              <p className="text-emerald-400">✅ চূড়ান্ত দিকনির্দেশনা (Step-by-step Final Guidance)</p>
              <p className="text-purple-300">📞 হেল্পডেস্ক কল ও WhatsApp সরাসরি যোগাযোগ</p>
            </div>
          </div>

          {/* WhatsApp Call Rule Highlight */}
          <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-300 text-xs text-emerald-950">
            <div className="flex items-center gap-2 font-bold text-emerald-900 mb-1">
              <PhoneCall className="w-4 h-4 text-emerald-700" />
              <span>WhatsApp Call & অফিস আওয়ার কঠোর নীতি:</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-700 pl-1">
              <li>অফিস আওয়ার: <strong>শনিবার–বৃহস্পতিবার সকাল ১০:০০ হতে বিকাল ৫:০০</strong> (শুক্রবার বন্ধ)।</li>
              <li>কল করার ইচ্ছা প্রকাশ করলে AI অবশ্যই অফিস আওয়ার এবং WhatsApp লিখিত বার্তার লিংক প্রদান করবে।</li>
              <li><strong>AI Safety Rule:</strong> AI কখনোই বলবে না "এখনই কল করুন", "আমি কল রিসিভ করব", "চেয়ারম্যান/সচিব এখন কল রিসিভ করবেন"।</li>
            </ul>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between shrink-0">
          <span className="text-xs text-slate-500">
            ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল হেল্পডেস্ক
          </span>

          <div className="flex items-center gap-2">
            {onStartFlowchartMode && (
              <button
                onClick={() => {
                  onClose();
                  onStartFlowchartMode();
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-colors shadow-xs"
              >
                অনবোর্ডিং ফ্লো শুরু করুন ➔
              </button>
            )}
            <button
              onClick={onClose}
              className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-200 text-slate-700 font-semibold text-xs border border-slate-300 transition-colors"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
