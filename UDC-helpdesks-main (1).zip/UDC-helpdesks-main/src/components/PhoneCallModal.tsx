import React from 'react';
import { Phone, MessageCircle, MessageSquare, AlertTriangle, X } from 'lucide-react';
import { OperatorProfile } from '../types';

interface PhoneCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  operator: OperatorProfile;
}

export const PhoneCallModal: React.FC<PhoneCallModalProps> = ({
  isOpen,
  onClose,
  operator
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in">
      <div 
        id="phone-call-warning-modal"
        className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4"
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2 text-amber-600">
            <AlertTriangle className="w-5 h-5" />
            <h4 className="font-bold text-slate-900 text-base">
              হেল্পডেস্ক যোগাযোগ নির্দেশিকা
            </h4>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning Notice Box */}
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 text-xs sm:text-sm leading-relaxed space-y-2">
          <p className="font-bold text-amber-900 text-sm">
            জরুরি পরামর্শ:
          </p>
          <p>
            “অনুগ্রহ করে <strong>কল বা ভয়েস মেসেজ না দিয়ে SMS/WhatsApp Text Message</strong>-এর মাধ্যমে যোগাযোগ করুন।”
          </p>
          <p className="text-xs text-amber-800">
            লিখিতভাবে মেসেজ পাঠালে আপনার তথ্যের সত্যতা যাচাই এবং নির্ভুল সেবা দ্রুত প্রদান করা সম্ভব হয়।
          </p>
        </div>

        {/* Priority Action Options */}
        <div className="space-y-2.5 pt-1">
          {/* WhatsApp Text */}
          <a
            id="modal-prefer-whatsapp"
            href={operator.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>WhatsApp-এ লিখিত মেসেজ পাঠান (সর্বোত্তম)</span>
          </a>

          {/* SMS Send */}
          <a
            id="modal-prefer-sms"
            href={`sms:${operator.phone}?body=${encodeURIComponent('আসসালামু আলাইকুম, ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ হেল্পডেস্কে তথ্য সহায়তা প্রয়োজন।')}`}
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            <MessageSquare className="w-4 h-4 text-sky-400" />
            <span>সরাসরি SMS করুন ({operator.phone})</span>
          </a>

          {/* Emergency Direct Call */}
          <a
            id="modal-emergency-call"
            href={`tel:${operator.phone}`}
            onClick={onClose}
            className="w-full py-2 px-4 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-600 text-xs font-semibold flex items-center justify-center gap-2 transition-colors mt-2"
          >
            <Phone className="w-3.5 h-3.5 text-slate-500" />
            <span>অত্যন্ত জরুরি প্রয়োজনে কল করুন ({operator.phone})</span>
          </a>
        </div>
      </div>
    </div>
  );
};
