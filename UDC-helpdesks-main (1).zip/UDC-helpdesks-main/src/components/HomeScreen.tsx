import React from 'react';
import { WelcomeBanner } from './WelcomeBanner';
import { OperatorContactCard } from './OperatorContactCard';
import { QuickActionButtons } from './QuickActionButtons';
import { QuickServiceMenu } from './QuickServiceMenu';
import { ReportNumberSection } from './ReportNumberSection';
import { ContactDirectoryPreview } from './ContactDirectoryPreview';
import { QrCodeSection } from './QrCodeSection';
import { ServiceItem, OperatorProfile } from '../types';

interface HomeScreenProps {
  operator: OperatorProfile;
  services: ServiceItem[];
  onNavigateAiChat: (service?: ServiceItem | null, query?: string) => void;
  onNavigateContactDirectory: () => void;
  onUpdateOperator: (updated: Partial<OperatorProfile>) => Promise<void>;
  showOperatorEditModal: boolean;
  setShowOperatorEditModal: (show: boolean) => void;
  onCallWarningModal: () => void;
  onSelectServiceModal: (service: ServiceItem) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  operator,
  services,
  onNavigateAiChat,
  onNavigateContactDirectory,
  onUpdateOperator,
  showOperatorEditModal,
  setShowOperatorEditModal,
  onCallWarningModal,
  onSelectServiceModal,
}) => {
  return (
    <div className="space-y-6">
      {/* 1. Welcome Banner */}
      <WelcomeBanner
        onStartChat={() => onNavigateAiChat(null)}
        whatsappUrl={operator.whatsappUrl}
      />

      {/* 2. Operator Contact Card (Positioned as in prototype layout) */}
      <OperatorContactCard
        operator={operator}
        onUpdateOperator={onUpdateOperator}
        showEditModal={showOperatorEditModal}
        setShowEditModal={setShowOperatorEditModal}
        onCallWarningModal={onCallWarningModal}
      />

      {/* 3. Quick Action Buttons (AI, WhatsApp, SMS, Call, Email, Facebook) */}
      <QuickActionButtons
        operator={operator}
        onOpenChat={() => onNavigateAiChat(null)}
        onCallModal={onCallWarningModal}
      />

      {/* 4. Quick Service Menu (Birth, Death, Citizen certs, etc. On click -> navigate to AiChat or modal) */}
      <QuickServiceMenu
        services={services}
        onSelectService={onSelectServiceModal}
        onAskAiWithContext={(srv, q) => onNavigateAiChat(srv, q)}
      />

      {/* 5. Report Number Input Section (matching wireframe 5) */}
      <ReportNumberSection
        onAnalyzeReport={(reportNo) => {
          onNavigateAiChat(null, `আমার রিপোর্ট নং ${reportNo}। আমার পূর্বের সমস্যা এবং পরবর্তী করণীয় কি?`);
        }}
      />

      {/* 6. Contact Directory Preview (with "View Full Directory" -> navigate to ContactDirectoryScreen) */}
      <ContactDirectoryPreview
        onViewFullDirectory={onNavigateContactDirectory}
      />

      {/* 7. QR Code Section */}
      <QrCodeSection />
    </div>
  );
};
