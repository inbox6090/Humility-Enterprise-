import React, { useState, useEffect } from 'react';
import { 
  X, 
  Ticket, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw, 
  Copy, 
  Check, 
  Search, 
  Filter,
  Phone,
  MessageCircle,
  Clock,
  ShieldAlert
} from 'lucide-react';
import { TicketItem, EscalationItem } from '../types';

interface TicketEscalationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TicketEscalationModal: React.FC<TicketEscalationModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'tickets' | 'escalations'>('tickets');
  const [tickets, setTickets] = useState<TicketItem[]>([]);
  const [escalations, setEscalations] = useState<EscalationItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const fetchTicketsAndEscalations = async () => {
    setIsLoading(true);
    try {
      const [ticketRes, escRes] = await Promise.all([
        fetch('/api/tickets'),
        fetch('/api/escalations')
      ]);
      if (ticketRes.ok) {
        const ticketData = await ticketRes.json();
        setTickets(ticketData.tickets || []);
      }
      if (escRes.ok) {
        const escData = await escRes.json();
        setEscalations(escData.escalations || []);
      }
    } catch (err) {
      console.error('Failed to fetch tickets/escalations:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchTicketsAndEscalations();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleMarkEscalationHandled = async (id: string) => {
    try {
      const res = await fetch(`/api/escalations/${id}/handle`, { method: 'POST' });
      if (res.ok) {
        setEscalations(prev => prev.map(e => e.id === id ? { ...e, handled: 'হ্যাঁ' } : e));
      }
    } catch (err) {
      console.error('Failed to handle escalation:', err);
    }
  };

  const filteredTickets = tickets.filter(t => 
    t.ticketId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.phone.includes(searchQuery) ||
    t.category.includes(searchQuery) ||
    t.summary.includes(searchQuery)
  );

  const filteredEscalations = escalations.filter(e => 
    e.phone.includes(searchQuery) ||
    e.userMessage.includes(searchQuery)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-[#0c1e36] to-[#1a3860] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
              <Ticket className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">লাইভ টিকেট ও এসকেলেশন ট্র্যাকার</h3>
              <p className="text-xs text-slate-300">
                WhatsApp, কল-লগ ও ওয়েব চ্যাটবট থেকে স্বয়ংক্রিয়ভাবে সংরক্ষিত ডাটাবেজ
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchTicketsAndEscalations}
              disabled={isLoading}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg text-xs flex items-center gap-1 transition-colors"
              title="রিফ্রেশ করুন"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">রিফ্রেশ</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab & Search Bar */}
        <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 bg-slate-200/70 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('tickets')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'tickets'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Ticket className="w-3.5 h-3.5 text-emerald-600" />
              <span>অভিযোগ ও পরামর্শ টিকেট ({tickets.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('escalations')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'escalations'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>এসকেলেশন কিউ ({escalations.filter(e => e.handled === 'না').length} পেন্ডিং)</span>
            </button>
          </div>

          <div className="relative flex-1 max-w-xs">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="টিকেট নং, ফোন বা বিষয়..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500 text-slate-800"
            />
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 bg-slate-100/60">
          {activeTab === 'tickets' ? (
            filteredTickets.length === 0 ? (
              <div className="py-12 text-center text-slate-500">
                <Ticket className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                <p className="text-sm font-semibold">কোনো টিকেট পাওয়া যায়নি</p>
                <p className="text-xs text-slate-400 mt-1">চ্যাটে অভিযোগ বা পরামর্শ দিলে স্বয়ংক্রিয়ভাবে টিকেট তৈরি হবে।</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {filteredTickets.map((item) => (
                  <div 
                    key={item.ticketId}
                    className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-xs font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                            {item.ticketId}
                          </span>
                          <button
                            onClick={() => handleCopy(item.ticketId, item.ticketId)}
                            className="text-slate-400 hover:text-slate-700 p-1 rounded"
                            title="টিকেট আইডি কপি করুন"
                          >
                            {copiedId === item.ticketId ? (
                              <Check className="w-3 h-3 text-emerald-600" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                        <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${
                          item.status === 'গৃহীত' 
                            ? 'bg-amber-100 text-amber-800 border border-amber-200'
                            : item.status === 'প্রক্রিয়াধীন'
                            ? 'bg-blue-100 text-blue-800 border border-blue-200'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        }`}>
                          {item.status}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                        <span className="bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded text-[11px] font-medium">
                          {item.intent === 'complaint' ? '📋 অভিযোগ' : '💡 পরামর্শ'}
                        </span>
                        <span className="bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded text-[11px] font-medium">
                          {item.category}
                        </span>
                        <span className="text-[11px] flex items-center gap-1 text-slate-400">
                          <Clock className="w-3 h-3" />
                          {item.timestamp}
                        </span>
                      </div>

                      <p className="text-xs text-slate-700 leading-relaxed bg-slate-50/70 p-2.5 rounded-lg border border-slate-100 mb-2 font-sans">
                        {item.summary}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                      <span className="flex items-center gap-1 font-mono">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {item.phone}
                      </span>
                      <span className="capitalize text-slate-400">চ্যানেল: {item.channel}</span>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : (
            filteredEscalations.length === 0 ? (
              <div className="py-12 text-center text-slate-500">
                <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-400 mb-2" />
                <p className="text-sm font-semibold">কোনো এসকেলেশন পেন্ডিং নেই</p>
                <p className="text-xs text-slate-400 mt-1">সব নাগরিক প্রশ্নের উত্তর সফলভাবে দেওয়া হয়েছে।</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredEscalations.map((esc) => (
                  <div
                    key={esc.id}
                    className={`bg-white rounded-xl border p-4 shadow-2xs transition-all ${
                      esc.handled === 'হ্যাঁ'
                        ? 'border-slate-200 opacity-75'
                        : 'border-amber-300 bg-amber-50/20'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex items-center gap-2">
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                          esc.handled === 'হ্যাঁ'
                            ? 'bg-slate-100 text-slate-700'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {esc.handled === 'হ্যাঁ' ? '✅ হ্যান্ডেল করা হয়েছে' : '⚠️ স্টাফ মনোযোগ প্রয়োজন'}
                        </span>
                        <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          {esc.timestamp}
                        </span>
                      </div>

                      {esc.handled !== 'হ্যাঁ' && (
                        <button
                          onClick={() => handleMarkEscalationHandled(esc.id)}
                          className="px-2.5 py-1 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-lg shadow-2xs transition-colors flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>সমাধান হিসেবে চিহ্নিত করুন</span>
                        </button>
                      )}
                    </div>

                    <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs text-slate-800 mb-2">
                      <strong className="text-slate-900 block mb-1">নাগরিকের বার্তা:</strong>
                      "{esc.userMessage}"
                    </div>

                    <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-500 gap-2">
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1 font-mono">
                          <Phone className="w-3 h-3 text-slate-400" />
                          {esc.phone}
                        </span>
                        <span>চ্যানেল: {esc.channel}</span>
                        {esc.reason && <span className="text-amber-700 font-medium">কারণ: {esc.reason}</span>}
                      </div>
                      <span className="font-medium text-slate-600">
                        কনফিডেন্স স্কোর: {(esc.confidence_score * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
          <span>০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল হেল্পডেস্ক</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 font-medium text-xs transition-colors"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
