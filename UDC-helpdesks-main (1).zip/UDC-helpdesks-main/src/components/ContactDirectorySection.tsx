import React, { useState } from 'react';
import { 
  Users, 
  Building2, 
  MessageCircle, 
  Phone, 
  Copy, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  ShieldCheck, 
  UserCheck, 
  ExternalLink,
  Code2,
  Send,
  Sparkles
} from 'lucide-react';
import { ContactDirectorySchema, ContactPerson } from '../types';
import { CONTACT_DIRECTORY_DATA } from '../data/knowledgeBase';

interface ContactDirectorySectionProps {
  onAskAiWithContext?: (query: string) => void;
}

export const ContactDirectorySection: React.FC<ContactDirectorySectionProps> = ({
  onAskAiWithContext
}) => {
  const [activeFormat, setActiveFormat] = useState<'hierarchy' | 'whatsapp' | 'json'>('hierarchy');
  const [selectedRoleCategory, setSelectedRoleCategory] = useState<string>('all');
  const [expandedSection, setExpandedSection] = useState<string | null>('leaders');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const data: ContactDirectorySchema = CONTACT_DIRECTORY_DATA;

  // Copy helper
  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2500);
  };

  // WhatsApp Conversation text formatted
  const whatsappConversationText = `[বহেড়াতৈল ইউনিয়ন পরিষদ হেল্পডেস্ক]
নাগরিক: আসসালামু আলাইকুম, ইউনিয়ন পরিষদের দায়িত্বপ্রাপ্ত কর্মকর্তা ও জনপ্রতিনিধিদের যোগাযোগ নম্বর প্রয়োজন।

UDC উদ্যোক্তা: ওয়ালাইকুম আসসালাম! ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের অফিসিয়াল পরিচিতি ও যোগাযোগ তালিকা নিচে দেওয়া হলো:

🏛️ মূল নেতৃত্ব ও প্রশাসন:
• চেয়ারম্যান/প্রশাসক: ${data.chairman.name} | মোবাইল: ${data.chairman.mobile}
• ইউপি সচিব: ${data.secretary.name} | মোবাইল: ${data.secretary.mobile}
• UDC উদ্যোক্তা: ${data.udc_operator.name} | মোবাইল: ${data.udc_operator.mobile} (WhatsApp)
• হিসাব সহকারী: ${data.admin_officer.name} | মোবাইল: ${data.admin_officer.mobile}

👥 সাধারণ ওয়ার্ড সদস্যবৃন্দ (১–৯নং ওয়ার্ড):
${data.members.map(m => `• ${m.ward}: ${m.name} | মোবাইল: ${m.mobile}`).join('\n')}

🌸 সংরক্ষিত মহিলা সদস্যবৃন্দ:
${data.reserved_female_members.map(r => `• ${r.name} (${r.ward}): মোবাইল: ${r.mobile}`).join('\n')}

🛡️ গ্রাম পুলিশ:
${data.village_police.map(v => `• ${v.role}: ${v.name} | মোবাইল: ${v.mobile}`).join('\n')}

💬 আপনি যাকে প্রয়োজন মনে করেন, তাকে লিখিত মেসেজ পাঠিয়ে যোগাযোগ করতে পারেন। ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্কে আপনাকে ধন্যবাদ!`;

  return (
    <section id="contact-directory-section" className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden mb-8">
      {/* Header Banner */}
      <div className="bg-[#0c1e36] text-white p-5 sm:p-6 border-b border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-semibold mb-2">
              <Users className="w-3.5 h-3.5" />
              <span>কর্মকর্তা ও জনপ্রতিনিধি ডিরেক্টরি</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
              <span>অফিসিয়াল কন্টাক্ট ডিরেক্টরি</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl leading-relaxed">
              ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের সকল কর্মকর্তা, ইউডিসি উদ্যোক্তা, ওয়ার্ড সদস্য ও গ্রাম পুলিশের অফিসিয়াল পরিচিতি ও যোগাযোগ মাধ্যম।
            </p>
          </div>

          {/* Quick Format Switcher Tabs */}
          <div className="flex bg-slate-900/80 p-1 rounded-xl border border-slate-700/80 self-start sm:self-center">
            <button
              id="dir-tab-hierarchy"
              onClick={() => setActiveFormat('hierarchy')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeFormat === 'hierarchy'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>১. অফিসিয়াল হায়ারার্কি</span>
            </button>

            <button
              id="dir-tab-whatsapp"
              onClick={() => setActiveFormat('whatsapp')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeFormat === 'whatsapp'
                  ? 'bg-[#25D366] text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>২. WhatsApp ভিউ</span>
            </button>

            <button
              id="dir-tab-json"
              onClick={() => setActiveFormat('json')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeFormat === 'json'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>৩. JSON ডাটা</span>
            </button>
          </div>
        </div>
      </div>

      {/* FORMAT 1: Official Hierarchy View */}
      {activeFormat === 'hierarchy' && (
        <div className="p-4 sm:p-6 space-y-6">
          {/* Guided Action Badges / Filter Bar */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80">
            <p className="text-xs font-semibold text-slate-600 mb-2">
              দ্রুত অনুসন্ধান ফিল্টার (Quick Category Filter):
            </p>
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'all', label: 'সকল পদবী' },
                { id: 'leadership', label: 'চেয়ারম্যান ও সচিব' },
                { id: 'udc', label: 'UDC অপারেটর' },
                { id: 'members', label: '১–৯নং ওয়ার্ড মেম্বার' },
                { id: 'female_members', label: 'সংরক্ষিত নারী সদস্য' },
                { id: 'police', label: 'গ্রাম পুলিশ' },
                { id: 'admin', label: 'প্রশাসনিক কর্মকর্তা' },
              ].map((btn) => (
                <button
                  key={btn.id}
                  id={`filter-btn-${btn.id}`}
                  onClick={() => setSelectedRoleCategory(btn.id)}
                  className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                    selectedRoleCategory === btn.id
                      ? 'bg-[#0c1e36] text-white shadow-sm'
                      : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          {/* Section: Main Leadership & Administration */}
          {(selectedRoleCategory === 'all' || selectedRoleCategory === 'leadership' || selectedRoleCategory === 'udc' || selectedRoleCategory === 'admin') && (
            <div className="space-y-3">
              <div 
                className="flex items-center justify-between cursor-pointer border-b border-slate-200 pb-2"
                onClick={() => setExpandedSection(expandedSection === 'leaders' ? null : 'leaders')}
              >
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                  পরিষদ নেতৃত্ব ও ডিজিটাল সেবা কাউন্টার
                </h3>
                {expandedSection === 'leaders' ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
              </div>

              {(expandedSection === 'leaders' || selectedRoleCategory !== 'all') && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {/* Chairman */}
                  {(selectedRoleCategory === 'all' || selectedRoleCategory === 'leadership') && (
                    <div className="p-4 rounded-xl border border-slate-200 bg-gradient-to-br from-slate-50 to-white shadow-sm flex flex-col justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                            প্রশাসনিক শীর্ষ পদ
                          </span>
                          <span className="text-[11px] text-slate-500">{data.chairman.ward}</span>
                        </div>
                        <h4 className="font-bold text-slate-900 text-base">{data.chairman.role}</h4>
                        <p className="text-xs text-slate-600 font-medium">{data.chairman.name}</p>
                        <p className="text-xs text-slate-500 leading-relaxed pt-1">
                          <strong>দায়িত্ব:</strong> {data.chairman.duty}
                        </p>
                      </div>

                      <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                        <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded text-slate-700">
                          {data.chairman.mobile}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleCopy(data.chairman.mobile, 'chairman-copy')}
                            className="px-2.5 py-1 text-xs rounded bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center gap-1"
                            title="নম্বর কপি করুন"
                          >
                            {copiedText === 'chairman-copy' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>কপি</span>
                          </button>
                          <a
                            href={data.chairman.whatsapp}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-1 text-xs rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 flex items-center gap-1"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                            <span>WhatsApp</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Secretary */}
                  {(selectedRoleCategory === 'all' || selectedRoleCategory === 'leadership') && (
                    <div className="p-4 rounded-xl border border-slate-200 bg-gradient-to-br from-slate-50 to-white shadow-sm flex flex-col justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-300">
                            প্রশাসনিক কর্মকর্তা
                          </span>
                          <span className="text-[11px] text-slate-500">{data.secretary.ward}</span>
                        </div>
                        <h4 className="font-bold text-slate-900 text-base">{data.secretary.role}</h4>
                        <p className="text-xs text-slate-600 font-medium">{data.secretary.name}</p>
                        <p className="text-xs text-slate-500 leading-relaxed pt-1">
                          <strong>দায়িত্ব:</strong> {data.secretary.duty}
                        </p>
                      </div>

                      <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                        <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded text-slate-700">
                          {data.secretary.mobile}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleCopy(data.secretary.mobile, 'secretary-copy')}
                            className="px-2.5 py-1 text-xs rounded bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center gap-1"
                          >
                            {copiedText === 'secretary-copy' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>কপি</span>
                          </button>
                          <a
                            href={data.secretary.whatsapp}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-1 text-xs rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 flex items-center gap-1"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                            <span>WhatsApp</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* UDC Operator - Verified */}
                  {(selectedRoleCategory === 'all' || selectedRoleCategory === 'udc') && (
                    <div className="p-4 rounded-xl border-2 border-emerald-500/40 bg-emerald-50/40 shadow-sm flex flex-col justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-600 text-white flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3" />
                            যাচাইকৃত হেল্পডেস্ক
                          </span>
                          <span className="text-[11px] text-emerald-800 font-semibold">{data.udc_operator.ward}</span>
                        </div>
                        <h4 className="font-bold text-slate-900 text-base">{data.udc_operator.role}</h4>
                        <p className="text-xs text-slate-700 font-bold">{data.udc_operator.name}</p>
                        <p className="text-xs text-slate-600 leading-relaxed pt-1">
                          <strong>দায়িত্ব:</strong> {data.udc_operator.duty}
                        </p>
                      </div>

                      <div className="pt-3 mt-3 border-t border-emerald-200/80 flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs font-mono font-bold bg-white px-2 py-1 rounded text-emerald-900 border border-emerald-300">
                          {data.udc_operator.mobile}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleCopy(data.udc_operator.mobile, 'udc-copy')}
                            className="px-2.5 py-1 text-xs rounded bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 flex items-center gap-1"
                          >
                            {copiedText === 'udc-copy' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>কপি</span>
                          </button>
                          <a
                            href={data.udc_operator.whatsapp}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-1 text-xs rounded bg-[#25D366] text-white hover:bg-[#20ba59] font-semibold flex items-center gap-1 shadow-sm"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>WhatsApp চ্যাট</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Administrative Officer */}
                  {(selectedRoleCategory === 'all' || selectedRoleCategory === 'admin') && (
                    <div className="p-4 rounded-xl border border-slate-200 bg-gradient-to-br from-slate-50 to-white shadow-sm flex flex-col justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-800">
                            হিসাব ও ডাটা এন্ট্রি
                          </span>
                          <span className="text-[11px] text-slate-500">{data.admin_officer.ward}</span>
                        </div>
                        <h4 className="font-bold text-slate-900 text-base">{data.admin_officer.role}</h4>
                        <p className="text-xs text-slate-600 font-medium">{data.admin_officer.name}</p>
                        <p className="text-xs text-slate-500 leading-relaxed pt-1">
                          <strong>দায়িত্ব:</strong> {data.admin_officer.duty}
                        </p>
                      </div>

                      <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                        <span className="text-xs font-mono bg-slate-100 px-2 py-1 rounded text-slate-700">
                          {data.admin_officer.mobile}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => handleCopy(data.admin_officer.mobile, 'admin-copy')}
                            className="px-2.5 py-1 text-xs rounded bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center gap-1"
                          >
                            {copiedText === 'admin-copy' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>কপি</span>
                          </button>
                          <a
                            href={data.admin_officer.whatsapp}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-2.5 py-1 text-xs rounded bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 flex items-center gap-1"
                          >
                            <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                            <span>WhatsApp</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Section: 1-9 Ward Members */}
          {(selectedRoleCategory === 'all' || selectedRoleCategory === 'members') && (
            <div className="space-y-3">
              <div 
                className="flex items-center justify-between cursor-pointer border-b border-slate-200 pb-2"
                onClick={() => setExpandedSection(expandedSection === 'members' ? null : 'members')}
              >
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                  ১নং থেকে ৯নং সাধারণ ওয়ার্ড মেম্বারবৃন্দ
                </h3>
                {expandedSection === 'members' ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
              </div>

              {(expandedSection === 'members' || selectedRoleCategory === 'members') && (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {data.members.map((member, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-emerald-300 transition-all shadow-xs flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            {member.ward}
                          </span>
                        </div>
                        <h5 className="font-bold text-slate-900 text-sm">{member.name}</h5>
                        <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                          <strong>দায়িত্ব:</strong> {member.duty}
                        </p>
                      </div>

                      <div className="pt-2.5 mt-2.5 border-t border-slate-100 flex items-center justify-between gap-1">
                        <span className="text-[11px] font-mono bg-slate-50 px-1.5 py-0.5 rounded text-slate-600">
                          {member.mobile}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleCopy(member.mobile, `member-${idx}`)}
                            className="p-1 text-slate-500 hover:text-slate-800 rounded hover:bg-slate-100"
                            title="কপি করুন"
                          >
                            {copiedText === `member-${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                          <a
                            href={member.whatsapp}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="WhatsApp"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Section: Reserved Female Members */}
          {(selectedRoleCategory === 'all' || selectedRoleCategory === 'female_members') && (
            <div className="space-y-3">
              <div 
                className="flex items-center justify-between cursor-pointer border-b border-slate-200 pb-2"
                onClick={() => setExpandedSection(expandedSection === 'female' ? null : 'female')}
              >
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-purple-600"></span>
                  সংরক্ষিত মহিলা সদস্যবৃন্দ (৩ আসন)
                </h3>
                {expandedSection === 'female' ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
              </div>

              {(expandedSection === 'female' || selectedRoleCategory === 'female_members') && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {data.reserved_female_members.map((member, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-purple-50/30 hover:border-purple-300 transition-all shadow-xs flex flex-col justify-between">
                      <div>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 block w-fit mb-1">
                          {member.ward}
                        </span>
                        <h5 className="font-bold text-slate-900 text-sm">{member.name}</h5>
                        <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                          <strong>দায়িত্ব:</strong> {member.duty}
                        </p>
                      </div>

                      <div className="pt-2.5 mt-2.5 border-t border-purple-100 flex items-center justify-between gap-1">
                        <span className="text-[11px] font-mono bg-white px-1.5 py-0.5 rounded text-slate-600 border border-purple-200">
                          {member.mobile}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleCopy(member.mobile, `female-${idx}`)}
                            className="p-1 text-slate-500 hover:text-slate-800 rounded hover:bg-purple-100"
                            title="কপি করুন"
                          >
                            {copiedText === `female-${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                          <a
                            href={member.whatsapp}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Section: Village Police */}
          {(selectedRoleCategory === 'all' || selectedRoleCategory === 'police') && (
            <div className="space-y-3">
              <div 
                className="flex items-center justify-between cursor-pointer border-b border-slate-200 pb-2"
                onClick={() => setExpandedSection(expandedSection === 'police' ? null : 'police')}
              >
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-slate-700"></span>
                  গ্রাম পুলিশ বাহিনী (দফাদার ও মহল্লাদার)
                </h3>
                {expandedSection === 'police' ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
              </div>

              {(expandedSection === 'police' || selectedRoleCategory === 'police') && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {data.village_police.map((police, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:border-slate-400 transition-all shadow-xs flex flex-col justify-between">
                      <div>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-800 block w-fit mb-1">
                          {police.role}
                        </span>
                        <h5 className="font-bold text-slate-900 text-sm">{police.name}</h5>
                        <p className="text-[11px] text-slate-600 mt-1 leading-snug">
                          <strong>দায়িত্ব:</strong> {police.duty}
                        </p>
                      </div>

                      <div className="pt-2.5 mt-2.5 border-t border-slate-200 flex items-center justify-between gap-1">
                        <span className="text-[11px] font-mono bg-white px-1.5 py-0.5 rounded text-slate-600 border border-slate-300">
                          {police.mobile}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleCopy(police.mobile, `police-${idx}`)}
                            className="p-1 text-slate-500 hover:text-slate-800 rounded hover:bg-slate-200"
                          >
                            {copiedText === `police-${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                          <a
                            href={police.whatsapp}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Direct AI Assistance for Contact */}
          {onAskAiWithContext && (
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-slate-700">
                <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>কার কাছে কোন সেবার প্রত্যয়ন বা সাক্ষর প্রয়োজন তা জানতে AI সহকারীকে প্রশ্ন করুন।</span>
              </div>
              <button
                onClick={() => onAskAiWithContext('কোন সেবার জন্য কার কাছে যেতে হবে বা কার সুপারিশ প্রয়োজন?')}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shrink-0"
              >
                পরামর্শ নিন
              </button>
            </div>
          )}
        </div>
      )}

      {/* FORMAT 2: WhatsApp Conversation View */}
      {activeFormat === 'whatsapp' && (
        <div className="p-4 sm:p-6 bg-[#efeae2]/50 space-y-4">
          <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-slate-200">
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-800 flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                WhatsApp চ্যাট ভিউ (Citizen & Operator Conversation)
              </h4>
              <p className="text-[11px] text-slate-500">
                নাগরিকের অনুরোধে ডিরেক্টরি প্রদর্শনের অফিসিয়াল ফরম্যাট।
              </p>
            </div>
            <button
              id="copy-whatsapp-text-btn"
              onClick={() => handleCopy(whatsappConversationText, 'wa-full')}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5 shadow-sm transition-all"
            >
              {copiedText === 'wa-full' ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
              <span>{copiedText === 'wa-full' ? 'কপি হয়েছে!' : 'কনভারসেশন কপি করুন'}</span>
            </button>
          </div>

          {/* WhatsApp UI Simulation Box */}
          <div className="max-w-2xl mx-auto bg-[#efeae2] p-4 rounded-2xl border border-slate-300 shadow-inner space-y-3 font-sans text-xs sm:text-sm">
            {/* User Message Bubble */}
            <div className="flex justify-end">
              <div className="bg-[#d9fdd3] text-slate-800 p-3 rounded-2xl rounded-tr-xs shadow-xs max-w-[85%] space-y-1">
                <p>আসসালামু আলাইকুম। ইউনিয়ন পরিষদের কর্মকর্তাদের যোগাযোগ নম্বর চাই।</p>
                <div className="text-[10px] text-slate-400 text-right">১০:১৫ AM ✓✓</div>
              </div>
            </div>

            {/* Operator Response Bubble */}
            <div className="flex justify-start">
              <div className="bg-white text-slate-800 p-3.5 sm:p-4 rounded-2xl rounded-tl-xs shadow-xs max-w-[95%] space-y-3 border border-slate-200">
                <div className="border-b border-slate-100 pb-2">
                  <span className="font-bold text-emerald-800 block text-xs">
                    UDC Operator (বহেড়াতৈল ইউনিয়ন পরিষদ):
                  </span>
                  <p className="text-xs text-slate-700 mt-0.5">
                    ওয়ালাইকুম আসসালাম! অবশ্যই, নিচে ইউনিয়ন পরিষদের কর্মকর্তাদের তালিকা দেওয়া হলো—
                  </p>
                </div>

                {/* Directory List Inside Message */}
                <div className="space-y-2 text-xs text-slate-800 bg-slate-50 p-3 rounded-xl border border-slate-200/80 font-mono">
                  <p className="font-bold text-slate-900 border-b pb-1 font-sans">
                    🏛️ অফিসিয়াল তালিকা:
                  </p>
                  <div className="space-y-1 text-[11px] sm:text-xs">
                    <p>• <strong>চেয়ারম্যান:</strong> {data.chairman.name} — {data.chairman.mobile}</p>
                    <p>• <strong>সচিব:</strong> {data.secretary.name} — {data.secretary.mobile}</p>
                    <p>• <strong>UDC অপারেটর:</strong> {data.udc_operator.name} — {data.udc_operator.mobile}</p>
                    <p>• <strong>হিসাব সহকারী:</strong> {data.admin_officer.name} — {data.admin_officer.mobile}</p>
                    <div className="pt-1.5 text-slate-600 font-sans">
                      <p className="font-bold text-slate-800">ওয়ার্ড মেম্বারগণ (১-৯নং):</p>
                      {data.members.slice(0, 3).map((m, i) => (
                        <p key={i} className="font-mono text-[11px]">• {m.ward}: {m.mobile}</p>
                      ))}
                      <p className="text-[10px] text-slate-500 italic">...অন্যান্য সকল ওয়ার্ড সদস্যের নম্বর সিস্টেমে সংরক্ষিত রয়েছে।</p>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-700 leading-relaxed font-sans">
                  "আপনি যাকে প্রয়োজন মনে করেন, তাকে WhatsApp-এ লিখে যোগাযোগ করতে পারেন।"
                </p>

                <div className="text-[10px] text-slate-400 text-right">১০:১৬ AM</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* FORMAT 3: Web App Contact Directory (UI-Ready JSON) */}
      {activeFormat === 'json' && (
        <div className="p-4 sm:p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-800 flex items-center gap-2">
                <Code2 className="w-4 h-4 text-blue-600" />
                ওয়েব অ্যাপ কন্টাক্ট ডিরেক্টরি (UI-Ready JSON Schema)
              </h4>
              <p className="text-[11px] text-slate-500">
                প্রকল্প স্পেসিফিকেশন অনুযায়ী কাঠামোগত JSON ডেটা — যা API বা ডাটাবেজের সাথে সরাসরি ইন্টিগ্রেশন উপযোগী।
              </p>
            </div>
            <button
              id="copy-json-btn"
              onClick={() => handleCopy(JSON.stringify(data, null, 2), 'json-full')}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-1.5 shadow-sm transition-all"
            >
              {copiedText === 'json-full' ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
              <span>{copiedText === 'json-full' ? 'কপি হয়েছে!' : 'JSON কপি করুন'}</span>
            </button>
          </div>

          <div className="relative bg-slate-900 rounded-xl p-4 overflow-x-auto text-slate-100 font-mono text-xs border border-slate-800 shadow-inner max-h-[480px]">
            <pre>{JSON.stringify(data, null, 2)}</pre>
          </div>
        </div>
      )}

      {/* Compliance Footer Note */}
      <div className="bg-slate-50 px-5 py-3 border-t border-slate-200 text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <p>
          🔒 <strong>সুরক্ষা নোট:</strong> ব্যক্তিগত মোবাইল নম্বর প্রকাশের পূর্বে সরকারি নির্দেশিকা মেনেই ডেটা প্রদর্শিত হয়।
        </p>
        <span className="text-emerald-700 font-medium">
          ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ হেল্পডেস্ক
        </span>
      </div>
    </section>
  );
};
