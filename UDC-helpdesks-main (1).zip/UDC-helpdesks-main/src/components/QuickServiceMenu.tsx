import React, { useState } from 'react';
import { 
  FileText, 
  Baby, 
  UserCheck, 
  Award, 
  HeartHandshake, 
  Users, 
  CheckSquare, 
  Search, 
  HelpCircle, 
  ChevronRight,
  Sparkles,
  Info,
  Clock,
  Banknote,
  Building
} from 'lucide-react';
import { ServiceItem } from '../types';
import { ServiceTipBanner } from './ServiceTipBanner';

interface QuickServiceMenuProps {
  services: ServiceItem[];
  onSelectService: (service: ServiceItem) => void;
  onAskAiWithContext: (service: ServiceItem, initialQuery?: string) => void;
}

export const QuickServiceMenu: React.FC<QuickServiceMenuProps> = ({
  services,
  onSelectService,
  onAskAiWithContext,
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Icon mapper for union parishad services
  const getServiceIcon = (id: string) => {
    switch (id) {
      case 'birth-reg':
        return <Baby className="w-5 h-5 text-blue-600" />;
      case 'death-reg':
        return <FileText className="w-5 h-5 text-slate-600" />;
      case 'citizen-cert':
        return <UserCheck className="w-5 h-5 text-emerald-600" />;
      case 'character-cert':
        return <Award className="w-5 h-5 text-amber-600" />;
      case 'unmarried-cert':
        return <Award className="w-5 h-5 text-purple-600" />;
      case 'warish-cert':
        return <Users className="w-5 h-5 text-rose-600" />;
      case 'attestation-cert':
        return <CheckSquare className="w-5 h-5 text-cyan-600" />;
      case 'social-welfare':
        return <HeartHandshake className="w-5 h-5 text-orange-600" />;
      case 'app-status':
        return <Search className="w-5 h-5 text-indigo-600" />;
      default:
        return <HelpCircle className="w-5 h-5 text-teal-600" />;
    }
  };

  const filteredServices = services.filter((service) => {
    const matchesCategory = filterCategory === 'all' || service.category === filterCategory;
    const matchesSearch = service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          service.shortDescription.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section className="mb-8">
      {/* Title & Filter Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 px-1">
        <div>
          <h3 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
            দ্রুত সেবা নির্বাচন করুন (Quick Service Menu)
          </h3>
          <p className="text-xs text-slate-500">
            প্রয়োজনীয় কাগজপত্র, ফি, সময়সীমা ও আবেদন নির্দেশিকা জানতে কার্ড নির্বাচন করুন
          </p>
        </div>

        {/* Search input for instant service lookup */}
        <div className="relative w-full sm:w-64">
          <input
            id="service-search-input"
            type="text"
            placeholder="সেবা খুঁজুন (যেমন: জন্ম নিবন্ধন)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2 top-2 text-xs text-slate-400 hover:text-slate-600"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3 scrollbar-none text-xs">
        <button
          onClick={() => setFilterCategory('all')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterCategory === 'all'
              ? 'bg-[#0c1e36] text-white shadow-sm'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          সকল সেবা ({services.length})
        </button>
        <button
          onClick={() => setFilterCategory('civil')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterCategory === 'civil'
              ? 'bg-[#0c1e36] text-white shadow-sm'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          জন্ম ও মৃত্যু নিবন্ধন
        </button>
        <button
          onClick={() => setFilterCategory('certificate')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterCategory === 'certificate'
              ? 'bg-[#0c1e36] text-white shadow-sm'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          সনদ ও প্রত্যয়ন
        </button>
        <button
          onClick={() => setFilterCategory('social_welfare')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterCategory === 'social_welfare'
              ? 'bg-[#0c1e36] text-white shadow-sm'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          ভাতা ও সামাজিক নিরাপত্তা
        </button>
        <button
          onClick={() => setFilterCategory('status')}
          className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
            filterCategory === 'status'
              ? 'bg-[#0c1e36] text-white shadow-sm'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          আবেদন স্ট্যাটাস
        </button>
      </div>

      {/* Dynamic Service Tip Banner to reduce application errors */}
      <ServiceTipBanner
        currentCategory={filterCategory}
        onAskAiPrompt={(promptText) => {
          // Find matching service context based on filterCategory or prompt
          const matched = services.find((s) => {
            if (filterCategory === 'civil') return s.id === 'birth-reg';
            if (filterCategory === 'certificate') return s.id === 'citizen-cert';
            if (filterCategory === 'social_welfare') return s.id === 'social-welfare';
            return s.id === 'birth-reg';
          }) || services[0];
          onAskAiWithContext(matched, promptText);
        }}
      />

      {/* Service Cards Grid - 10 Service Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filteredServices.map((service) => {
          return (
            <div
              key={service.id}
              id={`service-card-${service.id}`}
              className="bg-white rounded-xl border border-slate-200/90 hover:border-blue-400 p-4 shadow-sm hover:shadow-md transition-all flex flex-col justify-between group"
            >
              <div>
                {/* Header of card */}
                <div className="flex items-start justify-between gap-2 mb-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-center shrink-0 group-hover:bg-blue-50 group-hover:border-blue-200 transition-colors">
                      {getServiceIcon(service.id)}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-800 leading-snug group-hover:text-blue-700 transition-colors">
                        {service.name}
                      </h4>
                      <span className="text-[11px] text-slate-500 flex items-center gap-1">
                        <Building className="w-3 h-3 text-slate-400" />
                        {service.counter.split(' ')[0]} কাউন্টার
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                    {service.fee.includes('বিনামূল্যে') ? 'বিনামূল্যে' : 'সরকারি ফি'}
                  </span>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-600 line-clamp-2 mb-3 leading-relaxed">
                  {service.shortDescription}
                </p>

                {/* Quick Info Badges */}
                <div className="space-y-1 text-[11px] text-slate-500 mb-3 bg-slate-50 p-2 rounded-lg border border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 text-slate-600">
                      <Clock className="w-3 h-3 text-slate-400" /> সময়:
                    </span>
                    <span className="font-medium text-slate-700">{service.processingTime}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 text-slate-600">
                      <Banknote className="w-3 h-3 text-slate-400" /> সরকারি ফি:
                    </span>
                    <span className="font-medium text-emerald-700 truncate max-w-[170px]" title={service.fee}>
                      {service.fee}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                <button
                  id={`btn-view-${service.id}`}
                  onClick={() => onSelectService(service)}
                  className="flex-1 py-1.5 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                >
                  <Info className="w-3.5 h-3.5 text-slate-600" />
                  <span>কাগজপত্র ও নিয়ম</span>
                </button>

                <button
                  id={`btn-ask-ai-${service.id}`}
                  onClick={() => onAskAiWithContext(service)}
                  className="py-1.5 px-3 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-800 text-xs font-semibold flex items-center justify-center gap-1 border border-emerald-400/40 transition-colors"
                  title="AI সহকারীকে প্রশ্ন করুন"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>AI প্রশ্ন</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredServices.length === 0 && (
        <div className="text-center py-10 bg-white rounded-xl border border-slate-200 p-6">
          <p className="text-sm font-medium text-slate-600">কোনো সেবা পাওয়া যায়নি।</p>
          <p className="text-xs text-slate-400 mt-1">অনুগ্রহ করে বানান যাচাই করুন অথবা AI সহকারীর কাছে প্রশ্ন করুন।</p>
        </div>
      )}
    </section>
  );
};
