import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Users, 
  Building2, 
  MessageCircle, 
  Phone, 
  Copy, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  ShieldCheck, 
  UserCheck, 
  Code2, 
  ExternalLink,
  Sparkles,
  Share2
} from 'lucide-react';
import { CONTACT_DIRECTORY_DATA } from '../data/knowledgeBase';
import { ContactDirectorySchema } from '../types';

interface ContactDirectoryScreenProps {
  onBackToHome: () => void;
  onAskAiWithContext: (query: string) => void;
}

export const ContactDirectoryScreen: React.FC<ContactDirectoryScreenProps> = ({
  onBackToHome,
  onAskAiWithContext
}) => {
  const [activeTab, setActiveTab] = useState<'hierarchy' | 'whatsapp' | 'json'>('hierarchy');
  const [selectedRole, setSelectedRole] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const data: ContactDirectorySchema = CONTACT_DIRECTORY_DATA;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  // 7 Explicit Role Buttons as requested in prototype
  const roleButtons = [
    { id: 'all', label: 'সকল' },
    { id: 'chairman', label: 'চেয়ারম্যান' },
    { id: 'secretary', label: 'সচিব' },
    { id: 'udc', label: 'UDC অপারেটর' },
    { id: 'members', label: 'মেম্বার তালিকা' },
    { id: 'female_members', label: 'সংরক্ষিত মহিলা সদস্য' },
    { id: 'police', label: 'গ্রাম পুলিশ' },
    { id: 'admin', label: 'প্রশাসনিক কর্মকর্তা' },
  ];

  // WhatsApp Conversation text formatted matching prototype 4B
  const whatsappConversationText = `UDC Operator: আসসালামু আলাইকুম, কিভাবে সাহায্য করতে পারি?
Citizen: কর্মকর্তাদের WhatsApp নম্বর চাই।
UDC Operator: অবশ্যই, নিচে ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের তালিকা—

[চেয়ারম্যান] ${data.chairman.name}: ${data.chairman.mobile}
[সচিব] ${data.secretary.name}: ${data.secretary.mobile}
[UDC উদ্যোক্তা] ${data.udc_operator.name}: ${data.udc_operator.mobile}
[হিসাব সহকারী] ${data.admin_officer.name}: ${data.admin_officer.mobile}

[মেম্বারবৃন্দ]:
${data.members.map(m => `• ${m.ward}: ${m.name} (${m.mobile})`).join('\n')}

[সংরক্ষিত মহিলা সদস্য]:
${data.reserved_female_members.map(f => `• ${f.ward}: ${f.name} (${f.mobile})`).join('\n')}

[গ্রাম পুলিশ]:
${data.village_police.map(p => `• ${p.role}: ${p.name} (${p.mobile})`).join('\n')}`;

  return (
    <div className="space-y-6">
      {/* Top Navigation & Header Bar */}
      <div className="bg-[#0c1e36] text-white p-4 sm:p-6 rounded-2xl border border-slate-800 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              id="dir-back-to-home-btn"
              onClick={onBackToHome}
              className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all flex items-center gap-1.5 text-xs font-bold active:scale-95"
              title="হোম স্ক্রিনে ফিরে যান"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>হোম</span>
            </button>

            <div>
              <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-[10px] font-semibold">
                <Users className="w-3 h-3" />
                <span>ContactDirectoryScreen</span>
              </div>
              <h1 className="text-lg sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2 mt-0.5">
                <span>অফিসিয়াল কন্টাক্ট ডিরেক্টরি</span>
              </h1>
              <p className="text-xs text-slate-300">
                ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের সকল দায়িত্বপ্রাপ্ত ব্যক্তি ও প্রতিনিধিবৃন্দ
              </p>
            </div>
          </div>

          {/* View Format Switcher */}
          <div className="flex bg-slate-900/90 p-1 rounded-xl border border-slate-700 self-start sm:self-center">
            <button
              id="dir-screen-tab-hierarchy"
              onClick={() => setActiveTab('hierarchy')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'hierarchy'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Official Hierarchy</span>
            </button>

            <button
              id="dir-screen-tab-whatsapp"
              onClick={() => setActiveTab('whatsapp')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'whatsapp'
                  ? 'bg-[#25D366] text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp View</span>
            </button>

            <button
              id="dir-screen-tab-json"
              onClick={() => setActiveTab('json')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                activeTab === 'json'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>JSON View</span>
            </button>
          </div>
        </div>
      </div>

      {/* VIEW 1: OFFICIAL HIERARCHY */}
      {activeTab === 'hierarchy' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-6">
          {/* Section title & 7 Role Buttons as requested in prototype */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                <span>Section: Official Hierarchy (পদবী অনুযায়ী ফিল্টার)</span>
              </h2>
              <span className="text-xs text-slate-500">পদবী সিলেক্ট করুন</span>
            </div>

            {/* RoleButton Component Group */}
            <div className="flex flex-wrap gap-2 pt-1 pb-3 border-b border-slate-100">
              {roleButtons.map((role) => (
                <button
                  key={role.id}
                  id={`role-btn-${role.id}`}
                  onClick={() => setSelectedRole(role.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 ${
                    selectedRole === role.id
                      ? 'bg-[#0c1e36] text-white ring-2 ring-emerald-500 ring-offset-1'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>{role.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Cards Grid */}
          <div className="space-y-4">
            {/* 1. Chairman */}
            {(selectedRole === 'all' || selectedRole === 'chairman') && (
              <div className="p-4 rounded-xl border border-emerald-300 bg-emerald-50/40 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                      চেয়ারম্যান / প্রশাসক
                    </span>
                    <span className="text-xs text-slate-500">ইউপি শীর্ষ নেতৃত্ব</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">{data.chairman.name}</h3>
                  <p className="text-xs text-slate-600"><strong>দায়িত্ব:</strong> {data.chairman.duty}</p>
                </div>
                <div className="flex items-center gap-2 self-stretch md:self-auto justify-between md:justify-end border-t md:border-t-0 pt-2 md:pt-0">
                  <span className="font-mono text-sm font-bold text-slate-800 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                    {data.chairman.mobile}
                  </span>
                  <button
                    onClick={() => handleCopy(data.chairman.mobile, 'cm-copy')}
                    className="p-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-colors"
                    title="নম্বর কপি করুন"
                  >
                    {copiedId === 'cm-copy' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => onAskAiWithContext(`চেয়ারম্যান মহোদয়ের সাথে সাক্ষাতের নিয়ম এবং দায়িত্ব কী কী?`)}
                    className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>AI পরামর্শ</span>
                  </button>
                </div>
              </div>
            )}

            {/* 2. Secretary */}
            {(selectedRole === 'all' || selectedRole === 'secretary') && (
              <div className="p-4 rounded-xl border border-blue-300 bg-blue-50/40 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-300">
                      ইউনিয়ন পরিষদ সচিব
                    </span>
                    <span className="text-xs text-slate-500">প্রধান প্রশাসনিক কর্মকর্তা</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">{data.secretary.name}</h3>
                  <p className="text-xs text-slate-600"><strong>দায়িত্ব:</strong> {data.secretary.duty}</p>
                </div>
                <div className="flex items-center gap-2 self-stretch md:self-auto justify-between md:justify-end border-t md:border-t-0 pt-2 md:pt-0">
                  <span className="font-mono text-sm font-bold text-slate-800 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                    {data.secretary.mobile}
                  </span>
                  <button
                    onClick={() => handleCopy(data.secretary.mobile, 'sec-copy')}
                    className="p-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-colors"
                  >
                    {copiedId === 'sec-copy' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => onAskAiWithContext(`ইউপি সচিবের স্বাক্ষর কখন এবং কোন কোন সনদে প্রয়োজন হয়?`)}
                    className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>AI পরামর্শ</span>
                  </button>
                </div>
              </div>
            )}

            {/* 3. UDC Operator */}
            {(selectedRole === 'all' || selectedRole === 'udc') && (
              <div className="p-4 rounded-xl border border-teal-300 bg-teal-50/40 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 border border-teal-300">
                      UDC উদ্যোক্তা ও হেল্পডেস্ক
                    </span>
                    <span className="text-xs text-teal-700 font-medium">WhatsApp ও ডিজিটাল সেবা</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">{data.udc_operator.name}</h3>
                  <p className="text-xs text-slate-600"><strong>দায়িত্ব:</strong> {data.udc_operator.duty}</p>
                </div>
                <div className="flex items-center gap-2 self-stretch md:self-auto justify-between md:justify-end border-t md:border-t-0 pt-2 md:pt-0">
                  <span className="font-mono text-sm font-bold text-slate-800 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                    {data.udc_operator.mobile}
                  </span>
                  <a
                    href={`https://wa.me/88${data.udc_operator.mobile}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-lg text-xs font-bold flex items-center gap-1"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp</span>
                  </a>
                  <button
                    onClick={() => handleCopy(data.udc_operator.mobile, 'udc-copy')}
                    className="p-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-colors"
                  >
                    {copiedId === 'udc-copy' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* 4. Administrative Officer */}
            {(selectedRole === 'all' || selectedRole === 'admin') && (
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-800 border border-slate-300">
                      প্রশাসনিক কর্মকর্তা
                    </span>
                    <span className="text-xs text-slate-500">হিসাব সহকারী কাম-কম্পিউটার অপারেটর</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">{data.admin_officer.name}</h3>
                  <p className="text-xs text-slate-600"><strong>দায়িত্ব:</strong> {data.admin_officer.duty}</p>
                </div>
                <div className="flex items-center gap-2 self-stretch md:self-auto justify-between md:justify-end border-t md:border-t-0 pt-2 md:pt-0">
                  <span className="font-mono text-sm font-bold text-slate-800 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                    {data.admin_officer.mobile}
                  </span>
                  <button
                    onClick={() => handleCopy(data.admin_officer.mobile, 'admin-copy')}
                    className="p-2 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 transition-colors"
                  >
                    {copiedId === 'admin-copy' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* 5. General Ward Members (1-9) */}
            {(selectedRole === 'all' || selectedRole === 'members') && (
              <div className="space-y-2.5 pt-3">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                  <span>সাধারণ ওয়ার্ড মেম্বার তালিকা (১নং – ৯নং ওয়ার্ড)</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {data.members.map((m) => (
                    <div key={m.ward} className="p-3 rounded-xl border border-slate-200 bg-white hover:border-amber-400 transition-colors shadow-xs flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-200">
                          {m.ward}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 mt-1">{m.name}</h4>
                        <p className="text-[11px] text-slate-500">{m.duty}</p>
                      </div>
                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between">
                        <span className="font-mono text-xs text-slate-800 font-semibold">{m.mobile}</span>
                        <button
                          onClick={() => handleCopy(m.mobile, `m-${m.ward}`)}
                          className="p-1.5 text-slate-500 hover:text-slate-800 rounded hover:bg-slate-100"
                        >
                          {copiedId === `m-${m.ward}` ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 6. Reserved Female Members */}
            {(selectedRole === 'all' || selectedRole === 'female_members') && (
              <div className="space-y-2.5 pt-3">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                  <span>সংরক্ষিত নারী সদস্যবৃন্দ (১–৩, ৪–৬, ৭–৯নং ওয়ার্ড)</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {data.reserved_female_members.map((rf) => (
                    <div key={rf.ward} className="p-3 rounded-xl border border-rose-200 bg-rose-50/40 shadow-xs flex flex-col justify-between">
                      <div>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800 border border-rose-200">
                          {rf.ward}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900 mt-1">{rf.name}</h4>
                        <p className="text-[11px] text-slate-600">{rf.duty}</p>
                      </div>
                      <div className="mt-2 pt-2 border-t border-rose-100 flex items-center justify-between">
                        <span className="font-mono text-xs text-slate-800 font-semibold">{rf.mobile}</span>
                        <button
                          onClick={() => handleCopy(rf.mobile, `rf-${rf.ward}`)}
                          className="p-1.5 text-slate-500 hover:text-slate-800 rounded hover:bg-white"
                        >
                          {copiedId === `rf-${rf.ward}` ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 7. Village Police */}
            {(selectedRole === 'all' || selectedRole === 'police') && (
              <div className="space-y-2.5 pt-3">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                  <span>গ্রাম পুলিশ (দফাদার ও মহল্লাদার)</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {data.village_police.map((vp, idx) => (
                    <div key={idx} className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-between">
                      <div>
                        <div className="text-[10px] font-bold text-indigo-700">{vp.role}</div>
                        <div className="text-xs font-bold text-slate-800">{vp.name}</div>
                        <div className="text-[10px] text-slate-500">{vp.duty || vp.ward}</div>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-xs text-slate-700">{vp.mobile}</span>
                        <button
                          onClick={() => handleCopy(vp.mobile, `vp-${idx}`)}
                          className="p-1 text-slate-400 hover:text-slate-700"
                        >
                          {copiedId === `vp-${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW 2: WHATSAPP CONVERSATION VIEW matching Prototype 4B */}
      {activeTab === 'whatsapp' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#25D366]"></span>
                <span>Section: WhatsApp View (কথোপকথন ভিউ)</span>
              </h2>
              <p className="text-xs text-slate-500">
                নাগরিকদের সহজে কপি ও হোয়াটসঅ্যাপে পাঠানোর উপযোগী রেডি ফরম্যাট
              </p>
            </div>

            <button
              onClick={() => handleCopy(whatsappConversationText, 'full-wa-copy')}
              className="px-4 py-2 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all active:scale-95"
            >
              {copiedId === 'full-wa-copy' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedId === 'full-wa-copy' ? 'কপি হয়েছে!' : 'সম্পূর্ণ মেসেজ কপি'}</span>
            </button>
          </div>

          <div className="p-4 bg-[#efeae2] rounded-2xl border border-slate-300 font-sans space-y-3 max-w-2xl mx-auto shadow-inner">
            {/* Operator Message */}
            <div className="flex items-start gap-2 max-w-[85%]">
              <div className="w-7 h-7 rounded-full bg-[#075E54] text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                UDC
              </div>
              <div className="bg-white p-3 rounded-2xl rounded-tl-none shadow-xs text-xs text-slate-800 leading-relaxed border border-slate-200">
                <p className="font-bold text-[#075E54] mb-1">UDC Operator</p>
                আসসালামু আলাইকুম, কিভাবে সাহায্য করতে পারি?
              </div>
            </div>

            {/* Citizen Message */}
            <div className="flex items-start justify-end gap-2 ml-auto max-w-[85%]">
              <div className="bg-[#dcf8c6] p-3 rounded-2xl rounded-tr-none shadow-xs text-xs text-slate-800 leading-relaxed border border-emerald-200">
                <p className="font-bold text-slate-700 mb-1">Citizen</p>
                কর্মকর্তাদের WhatsApp নম্বর চাই।
              </div>
              <div className="w-7 h-7 rounded-full bg-slate-700 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                নাগরিক
              </div>
            </div>

            {/* Operator Full Reply */}
            <div className="flex items-start gap-2 max-w-[92%]">
              <div className="w-7 h-7 rounded-full bg-[#075E54] text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                UDC
              </div>
              <div className="bg-white p-3.5 rounded-2xl rounded-tl-none shadow-xs text-xs text-slate-800 leading-relaxed border border-slate-200 space-y-2">
                <p className="font-bold text-[#075E54]">UDC Operator</p>
                <p>অবশ্যই, নিচে ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের কর্মকর্তাদের তালিকা—</p>
                
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 font-mono text-[11px] space-y-1.5">
                  <p className="font-bold text-slate-900">[চেয়ারম্যান] {data.chairman.name}: {data.chairman.mobile}</p>
                  <p className="font-bold text-slate-900">[সচিব] {data.secretary.name}: {data.secretary.mobile}</p>
                  <p className="font-bold text-slate-900">[UDC উদ্যোক্তা] {data.udc_operator.name}: {data.udc_operator.mobile}</p>
                  <p className="font-bold text-slate-900">[হিসাব সহকারী] {data.admin_officer.name}: {data.admin_officer.mobile}</p>
                </div>

                <div className="text-[11px] text-slate-600">
                  <span className="font-bold">ওয়ার্ড মেম্বারবৃন্দ (১-৯):</span>
                  <div className="grid grid-cols-2 gap-1 mt-1 text-[10px] text-slate-700 font-mono">
                    {data.members.slice(0, 6).map(m => (
                      <div key={m.ward}>{m.ward}: {m.mobile}</div>
                    ))}
                  </div>
                </div>

                <p className="text-[11px] text-slate-500 pt-1">
                  যেকোনো প্রয়োজনে সরাসরি মেসেজ পাঠাতে পারেন। ধন্যবাদ!
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: JSON VIEW (Web App) matching Prototype 4C */}
      {activeTab === 'json' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                <span>Section: JSON View (Web App Schema)</span>
              </h2>
              <p className="text-xs text-slate-500">
                সফটওয়্যার ইন্টিগ্রেশন ও ডাটাবেস এপিআই স্কিমা
              </p>
            </div>

            <button
              onClick={() => handleCopy(JSON.stringify(data, null, 2), 'json-schema-copy')}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all active:scale-95"
            >
              {copiedId === 'json-schema-copy' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedId === 'json-schema-copy' ? 'JSON কপি হয়েছে!' : 'Copy JSON'}</span>
            </button>
          </div>

          <div className="relative rounded-xl overflow-hidden bg-slate-900 text-slate-100 p-4 font-mono text-xs border border-slate-800 max-h-[500px] overflow-y-auto">
            <pre className="text-emerald-400 leading-relaxed whitespace-pre-wrap">
              {JSON.stringify(data, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
