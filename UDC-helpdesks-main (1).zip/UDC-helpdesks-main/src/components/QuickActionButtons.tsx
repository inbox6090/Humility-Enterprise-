import React from 'react';
import { Sparkles, MessageCircle, MessageSquare, Phone, Mail, Globe, ArrowUpRight } from 'lucide-react';
import { OperatorProfile } from '../types';

interface QuickActionButtonsProps {
  operator: OperatorProfile;
  onOpenChat: () => void;
  onCallModal: () => void;
}

export const QuickActionButtons: React.FC<QuickActionButtonsProps> = ({
  operator,
  onOpenChat,
  onCallModal
}) => {
  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-3 px-1">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          প্রধান অ্যাকশন বাটনসমূহ (Helpdesk Actions)
        </h3>
        <span className="text-xs text-slate-500">ক্লিক করে যোগাযোগ করুন</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {/* 1. AI Assistant Button - Primary Highlight */}
        <button
          id="action-btn-ai-chat"
          onClick={onOpenChat}
          className="group relative overflow-hidden bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white p-4 rounded-xl shadow-md transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-left border border-emerald-400/40"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-lg bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30 text-white">
                <Sparkles className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <span className="text-[11px] font-medium text-emerald-100 uppercase tracking-wider block">
                  তাৎক্ষণিক সমাধান
                </span>
                <span className="text-base font-bold text-white block leading-tight">
                  💬 AI সহকারীকে প্রশ্ন করুন
                </span>
              </div>
            </div>
            <ArrowUpRight className="w-5 h-5 text-emerald-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <p className="mt-2 text-xs text-emerald-100/90 leading-tight">
            যেকোনো সেবা, কাগজপত্র ও নিয়ম নিয়ে চ্যাট করুন
          </p>
        </button>

        {/* 2. WhatsApp Direct Contact */}
        <a
          id="action-btn-whatsapp"
          href={operator.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative overflow-hidden bg-[#25D366] hover:bg-[#20ba59] text-white p-4 rounded-xl shadow-md transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-left border border-emerald-300/40"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-lg bg-black/15 flex items-center justify-center border border-white/30 text-white">
                <MessageCircle className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-medium text-emerald-950 uppercase tracking-wider block">
                  অফিসিয়াল চ্যাট
                </span>
                <span className="text-base font-bold text-white block leading-tight">
                  🟢 WhatsApp-এ যোগাযোগ
                </span>
              </div>
            </div>
            <ArrowUpRight className="w-5 h-5 text-emerald-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <div className="mt-2 space-y-1">
            <p className="text-xs text-white/95 leading-tight">
              প্রয়োজনে সরাসরি WhatsApp-এ লিখিতভাবে টেক্সট করুন
            </p>
            <div className="inline-flex items-center gap-1.5 bg-black/20 text-white text-[11px] font-bold px-2 py-0.5 rounded-md border border-white/20">
              <span>📞 অফিস আওয়ার: ১০:০০–৫:০০ (শনি–বৃহঃ)</span>
            </div>
          </div>
        </a>

        {/* 3. SMS / Message Direct */}
        <a
          id="action-btn-sms"
          href={`sms:${operator.phone}?body=${encodeURIComponent('আসসালামু আলাইকুম, ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ সেবা সংক্রান্ত তথ্য জানতে চাচ্ছি।')}`}
          className="group relative overflow-hidden bg-slate-800 hover:bg-slate-700 text-white p-4 rounded-xl shadow-md transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-left border border-slate-700"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-lg bg-white/10 flex items-center justify-center border border-white/20 text-sky-400">
                <MessageSquare className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-medium text-slate-300 uppercase tracking-wider block">
                  মেসেজ অ্যাপ
                </span>
                <span className="text-base font-bold text-white block leading-tight">
                  📱 SMS / Message পাঠান
                </span>
              </div>
            </div>
            <ArrowUpRight className="w-5 h-5 text-slate-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <p className="mt-2 text-xs text-slate-300 leading-tight">
            মোবাইলে প্রি-ফিল্ড SMS: {operator.phone}
          </p>
        </a>

        {/* 4. Phone Contact Modal (with Warning Rule) */}
        <button
          id="action-btn-phone"
          onClick={onCallModal}
          className="group relative overflow-hidden bg-white hover:bg-slate-50 text-slate-800 p-4 rounded-xl shadow-sm border border-slate-200 transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-lg bg-blue-50 flex items-center justify-center border border-blue-200 text-blue-600">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider block">
                  জরুরি তথ্য
                </span>
                <span className="text-base font-bold text-slate-800 block leading-tight">
                  📞 হেল্পডেস্ক নম্বর
                </span>
              </div>
            </div>
            <ArrowUpRight className="w-5 h-5 text-slate-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <p className="mt-2 text-xs text-amber-700 font-medium leading-tight">
            কলের পরিবর্তে SMS/WhatsApp লিখিত বার্তা পাঠানোর অনুরোধ
          </p>
        </button>

        {/* 5. Gmail Contact */}
        <a
          id="action-btn-gmail"
          href={`mailto:${operator.email}?subject=${encodeURIComponent('০২নং বহেড়াতৈল ইউনিয়ন পরিষদ হেল্পডেস্ক অনুসন্ধান')}`}
          className="group relative overflow-hidden bg-white hover:bg-slate-50 text-slate-800 p-4 rounded-xl shadow-sm border border-slate-200 transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-lg bg-red-50 flex items-center justify-center border border-red-200 text-red-600">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider block">
                  অফিসিয়াল ইমেইল
                </span>
                <span className="text-base font-bold text-slate-800 block leading-tight">
                  📧 Gmail-এ লিখুন
                </span>
              </div>
            </div>
            <ArrowUpRight className="w-5 h-5 text-slate-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <p className="mt-2 text-xs text-slate-500 truncate leading-tight">
            {operator.email}
          </p>
        </a>

        {/* 6. Facebook Profile */}
        <a
          id="action-btn-facebook"
          href={operator.facebookUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative overflow-hidden bg-white hover:bg-slate-50 text-slate-800 p-4 rounded-xl shadow-sm border border-slate-200 transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-left"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-lg bg-indigo-50 flex items-center justify-center border border-indigo-200 text-indigo-600">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider block">
                  ফেসবুক প্রোফাইল
                </span>
                <span className="text-base font-bold text-slate-800 block leading-tight">
                  🌐 Facebook পেইজ/প্রোফাইল
                </span>
              </div>
            </div>
            <ArrowUpRight className="w-5 h-5 text-slate-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </div>
          <p className="mt-2 text-xs text-slate-500 leading-tight">
            MD JUBAER HOSSEN • অফিসিয়াল প্রোফাইল
          </p>
        </a>
      </div>
    </section>
  );
};
