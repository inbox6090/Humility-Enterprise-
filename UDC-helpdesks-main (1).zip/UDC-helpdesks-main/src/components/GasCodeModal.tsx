import React, { useState } from 'react';
import { X, Copy, Check, Code, ExternalLink, FileCode, CheckCircle2, ShieldCheck } from 'lucide-react';

interface GasCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const GAS_CODE_TEXT = `/**
 * ==========================================================================
 * AI চ্যাটবট মডিউল — ০২ নং বহেড়াতৈল ইউনিয়ন পরিষদ হেল্পডেস্ক
 * ==========================================================================
 * এই ফাইলটি Gemini.gs-এ যোগ করুন অথবা আলাদা AI_Chatbot.gs ফাইল হিসেবে রাখুন।
 * WhatsApp (Make.com webhook) এবং কল-লগ সামারি — দুই জায়গা থেকেই এই একই
 * ফাংশন কল হবে।
 *
 * নির্ভরতা (Dependencies):
 *  - Script Properties-এ GEMINI_API_KEY সেট থাকতে হবে
 *  - CONFIG.CHAT_LOG_SHEET_ID / SHEET_NAME (কথোপকথনের ইতিহাস রাখার জন্য)
 *  - CONFIG.TICKETS_SHEET_NAME (টিকেট তৈরির জন্য, আগের ধাপে আলোচিত)
 * ==========================================================================
 */

// --------------------------------------------------------------------------
// ১. কনফিগারেশন
// --------------------------------------------------------------------------
const CHATBOT_CONFIG = {
  GEMINI_MODEL: "gemini-2.0-flash",
  CONFIDENCE_THRESHOLD: 0.6,       // এর নিচে হলে → মানুষের কাছে এসকেলেট
  MAX_CONTEXT_MESSAGES: 3,         // আগের কতগুলো মেসেজ প্রম্পটে জুড়বে
  CHAT_LOG_SHEET_NAME: "ChatLogs",
  TICKETS_SHEET_NAME: "Tickets"
};

// --------------------------------------------------------------------------
// ২. সিস্টেম প্রম্পট (এই অংশটাই বটের "ব্যক্তিত্ব ও নিয়ম")
// --------------------------------------------------------------------------
function getSystemPrompt_() {
  return \`
তুমি "সহায়ক" — বাংলাদেশের ০২ নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখীপুর, টাঙ্গাইলের
একটি সরকারি ডিজিটাল হেল্পডেস্ক সহকারী। তুমি নাগরিকদের WhatsApp মেসেজের
উত্তর দাও।

তোমার আচরণবিধি (কঠোরভাবে মানতে হবে):
১. সবসময় সহজ, ভদ্র ও দাপ্তরিক-কিন্তু-বন্ধুত্বপূর্ণ বাংলায় উত্তর দেবে।
২. তুমি যা জানো না, তা কখনো বানিয়ে বলবে না। অনিশ্চিত হলে confidence_score
   কম দিয়ে needs_escalation: true করবে।
৩. ফি, সময়সীমা, বা প্রক্রিয়াগত নির্দিষ্ট তথ্য দেওয়ার আগে নিশ্চিত হও যে
   এটি context-এ সরবরাহ করা হয়েছে। না থাকলে সরাসরি বলে দাও যে একজন
   স্টাফ সঠিক তথ্য জানাবেন।
৪. ব্যক্তিগত/স্পর্শকাতর সিদ্ধান্ত (যেমন কোনো আবেদন বাতিল/অনুমোদন) কখনো
   নিজে থেকে দেবে না — সবসময় escalate করবে।
৫. প্রতিটি উত্তর অবশ্যই নিচের JSON কাঠামোতে দেবে, অতিরিক্ত কোনো টেক্সট
   ছাড়া (কোনো markdown code fence ছাড়া, শুধু raw JSON):

{
  "intent": "status_check | complaint | suggestion | general_query | other",
  "category": "রাস্তা | পানি | বিদ্যুৎ | প্রশাসনিক | সনদ | অন্যান্য | none",
  "confidence_score": 0.0 থেকে 1.0 এর মধ্যে একটি সংখ্যা,
  "reply_text": "নাগরিককে পাঠানোর জন্য প্রস্তুত বাংলা উত্তর",
  "needs_escalation": true অথবা false,
  "ticket_summary": "যদি এটি অভিযোগ/পরামর্শ হয়, এক লাইনে সারাংশ, নাহলে null"
}
\`.trim();
}

// --------------------------------------------------------------------------
// ৩. মূল ফাংশন — WhatsApp ও কল-লগ দুই জায়গা থেকেই এটি কল হবে
// --------------------------------------------------------------------------
/**
 * @param {string} userMessage      নাগরিকের মূল বার্তা (WhatsApp টেক্সট বা কল-সারাংশ)
 * @param {string} phoneNumber      নাগরিকের ফোন নম্বর (কনটেক্সট লুকআপের জন্য)
 * @param {string} channel          "whatsapp" | "call" | "web"
 * @returns {Object} parsed AI response object
 */
function handleChatbotMessage(userMessage, phoneNumber, channel) {
  try {
    // ধাপ ১: আগের কথোপকথনের ইতিহাস টেনে আনা
    const previousContext = getRecentChatHistory_(phoneNumber, CHATBOT_CONFIG.MAX_CONTEXT_MESSAGES);

    // ধাপ ২: নাগরিকের পরিচিত তথ্য আছে কিনা দেখা (UPMS ডেটাবেস থেকে)
    const citizenInfo = lookupCitizenByPhone_(phoneNumber);

    // ধাপ ৩: Gemini-কে কল করা
    const aiResponse = callGeminiChatbotAPI_(userMessage, previousContext, citizenInfo);

    // ধাপ ৪: লগ সংরক্ষণ (ভবিষ্যতের কনটেক্সটের জন্য)
    logChatMessage_(phoneNumber, channel, userMessage, aiResponse.reply_text);

    // ধাপ ৫: প্রয়োজনে টিকেট তৈরি
    if (aiResponse.intent === "complaint" || aiResponse.intent === "suggestion") {
      createTicketFromChat_(phoneNumber, channel, aiResponse);
    }

    // ধাপ ৬: কনফিডেন্স কম হলে জোর করে এসকেলেট করা (AI নিজে ভুল বললেও সেফটি নেট)
    if (aiResponse.confidence_score < CHATBOT_CONFIG.CONFIDENCE_THRESHOLD) {
      aiResponse.needs_escalation = true;
      aiResponse.reply_text +=
        "\\n\\nআপনার প্রশ্নটি আরও ভালোভাবে বোঝার জন্য একজন স্টাফ শীঘ্রই আপনার " +
        "সাথে যোগাযোগ করবেন। ধন্যবাদ।";
    }

    if (aiResponse.needs_escalation) {
      flagForStaffAttention_(phoneNumber, channel, userMessage, aiResponse);
    }

    return aiResponse;

  } catch (err) {
    Logger.log("handleChatbotMessage error: " + err.message);
    return {
      intent: "other",
      category: "none",
      confidence_score: 0,
      reply_text: "দুঃখিত, এই মুহূর্তে সাড়া দিতে সমস্যা হচ্ছে। একজন স্টাফ শীঘ্রই যোগাযোগ করবেন।",
      needs_escalation: true,
      ticket_summary: userMessage
    };
  }
}

// --------------------------------------------------------------------------
// ৪. Gemini API কল
// --------------------------------------------------------------------------
function callGeminiChatbotAPI_(userMessage, previousContext, citizenInfo) {
  const apiKey = PropertiesService.getScriptProperties().getProperty("GEMINI_API_KEY");
  if (!apiKey) throw new Error("GEMINI_API_KEY সেট করা নেই। Script Properties চেক করুন।");

  const url = \`https://generativelanguage.googleapis.com/v1beta/models/\${CHATBOT_CONFIG.GEMINI_MODEL}:generateContent?key=\${apiKey}\`;

  const contextBlock = previousContext.length
    ? \`পূর্ববর্তী কথোপকথন:\\n\${previousContext.map(m => \`- \${m}\`).join("\\n")}\`
    : "কোনো পূর্ববর্তী কথোপকথন নেই।";

  const citizenBlock = citizenInfo
    ? \`নাগরিকের পরিচিত তথ্য: নাম - \${citizenInfo.name}, শেষ আবেদন - \${citizenInfo.lastApplication || "নেই"}\`
    : "এই ফোন নম্বরটি ডেটাবেসে পাওয়া যায়নি — নতুন নাগরিক হতে পারে।";

  const fullPrompt = \`\${getSystemPrompt_()}

\${contextBlock}

\${citizenBlock}

নাগরিকের বর্তমান বার্তা: "\${userMessage}"

উপরের নিয়ম অনুযায়ী শুধুমাত্র JSON রেসপন্স দাও।\`;

  const payload = {
    contents: [{ parts: [{ text: fullPrompt }] }],
    generationConfig: {
      temperature: 0.3,
      responseMimeType: "application/json"
    }
  };

  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  const response = UrlFetchApp.fetch(url, options);
  const responseCode = response.getResponseCode();
  const responseText = response.getContentText();

  if (responseCode !== 200) {
    throw new Error(\`Gemini API error (\${responseCode}): \${responseText}\`);
  }

  const json = JSON.parse(responseText);
  const rawText = json.candidates[0].content.parts[0].text;
  const parsed = JSON.parse(rawText);

  return {
    intent: parsed.intent || "other",
    category: parsed.category || "none",
    confidence_score: typeof parsed.confidence_score === "number" ? parsed.confidence_score : 0.5,
    reply_text: parsed.reply_text || "দুঃখিত, বুঝতে সমস্যা হয়েছে।",
    needs_escalation: !!parsed.needs_escalation,
    ticket_summary: parsed.ticket_summary || null
  };
}

// --------------------------------------------------------------------------
// ৫. কনটেক্সট মেমোরি
// --------------------------------------------------------------------------
function getRecentChatHistory_(phoneNumber, maxMessages) {
  const sheet = getOrCreateChatLogSheet_();
  const data = sheet.getDataRange().getValues();
  const history = [];

  for (let i = data.length - 1; i >= 1 && history.length < maxMessages; i--) {
    if (data[i][1] === phoneNumber) {
      history.unshift(\`নাগরিক: \${data[i][3]} | বট: \${data[i][4]}\`);
    }
  }
  return history;
}

function logChatMessage_(phoneNumber, channel, userMessage, botReply) {
  const sheet = getOrCreateChatLogSheet_();
  sheet.appendRow([new Date(), phoneNumber, channel, userMessage, botReply]);
}

function getOrCreateChatLogSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(CHATBOT_CONFIG.CHAT_LOG_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(CHATBOT_CONFIG.CHAT_LOG_SHEET_NAME);
    sheet.appendRow(["Timestamp", "Phone", "Channel", "UserMessage", "BotReply"]);
  }
  return sheet;
}

// --------------------------------------------------------------------------
// ৬. নাগরিক লুকআপ (UPMS)
// --------------------------------------------------------------------------
function lookupCitizenByPhone_(phoneNumber) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName("Citizens");
    if (!sheet) return null;

    const data = sheet.getDataRange().getValues();
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][1]) === String(phoneNumber)) {
        return { name: data[i][0], lastApplication: data[i][3] || null };
      }
    }
    return null;
  } catch (e) {
    return null;
  }
}

// --------------------------------------------------------------------------
// ৭. টিকেট তৈরি
// --------------------------------------------------------------------------
function createTicketFromChat_(phoneNumber, channel, aiResponse) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(CHATBOT_CONFIG.TICKETS_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(CHATBOT_CONFIG.TICKETS_SHEET_NAME);
    sheet.appendRow(["TicketID", "Timestamp", "Phone", "Channel", "Intent", "Category", "Summary", "Status"]);
  }

  const ticketId = "T-" + Utilities.formatDate(new Date(), "GMT+6", "yyyyMMdd-HHmmss");
  sheet.appendRow([
    ticketId,
    new Date(),
    phoneNumber,
    channel,
    aiResponse.intent,
    aiResponse.category,
    aiResponse.ticket_summary,
    "গৃহীত"
  ]);

  return ticketId;
}

// --------------------------------------------------------------------------
// ৮. স্টাফের নজরে আনা (এসকেলেশন)
// --------------------------------------------------------------------------
function flagForStaffAttention_(phoneNumber, channel, userMessage, aiResponse) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName("EscalationQueue");
  if (!sheet) {
    sheet = ss.insertSheet("EscalationQueue");
    sheet.appendRow(["Timestamp", "Phone", "Channel", "UserMessage", "Confidence", "Handled"]);
  }
  sheet.appendRow([new Date(), phoneNumber, channel, userMessage, aiResponse.confidence_score, "না"]);
}

// Make.com Webhook Handler
function doPost(e) {
  const body = JSON.parse(e.postData.contents);
  const result = handleChatbotMessage(body.message, body.phone, "whatsapp");
  return ContentService.createTextOutput(JSON.stringify({ reply: result.reply_text }))
         .setMimeType(ContentService.MimeType.JSON);
}`;

export const GasCodeModal: React.FC<GasCodeModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(GAS_CODE_TEXT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-[#0c1e36] to-[#1a3860] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
              <FileCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Google Apps Script (AI_Chatbot.gs) কোড</h3>
              <p className="text-xs text-slate-300">
                Google Sheets ও Make.com WhatsApp Webhook-এ ব্যবহারের জন্য অফিসিয়াল কোড
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyCode}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>কপি সম্পন্ন!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>সম্পূর্ণ কোড কপি করুন</span>
                </>
              )}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Instructions Banner */}
        <div className="px-5 py-3 bg-emerald-50 border-b border-emerald-200 text-xs text-emerald-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              <strong>সেটআপ নির্দেশিকা:</strong> Google Sheets &gt; Extensions &gt; Apps Script &gt; Script Properties-এ <code>GEMINI_API_KEY</code> যোগ করুন।
            </span>
          </div>
          <span className="text-emerald-800 font-mono text-[11px] bg-white px-2 py-0.5 rounded border border-emerald-300">
            Model: gemini-2.0-flash / gemini-2.5-flash
          </span>
        </div>

        {/* Code Content */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950 text-slate-200 font-mono text-xs leading-relaxed">
          <pre className="whitespace-pre overflow-x-auto">
            <code>{GAS_CODE_TEXT}</code>
          </pre>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-600 flex items-center justify-between">
          <span>ফাইল লোকেশন: <code>/google_apps_script/AI_Chatbot.gs</code></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 font-medium text-xs transition-colors"
          >
            বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
