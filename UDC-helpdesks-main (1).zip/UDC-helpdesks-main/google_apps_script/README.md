# ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ — AI চ্যাটবট ও Make.com ইন্টিগ্রেশন গাইড

এই ফোল্ডারে রয়েছে Google Apps Script (`AI_Chatbot.gs`) মডিউল যা WhatsApp (Make.com webhook), কল-লগ সামারি এবং Google Sheets ডাটাবেজের সাথে স্বয়ংক্রিয়ভাবে কাজ করে।

## ১. কীভাবে Google Sheets-এ সেটআপ করবেন:
1. আপনার ইউনিয়ন পরিষদের গুগল শিট খুলুন (যেমন: `Baheratail_UP_Citizen_DB`)।
2. মেন্যুবার থেকে **Extensions > Apps Script**-এ যান।
3. একটি নতুন ফাইল তৈরি করে নাম দিন `AI_Chatbot.gs` এবং এই ফোল্ডারের কোডটি কপি করে পেস্ট করুন।
4. **Project Settings (গিয়ার আইকন) > Script Properties**-এ গিয়ে যোগ করুন:
   - `GEMINI_API_KEY`: আপনার Gemini API Key

## ২. ব্যবহৃত শিট ও কলাম স্ট্রাকচার:
- **ChatLogs:** `[Timestamp, Phone, Channel, UserMessage, BotReply]`
- **Tickets:** `[TicketID, Timestamp, Phone, Channel, Intent, Category, Summary, Status]`
- **Citizens:** `[Name, Phone, ..., LastApplicationType]`
- **EscalationQueue:** `[Timestamp, Phone, Channel, UserMessage, Confidence, Handled]`

## ৩. Make.com Webhook ডিপ্লয়মেন্ট:
1. Apps Script-এ **Deploy > New deployment** নির্বাচন করুন।
2. Select type: **Web app**
3. Execute as: **Me**
4. Who has access: **Anyone**
5. Deploy করে প্রাপ্ত Web App URL-টি Make.com-এর HTTP Module বা Webhook-এ সেট করুন।
6. `doPost(e)` ফাংশন ব্যবহার করে WhatsApp মেসেজ পাঠালে এটি সরাসরি JSON ফরম্যাটে উত্তর দেবে।

## ৪. ওয়েব অ্যাপ্লিকেশন এন্ডপয়েন্ট:
এই পোর্টালের ব্যাকএন্ডেও সমমানের দুটি এপিআই রয়েছে:
- `POST /api/webhook/whatsapp` — Make.com উপযোগী পে-লোড `{ "message": "...", "phone": "017...", "channel": "whatsapp" }`
- `POST /api/chatbot` — একই পে-লোড নিয়ে বিস্তারিত মেটাডাটা ও টিকেট আইডি প্রদান করে।
- `GET /api/tickets` — স্বয়ংক্রিয়ভাবে তৈরি হওয়া টিকেট তালিকা।
- `GET /api/escalations` — এসকেলেশন কিউ ও পর্যালোচনার তালিকা।
