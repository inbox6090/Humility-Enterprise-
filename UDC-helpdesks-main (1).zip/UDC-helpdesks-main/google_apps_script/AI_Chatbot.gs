/**
 * ==========================================================================
 * AI চ্যাটবট মডিউল — ০২ নং বহেড়াতৈল ইউনিয়ন পরিষদ হেল্পডেস্ক
 * ==========================================================================
 * এই ফাইলটি Gemini.gs-এ যোগ করুন অথবা আলাদা AI_Chatbot.gs ফাইল হিসেবে রাখুন।
 * WhatsApp (Make.com webhook) এবং কল-লগ সামারি — দুই জায়গা থেকেই এই একই
 * ফাংশন কল হবে।
 *
 * নির্ভরতা (Dependencies):
 *  - Script Properties-এ GEMINI_API_KEY সেট থাকতে হবে
 *  - CONFIG.CHAT_LOG_SHEET_ID / SHEET_NAME (কথোপকথনের ইতিহাস রাখার জন্য)
 *  - CONFIG.TICKETS_SHEET_NAME (টিকেট তৈরির জন্য, আগের ধাপে আলোচিত)
 * ==========================================================================
 */

// --------------------------------------------------------------------------
// ১. কনফিগারেশন
// --------------------------------------------------------------------------
const CHATBOT_CONFIG = {
  GEMINI_MODEL: "gemini-2.0-flash",
  CONFIDENCE_THRESHOLD: 0.6,       // এর নিচে হলে → মানুষের কাছে এসকেলেট
  MAX_CONTEXT_MESSAGES: 3,         // আগের কতগুলো মেসেজ প্রম্পটে জুড়বে
  CHAT_LOG_SHEET_NAME: "ChatLogs",
  TICKETS_SHEET_NAME: "Tickets"
};

// --------------------------------------------------------------------------
// ২. সিস্টেম প্রম্পট (এই অংশটাই বটের "ব্যক্তিত্ব ও নিয়ম")
// --------------------------------------------------------------------------
function getSystemPrompt_() {
  return `
তুমি "সহায়ক" — বাংলাদেশের ০২ নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখীপুর, টাঙ্গাইলের
একটি সরকারি ডিজিটাল হেল্পডেস্ক সহকারী। তুমি নাগরিকদের WhatsApp মেসেজের
উত্তর দাও।

তোমার আচরণবিধি (কঠোরভাবে মানতে হবে):
১. সবসময় সহজ, ভদ্র ও দাপ্তরিক-কিন্তু-বন্ধুত্বপূর্ণ বাংলায় উত্তর দেবে।
২. তুমি যা জানো না, তা কখনো বানিয়ে বলবে না। অনিশ্চিত হলে confidence_score
   কম দিয়ে needs_escalation: true করবে।
৩. ফি, সময়সীমা, বা প্রক্রিয়াগত নির্দিষ্ট তথ্য দেওয়ার আগে নিশ্চিত হও যে
   এটি context-এ সরবরাহ করা হয়েছে। না থাকলে সরাসরি বলে দাও যে একজন
   স্টাফ সঠিক তথ্য জানাবেন।
৪. ব্যক্তিগত/স্পর্শকাতর সিদ্ধান্ত (যেমন কোনো আবেদন বাতিল/অনুমোদন) কখনো
   নিজে থেকে দেবে না — সবসময় escalate করবে।
৫. প্রতিটি উত্তর অবশ্যই নিচের JSON কাঠামোতে দেবে, অতিরিক্ত কোনো টেক্সট
   ছাড়া (কোনো markdown code fence ছাড়া, শুধু raw JSON):

{
  "intent": "status_check | complaint | suggestion | general_query | other",
  "category": "রাস্তা | পানি | বিদ্যুৎ | প্রশাসনিক | সনদ | অন্যান্য | none",
  "confidence_score": 0.0 থেকে 1.0 এর মধ্যে একটি সংখ্যা,
  "reply_text": "নাগরিককে পাঠানোর জন্য প্রস্তুত বাংলা উত্তর",
  "needs_escalation": true অথবা false,
  "ticket_summary": "যদি এটি অভিযোগ/পরামর্শ হয়, এক লাইনে সারাংশ, নাহলে null"
}
`.trim();
}

// --------------------------------------------------------------------------
// ৩. মূল ফাংশন — WhatsApp ও কল-লগ দুই জায়গা থেকেই এটি কল হবে
// --------------------------------------------------------------------------
/**
 * @param {string} userMessage      নাগরিকের মূল বার্তা (WhatsApp টেক্সট বা কল-সারাংশ)
 * @param {string} phoneNumber      নাগরিকের ফোন নম্বর (কনটেক্সট লুকআপের জন্য)
 * @param {string} channel          "whatsapp" | "call" | "web"
 * @returns {Object} parsed AI response object
 */
function handleChatbotMessage(userMessage, phoneNumber, channel) {
  try {
    // ধাপ ১: আগের কথোপকথনের ইতিহাস টেনে আনা
    const previousContext = getRecentChatHistory_(phoneNumber, CHATBOT_CONFIG.MAX_CONTEXT_MESSAGES);

    // ধাপ ২: নাগরিকের পরিচিত তথ্য আছে কিনা দেখা (UPMS ডেটাবেস থেকে)
    const citizenInfo = lookupCitizenByPhone_(phoneNumber);

    // ধাপ ৩: Gemini-কে কল করা
    const aiResponse = callGeminiChatbotAPI_(userMessage, previousContext, citizenInfo);

    // ধাপ ৪: লগ সংরক্ষণ (ভবিষ্যতের কনটেক্সটের জন্য)
    logChatMessage_(phoneNumber, channel, userMessage, aiResponse.reply_text);

    // ধাপ ৫: প্রয়োজনে টিকেট তৈরি
    if (aiResponse.intent === "complaint" || aiResponse.intent === "suggestion") {
      createTicketFromChat_(phoneNumber, channel, aiResponse);
    }

    // ধাপ ৬: কনফিডেন্স কম হলে জোর করে এসকেলেট করা (AI নিজে ভুল বললেও সেফটি নেট)
    if (aiResponse.confidence_score < CHATBOT_CONFIG.CONFIDENCE_THRESHOLD) {
      aiResponse.needs_escalation = true;
      aiResponse.reply_text +=
        "\n\nআপনার প্রশ্নটি আরও ভালোভাবে বোঝার জন্য একজন স্টাফ শীঘ্রই আপনার " +
        "সাথে যোগাযোগ করবেন। ধন্যবাদ।";
    }

    if (aiResponse.needs_escalation) {
      flagForStaffAttention_(phoneNumber, channel, userMessage, aiResponse);
    }

    return aiResponse;

  } catch (err) {
    Logger.log("handleChatbotMessage error: " + err.message);
    // AI ফেইল করলেও নাগরিক যেন খালি হাতে না ফেরে
    return {
      intent: "other",
      category: "none",
      confidence_score: 0,
      reply_text: "দুঃখিত, এই মুহূর্তে সাড়া দিতে সমস্যা হচ্ছে। একজন স্টাফ শীঘ্রই যোগাযোগ করবেন।",
      needs_escalation: true,
      ticket_summary: userMessage
    };
  }
}

// --------------------------------------------------------------------------
// ৪. Gemini API কল
// --------------------------------------------------------------------------
function callGeminiChatbotAPI_(userMessage, previousContext, citizenInfo) {
  const apiKey = PropertiesService.getScriptProperties().getProperty("GEMINI_API_KEY");
  if (!apiKey) throw new Error("GEMINI_API_KEY সেট করা নেই। Script Properties চেক করুন।");

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${CHATBOT_CONFIG.GEMINI_MODEL}:generateContent?key=${apiKey}`;

  const contextBlock = previousContext.length
    ? `পূর্ববর্তী কথোপকথন:\n${previousContext.map(m => `- ${m}`).join("\n")}`
    : "কোনো পূর্ববর্তী কথোপকথন নেই।";

  const citizenBlock = citizenInfo
    ? `নাগরিকের পরিচিত তথ্য: নাম - ${citizenInfo.name}, শেষ আবেদন - ${citizenInfo.lastApplication || "নেই"}`
    : "এই ফোন নম্বরটি ডেটাবেসে পাওয়া যায়নি — নতুন নাগরিক হতে পারে।";

  const fullPrompt = `${getSystemPrompt_()}

${contextBlock}

${citizenBlock}

নাগরিকের বর্তমান বার্তা: "${userMessage}"

উপরের নিয়ম অনুযায়ী শুধুমাত্র JSON রেসপন্স দাও।`;

  const payload = {
    contents: [{ parts: [{ text: fullPrompt }] }],
    generationConfig: {
      temperature: 0.3,       // কম টেম্পারেচার = বেশি নির্ভুল, কম "সৃজনশীল" উত্তর
      responseMimeType: "application/json"
    }
  };

  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  const response = UrlFetchApp.fetch(url, options);
  const responseCode = response.getResponseCode();
  const responseText = response.getContentText();

  if (responseCode !== 200) {
    throw new Error(`Gemini API error (${responseCode}): ${responseText}`);
  }

  const json = JSON.parse(responseText);
  const rawText = json.candidates[0].content.parts[0].text;
  const parsed = JSON.parse(rawText); // JSON mode ব্যবহার করায় সরাসরি parse করা যায়

  // ফলব্যাক ভ্যালিডেশন — AI যদি কোনো ফিল্ড বাদ দেয়
  return {
    intent: parsed.intent || "other",
    category: parsed.category || "none",
    confidence_score: typeof parsed.confidence_score === "number" ? parsed.confidence_score : 0.5,
    reply_text: parsed.reply_text || "দুঃখিত, বুঝতে সমস্যা হয়েছে।",
    needs_escalation: !!parsed.needs_escalation,
    ticket_summary: parsed.ticket_summary || null
  };
}

// --------------------------------------------------------------------------
// ৫. কনটেক্সট মেমোরি — Sheets থেকে সাম্প্রতিক কথোপকথন টেনে আনা
// --------------------------------------------------------------------------
function getRecentChatHistory_(phoneNumber, maxMessages) {
  const sheet = getOrCreateChatLogSheet_();
  const data = sheet.getDataRange().getValues();
  const history = [];

  // ধরে নিচ্ছি কলাম: [Timestamp, Phone, Channel, UserMessage, BotReply]
  for (let i = data.length - 1; i >= 1 && history.length < maxMessages; i--) {
    if (data[i][1] === phoneNumber) {
      history.unshift(`নাগরিক: ${data[i][3]} | বট: ${data[i][4]}`);
    }
  }
  return history;
}

function logChatMessage_(phoneNumber, channel, userMessage, botReply) {
  const sheet = getOrCreateChatLogSheet_();
  sheet.appendRow([new Date(), phoneNumber, channel, userMessage, botReply]);
}

function getOrCreateChatLogSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(CHATBOT_CONFIG.CHAT_LOG_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(CHATBOT_CONFIG.CHAT_LOG_SHEET_NAME);
    sheet.appendRow(["Timestamp", "Phone", "Channel", "UserMessage", "BotReply"]);
  }
  return sheet;
}

// --------------------------------------------------------------------------
// ৬. নাগরিক লুকআপ (UPMS ডেটাবেসের সাথে সংযোগ — শিট নাম/কলাম নিজের মতো ঠিক করুন)
// --------------------------------------------------------------------------
function lookupCitizenByPhone_(phoneNumber) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName("Citizens"); // আপনার citizen ডাটা শিটের নাম দিন
    if (!sheet) return null;

    const data = sheet.getDataRange().getValues();
    // ধরে নিচ্ছি কলাম: [..., Name, Phone, ..., LastApplicationType]
    for (let i = 1; i < data.length; i++) {
      if (String(data[i][1]) === String(phoneNumber)) {
        return { name: data[i][0], lastApplication: data[i][3] || null };
      }
    }
    return null;
  } catch (e) {
    return null; // লুকআপ ব্যর্থ হলেও চ্যাটবট থেমে যাবে না
  }
}

// --------------------------------------------------------------------------
// ৭. টিকেট তৈরি (অভিযোগ/পরামর্শের জন্য)
// --------------------------------------------------------------------------
function createTicketFromChat_(phoneNumber, channel, aiResponse) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(CHATBOT_CONFIG.TICKETS_SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(CHATBOT_CONFIG.TICKETS_SHEET_NAME);
    sheet.appendRow(["TicketID", "Timestamp", "Phone", "Channel", "Intent", "Category", "Summary", "Status"]);
  }

  const ticketId = "T-" + Utilities.formatDate(new Date(), "GMT+6", "yyyyMMdd-HHmmss");
  sheet.appendRow([
    ticketId,
    new Date(),
    phoneNumber,
    channel,
    aiResponse.intent,
    aiResponse.category,
    aiResponse.ticket_summary,
    "গৃহীত"
  ]);

  return ticketId;
}

// --------------------------------------------------------------------------
// ৮. স্টাফের নজরে আনা (এসকেলেশন)
// --------------------------------------------------------------------------
function flagForStaffAttention_(phoneNumber, channel, userMessage, aiResponse) {
  // এখানে চাইলে স্টাফদের কাছে ইমেইল/WhatsApp নোটিফিকেশন পাঠাতে পারেন।
  // আপাতত শুধু একটা লগ শিটে ফ্ল্যাগ করে রাখছি।
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName("EscalationQueue");
  if (!sheet) {
    sheet = ss.insertSheet("EscalationQueue");
    sheet.appendRow(["Timestamp", "Phone", "Channel", "UserMessage", "Confidence", "Handled"]);
  }
  sheet.appendRow([new Date(), phoneNumber, channel, userMessage, aiResponse.confidence_score, "না"]);
}

/**
 * ==========================================================================
 * Make.com থেকে কল করার নমুনা (webhook handler হিসেবে ব্যবহার করুন)
 * ==========================================================================
 * doPost(e) ফাংশনে Code.gs-এ এভাবে যুক্ত করুন:
 *
 * function doPost(e) {
 *   const body = JSON.parse(e.postData.contents);
 *   const result = handleChatbotMessage(body.message, body.phone, "whatsapp");
 *   return ContentService.createTextOutput(JSON.stringify({ reply: result.reply_text }))
 *          .setMimeType(ContentService.MimeType.JSON);
 * }
 * ==========================================================================
 */
