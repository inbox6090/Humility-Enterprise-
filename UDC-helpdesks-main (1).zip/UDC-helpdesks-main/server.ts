import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { 
  DEFAULT_OPERATOR, 
  SERVICES_DATA, 
  CITIZEN_REPORTS_DATA, 
  CONTACT_DIRECTORY_DATA, 
  findReportByNo,
  REGISTERED_CITIZENS_DATA,
  lookupCitizenByPhone,
  SAMPLE_TICKETS,
  SAMPLE_ESCALATIONS
} from './src/data/knowledgeBase';
import { 
  TicketItem, 
  EscalationItem, 
  ChatbotIntent, 
  ChatbotCategory, 
  ChatbotResponse,
  GeminiInputPayload,
  GeminiOutputResponse,
  FormattedResponse
} from './src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// In-memory operator state (initialized with official data)
let currentOperator = { ...DEFAULT_OPERATOR };

// In-memory Ticket, Escalation & Chat logs state (matching Google Apps Script / UPMS Database)
let ticketsDatabase: TicketItem[] = [...SAMPLE_TICKETS];
let escalationQueue: EscalationItem[] = [...SAMPLE_ESCALATIONS];
let chatLogs: Array<{ timestamp: string; phone: string; channel: string; userMessage: string; botReply: string }> = [];

// Office Hours configuration (Strictly defined per instructions)
export const OFFICE_HOURS = {
  call_available: '10:00–17:00 (Sat–Thu)',
  closed: 'Friday & Govt Holidays',
  displayText: 'শনিবার–বৃহস্পতিবার: সকাল ১০টা থেকে বিকাল ৫টা, শুক্রবার ও সরকারি ছুটির দিনে বন্ধ',
  shortBadge: '১০:০০–৫:০০ (শনি–বৃহঃ)',
  deepLink: 'https://wa.me/message/7PMRKZ6ZMPT2G1'
};

// Dynamic Citizens and Reports state (Simulating real-time UPMS / Google Sheet updates)
export interface DynamicCitizenRecord {
  name: string;
  mobile: string;
  address?: string;
  reportNumber?: string;
  issueText?: string;
  createdAt: string;
}

export interface DynamicReportRecord {
  reportNo: string;
  citizenName: string;
  mobile?: string;
  serviceName: string;
  previousIssue: string;
  reasonForContact: string;
  relatedDocuments: string[];
  stuckStep: string;
  currentStatus: string;
  counter: string;
  recommendedAction: string;
  submissionDate: string;
}

const dynamicCitizens: DynamicCitizenRecord[] = [];
const dynamicReports: DynamicReportRecord[] = [];

// Helper to validate numeric report number (only digits, min 5 digits)
export function validateNumericReportNumber(num: string): boolean {
  if (!num) return false;
  const cleaned = num.trim();
  return /^\d{5,}$/.test(cleaned);
}

// Helper to generate numeric report number (numeric, ≥5 digits)
export function generateNumericReportNumber(): string {
  return String(Math.floor(10000 + Math.random() * 90000));
}

// Lazy initialize Gemini client
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({ apiKey });
}

// --------------------------------------------------------------------------
// AI চ্যাটবট মডিউল কনফিগারেশন ও প্রম্পট (AI_Chatbot.gs / Gemini.gs সমতুল্য)
// --------------------------------------------------------------------------
const CHATBOT_CONFIG = {
  GEMINI_MODEL: 'gemini-3.8-flash',
  CONFIDENCE_THRESHOLD: 0.6,
  MAX_CONTEXT_MESSAGES: 3,
};

export function createEmptyFormattedResponse(): FormattedResponse {
  return {
    service: '',
    documents: [],
    steps: [],
    counter: '',
    notes: [],
    report_analysis: {
      reportNumber: '',
      summary: '',
      possible_reason: '',
      recommended_action: ''
    },
    contact: {
      call: currentOperator.phone || '+8801834333300',
      whatsapp: currentOperator.whatsappUrl || 'https://wa.me/message/7PMRKZ6ZMPT2G1',
      sms: currentOperator.phone || '+8801834333300',
      email: currentOperator.email || 'Baheratailunion@gmail.com'
    }
  };
}

export function buildBanglaFormattedTemplate(fr: FormattedResponse, defaultText?: string): string {
  const parts: string[] = [];

  if (fr.service && fr.service.trim()) {
    parts.push(`📌 সেবা: ${fr.service.trim()}`);
  }

  if (fr.documents && fr.documents.length > 0) {
    const docLines = fr.documents.filter(d => d && d.trim()).map(d => `- ${d.trim()}`);
    if (docLines.length > 0) {
      parts.push(`📄 প্রয়োজনীয় কাগজপত্র:\n${docLines.join('\n')}`);
    }
  }

  if (fr.steps && fr.steps.length > 0) {
    const stepLines = fr.steps.filter(s => s && s.trim()).map((s, idx) => `${idx + 1}) ${s.trim()}`);
    if (stepLines.length > 0) {
      parts.push(`🛠️ প্রক্রিয়া:\n${stepLines.join('\n')}`);
    }
  }

  if (fr.counter && fr.counter.trim()) {
    parts.push(`🏢 দায়িত্বপ্রাপ্ত কাউন্টার: ${fr.counter.trim()}`);
  }

  if (fr.notes && fr.notes.length > 0) {
    const noteLines = fr.notes.filter(n => n && n.trim()).map(n => `- ${n.trim()}`);
    if (noteLines.length > 0) {
      parts.push(`⚠️ গুরুত্বপূর্ণ নোট:\n${noteLines.join('\n')}`);
    }
  }

  if (fr.report_analysis && (fr.report_analysis.reportNumber || fr.report_analysis.summary)) {
    const ra = fr.report_analysis;
    const repHeader = ra.reportNumber ? `${ra.reportNumber} অনুযায়ী:` : 'রিপোর্ট অনুযায়ী:';
    const repLines: string[] = [repHeader];
    if (ra.summary) repLines.push(`- ${ra.summary}`);
    if (ra.possible_reason) repLines.push(`- ${ra.possible_reason}`);
    parts.push(`📝 রিপোর্ট নং বিশ্লেষণ:\n${repLines.join('\n')}`);
  }

  if (fr.report_analysis && fr.report_analysis.recommended_action) {
    parts.push(`✅ করণীয়:\n- ${fr.report_analysis.recommended_action}`);
  } else if (!fr.report_analysis?.reportNumber && fr.service) {
    parts.push(`✅ করণীয়:\n- প্রয়োজনীয় কাগজপত্র প্রস্তুত করে ইউনিয়ন ডিজিটাল সেন্টার (UDC) বা সংশ্লিষ্ট কাউন্টারে জমা দিন।`);
  }

  if (fr.contact) {
    const c = fr.contact;
    const contactLines: string[] = [];
    if (c.call) contactLines.push(`- কল: ${c.call}`);
    if (c.whatsapp) contactLines.push(`- WhatsApp: ${c.whatsapp}`);
    if (c.sms) contactLines.push(`- SMS: ${c.sms}`);
    if (c.email) contactLines.push(`- ইমেইল: ${c.email}`);
    if (contactLines.length > 0) {
      parts.push(`📞 যোগাযোগ:\n${contactLines.join('\n')}`);
    }
  }

  parts.push(`🤝 আরও কোনো সহায়তা লাগলে আমাকে জানাতে পারেন।`);

  // If there's neither a service nor a report analysis, and we have custom reply text
  if (!fr.service && !fr.report_analysis?.reportNumber && defaultText && defaultText.trim()) {
    return defaultText;
  }

  return parts.join('\n\n');
}

export function normalizeIntent(intent: any): ChatbotIntent {
  const i = String(intent || '').toLowerCase().trim();
  if (i === 'generalquery' || i === 'general_query') return 'generalquery';
  if (i === 'servicequery' || i === 'service_query') return 'servicequery';
  if (i === 'statuscheck' || i === 'status_check') return 'statuscheck';
  if (i === 'complaint') return 'complaint';
  if (i === 'suggestion') return 'suggestion';
  if (i === 'contactrequest' || i === 'contact_request') return 'contactrequest';
  return 'other';
}

export function normalizeCategory(category: any): ChatbotCategory {
  const c = String(category || '').trim();
  const validCategories: ChatbotCategory[] = ['সনদ', 'জন্ম', 'মৃত্যু', 'রাস্তা', 'পানি', 'বিদ্যুৎ', 'প্রশাসনিক', 'অন্যান্য', 'none'];
  if (validCategories.includes(c as ChatbotCategory)) {
    return c as ChatbotCategory;
  }
  return 'অন্যান্য';
}

function detectCategoryFromText(text: string): ChatbotCategory {
  const t = text.toLowerCase();
  if (t.includes('রাস্তা') || t.includes('সড়ক') || t.includes('ব্রিজ') || t.includes('কালভার্ট') || t.includes('ড্রেন') || t.includes('খানাখন্দ')) {
    return 'রাস্তা';
  }
  if (t.includes('পানি') || t.includes('নলকূপ') || t.includes('টিউবওয়েল') || t.includes('আর্সেনিক') || t.includes('সাপ্লাই') || t.includes('জলাবদ্ধ')) {
    return 'পানি';
  }
  if (t.includes('বিদ্যুৎ') || t.includes('কারেন্ট') || t.includes('লোডশেডিং') || t.includes('ট্রান্সফরমার') || t.includes('মিটার') || t.includes('তার')) {
    return 'বিদ্যুৎ';
  }
  if (t.includes('জন্ম')) {
    return 'জন্ম';
  }
  if (t.includes('মৃত্যু')) {
    return 'মৃত্যু';
  }
  if (t.includes('সনদ') || t.includes('ওয়ারিশ') || t.includes('নাগরিকত্ব') || t.includes('ট্রেড') || t.includes('প্রত্যয়ন')) {
    return 'সনদ';
  }
  if (t.includes('ভাতা') || t.includes('ট্যাক্স') || t.includes('সচিব') || t.includes('চেয়ারম্যান') || t.includes('মেম্বার') || t.includes('অফিস')) {
    return 'প্রশাসনিক';
  }
  return 'অন্যান্য';
}

function validateAndNormalizeFormattedResponse(
  raw: any, 
  defaultService?: string, 
  defaultReportNo?: string
): FormattedResponse {
  const empty = createEmptyFormattedResponse();
  return {
    service: typeof raw?.service === 'string' ? raw.service : (defaultService || empty.service),
    documents: Array.isArray(raw?.documents) ? raw.documents.map(String) : empty.documents,
    steps: Array.isArray(raw?.steps) ? raw.steps.map(String) : empty.steps,
    counter: typeof raw?.counter === 'string' ? raw.counter : empty.counter,
    notes: Array.isArray(raw?.notes) ? raw.notes.map(String) : empty.notes,
    report_analysis: {
      reportNumber: typeof raw?.report_analysis?.reportNumber === 'string' ? raw.report_analysis.reportNumber : (defaultReportNo || ''),
      summary: typeof raw?.report_analysis?.summary === 'string' ? raw.report_analysis.summary : '',
      possible_reason: typeof raw?.report_analysis?.possible_reason === 'string' ? raw.report_analysis.possible_reason : '',
      recommended_action: typeof raw?.report_analysis?.recommended_action === 'string' ? raw.report_analysis.recommended_action : ''
    },
    contact: {
      call: typeof raw?.contact?.call === 'string' && raw.contact.call ? raw.contact.call : empty.contact.call,
      whatsapp: typeof raw?.contact?.whatsapp === 'string' && raw.contact.whatsapp ? raw.contact.whatsapp : empty.contact.whatsapp,
      sms: typeof raw?.contact?.sms === 'string' && raw.contact.sms ? raw.contact.sms : empty.contact.sms,
      email: typeof raw?.contact?.email === 'string' && raw.contact.email ? raw.contact.email : empty.contact.email,
    }
  };
}

function generateStructuredFallbackResponse(
  userMessage: string, 
  phoneNumber: string = '01XXXXXXXXX',
  serviceId?: string,
  explicitReportNo?: string
): GeminiOutputResponse {
  const text = userMessage.trim();
  const textLower = text.toLowerCase();
  const category = detectCategoryFromText(text);
  const fr = createEmptyFormattedResponse();

  // 1. Status check / Report check
  // Check if citizen entered numeric report number (min 5 digits validation)
  if (/^\d+$/.test(text)) {
    if (text.length < 5) {
      return {
        intent: 'statuscheck',
        category: 'অন্যান্য',
        confidence_score: 0.95,
        reply_text: 'রিপোর্ট নং শুধুমাত্র সংখ্যা হবে এবং কমপক্ষে ৫ ডিজিট হতে হবে।',
        needs_escalation: false,
        ticket_summary: null,
        formatted_response: fr
      };
    }
  }

  const hasReportKey = textLower.includes('রিপোর্ট') || textLower.includes('report') || /BT[-_]?(?:REP[-_]?)?\d+/i.test(text) || /\b\d{5,}\b/.test(text) || textLower.includes('স্ট্যাটাস') || !!explicitReportNo;
  if (hasReportKey) {
    const reportQuery = explicitReportNo || text;
    const matchedReport = findReportByNo(reportQuery) || dynamicReports.find(r => r.reportNo === reportQuery.trim());
    if (matchedReport) {
      fr.service = matchedReport.serviceName;
      fr.documents = [...matchedReport.relatedDocuments];
      fr.counter = matchedReport.counter;
      fr.notes = [
        `বর্তমান অবস্থা: ${matchedReport.currentStatus}`,
        `আটকে থাকা ধাপ: ${matchedReport.stuckStep}`
      ];
      fr.report_analysis = {
        reportNumber: matchedReport.reportNo,
        summary: `নাগরিক: ${matchedReport.citizenName}। পূর্বের সমস্যা: ${matchedReport.previousIssue}। যোগাযোগের কারণ: ${matchedReport.reasonForContact}।`,
        possible_reason: `আটকে থাকা ধাপ: ${matchedReport.stuckStep} (বর্তমান অবস্থা: ${matchedReport.currentStatus})`,
        recommended_action: matchedReport.recommendedAction
      };

      return {
        intent: 'statuscheck',
        category: 'সনদ',
        confidence_score: 0.95,
        reply_text: buildBanglaFormattedTemplate(fr),
        needs_escalation: false,
        ticket_summary: null,
        formatted_response: fr
      };
    }

    fr.report_analysis = {
      reportNumber: explicitReportNo || '',
      summary: 'প্রদত্ত রিপোর্ট নং সিস্টেমে পাওয়া যায়নি।',
      possible_reason: 'ভুল রিপোর্ট নম্বর প্রদান বা রেকর্ড না থাকা।',
      recommended_action: 'অনুগ্রহ করে সঠিক ৫ ডিজিটের রিপোর্ট নং প্রদান করুন অথবা ইউনিয়ন পরিষদ কার্যালয়ে সরাসরি যোগাযোগ করুন।'
    };

    return {
      intent: 'statuscheck',
      category: 'সনদ',
      confidence_score: 0.85,
      reply_text: `আপনার প্রদত্ত রিপোর্ট নং সিস্টেমে পাওয়া যায়নি। অনুগ্রহ করে সঠিক রিপোর্ট নং প্রদান করুন অথবা ইউনিয়ন পরিষদে যোগাযোগ করুন।`,
      needs_escalation: false,
      ticket_summary: null,
      formatted_response: fr
    };
  }

  // 2. WhatsApp Call Rule & Contact Request detection (Mandatory Office Hours & Safety Rule)
  const isCallRequest = textLower.includes('কল') || 
                        textLower.includes('phone') || 
                        textLower.includes('call') || 
                        textLower.includes('ফোন') ||
                        textLower.includes('whatsapp কল') || 
                        textLower.includes('হোয়াটসঅ্যাপ কল') || 
                        textLower.includes('কল করতে চাই');

  if (isCallRequest) {
    fr.service = 'অফিসিয়াল হেল্পডেস্ক ও WhatsApp যোগাযোগ';
    fr.counter = 'UDC হেল্পডেস্ক (MD JUBAER HOSSEN)';
    fr.notes = [
      'অফিস আওয়ার: শনিবার–বৃহস্পতিবার, সকাল ১০:০০ হতে বিকাল ৫:০০ ঘটিকা',
      'শুক্রবার ও সরকারি ছুটির দিনে বন্ধ'
    ];
    return {
      intent: 'contactrequest',
      category: 'প্রশাসনিক',
      confidence_score: 0.98,
      reply_text: `📞 কল করার আগে একটি বিষয় জানিয়ে রাখি—\n\nআমাদের অফিস আওয়ার:\nশনিবার–বৃহস্পতিবার: সকাল ১০টা থেকে বিকাল ৫টা\nশুক্রবার: বন্ধ\n\nএই সময়ের বাইরে কল করলে সাড়া পাওয়া নাও যেতে পারে।\nআপনি চাইলে এখনই WhatsApp-এ লিখিতভাবে বার্তা পাঠাতে পারেন।\n\n👉 WhatsApp: ${OFFICE_HOURS.deepLink}\n\n(অফিস আওয়ারে কল করলে সাড়া পাওয়া যাবে। লিখিত বার্তা পাঠালে দ্রুত উত্তর পাওয়া যাবে)`,
      needs_escalation: false,
      ticket_summary: null,
      formatted_response: fr,
      office_hours: {
        call_available: OFFICE_HOURS.call_available,
        closed: OFFICE_HOURS.closed
      }
    };
  }

  // 2. Complaint detection
  const complaintKeywords = [
    'অভিযোগ', 'ভেঙে', 'নষ্ট', 'পানি জমে', 'বিদ্যুৎ নাই', 'কারেন্ট নাই', 
    'সমস্যা', 'বিপদ', 'মেরামত', 'খারাপ অবস্থা', 'জলাবদ্ধতা', 'ড্রেন', 
    'উপচে', 'বন্ধ', 'কাদা', 'খানাখন্দ', 'ময়লা', 'আবর্জনা', 'দেরি হচ্ছে',
    'হয়রানি', 'দুর্ভোগ', 'অসুবিধা', 'ভাঙা', 'চালু নেই', 'পড়ে আছে'
  ];
  const isComplaint = complaintKeywords.some(k => textLower.includes(k));
  if (isComplaint) {
    fr.notes = ['নাগরিক অভিযোগটি ইউনিয়ন পরিষদ নোটিশ ও ব্যবস্থাপনা রেজিস্টারে তালিকাভুক্ত করা হয়েছে।'];
    return {
      intent: 'complaint',
      category: category === 'none' ? 'অন্যান্য' : category,
      confidence_score: 0.88,
      reply_text: `আপনার অভিযোগটি গুরুত্ব সহকারে গ্রহণ করা হলো। ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের সংশ্লিষ্ট শাখাকে তদন্ত ও প্রয়োজনীয় ব্যবস্থার জন্য নির্দেশনা দেওয়া হচ্ছে।`,
      needs_escalation: false,
      ticket_summary: text.slice(0, 100),
      formatted_response: fr
    };
  }

  // 3. Suggestion detection
  const suggestionKeywords = ['পরামর্শ', 'উচিত', 'অনুরোধ', 'প্রস্তাব', 'উন্নয়ন', 'চালু করা দরকার', 'সুপারিশ', 'ব্যবস্থা করা', 'করা প্রয়োজন', 'দাবি'];
  const isSuggestion = suggestionKeywords.some(k => textLower.includes(k));
  if (isSuggestion) {
    fr.notes = ['পরামর্শটি ইউনিয়ন পরিষদের মাসিক সমন্বয় সভায় পর্যালোচনার জন্য জমা রাখা হলো।'];
    return {
      intent: 'suggestion',
      category: category === 'none' ? 'প্রশাসনিক' : category,
      confidence_score: 0.85,
      reply_text: `আপনার সুচিন্তিত পরামর্শের জন্য বহেড়াতৈল ইউনিয়ন পরিষদের পক্ষ থেকে আন্তরিক ধন্যবাদ। এটি পরবর্তী পরিষদ মাসিক সমন্বয় সভায় পর্যালোচনা করা হবে।`,
      needs_escalation: false,
      ticket_summary: text.slice(0, 100),
      formatted_response: fr
    };
  }

  // 4. Contact Request detection
  const contactKeywords = ['যোগাযোগ', 'ফোন', 'মোবাইল', 'নাম্বার', 'contact', 'হোয়াটসঅ্যাপ', 'whatsapp', 'হেল্পডেস্ক'];
  if (contactKeywords.some(k => textLower.includes(k))) {
    fr.service = 'ইউনিয়ন পরিষদ হেল্পডেস্ক ও যোগাযোগ';
    fr.counter = 'UDC হেল্পডেস্ক ও ফ্রন্ট ডেস্ক';
    fr.notes = ['অফিস সময়: রবি-বৃহস্পতি, সকাল ৯:০০ হতে বিকাল ৫:০০ ঘটিকা।'];
    return {
      intent: 'contactrequest',
      category: 'প্রশাসনিক',
      confidence_score: 0.95,
      reply_text: `আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন।\n\nবহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল হেল্পডেস্ক:\n• UDC উদ্যোক্তা: ${currentOperator.name}\n• মোবাইল/এসএমএস: ${currentOperator.phone}\n• কার্যালয়: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল\n(অনুগ্রহ করে কল না করে লিখিত মেসেজ পাঠানোর অনুরোধ রইলো)`,
      needs_escalation: false,
      ticket_summary: null,
      formatted_response: fr
    };
  }

  // 5. Sensitive or out-of-scope inquiry (land dispute, arbitration, money claims)
  const sensitiveKeywords = ['জমি বিরোধ', 'শালিস', 'সালিশ', 'মামলা', 'টাকা ফেরত', 'দ্বন্দ্ব', 'মারামারি', 'আদালত'];
  if (sensitiveKeywords.some(k => textLower.includes(k))) {
    return {
      intent: 'other',
      category: 'প্রশাসনিক',
      confidence_score: 0.40,
      reply_text: `এটি পারিবারিক বা স্পর্শকাতর আইনি বিষয়। এই সিদ্ধান্ত সরাসরি ডিজিটাল চ্যাটে দেওয়া সম্ভব নয়। অনুগ্রহ করে প্রয়োজনীয় কাগজপত্রসহ ইউনিয়ন পরিষদ কার্যালয়ে গ্রাম আদালত বা চেয়ারম্যান মহোদয়ের সাথে যোগাযোগ করুন।`,
      needs_escalation: true,
      ticket_summary: text.slice(0, 100),
      formatted_response: fr
    };
  }

  // 6. Service knowledge query
  const matchedService = SERVICES_DATA.find(s => 
    s.id === serviceId || 
    textLower.includes(s.name.toLowerCase()) || 
    (s.id === 'birth-reg' && textLower.includes('জন্ম')) ||
    (s.id === 'death-reg' && textLower.includes('মৃত্যু')) ||
    (s.id === 'warish-cert' && (textLower.includes('ওয়ারিশ') || textLower.includes('উত্তরাধিকার'))) ||
    (s.id === 'citizen-cert' && (textLower.includes('নাগরিকত্ব') || textLower.includes('চারিত্রিক'))) ||
    (s.id === 'trade-license' && textLower.includes('ট্রেড')) ||
    (s.id === 'allowance-card' && (textLower.includes('ভাতা') || textLower.includes('বয়স্ক')))
  );

  if (matchedService) {
    fr.service = matchedService.name;
    fr.documents = [...matchedService.requiredDocuments];
    fr.steps = [...matchedService.applicationProcess];
    fr.counter = matchedService.counter;
    fr.notes = [...matchedService.importantNotes];
    if (matchedService.fee) {
      fr.notes.push(`অফিসিয়াল ফি সংক্রান্ত তথ্য: ${matchedService.fee}`);
    }

    return {
      intent: 'servicequery',
      category: matchedService.id === 'birth-reg' ? 'জন্ম' : matchedService.id === 'death-reg' ? 'মৃত্যু' : 'সনদ',
      confidence_score: 0.95,
      reply_text: buildBanglaFormattedTemplate(fr),
      needs_escalation: false,
      ticket_summary: null,
      formatted_response: fr
    };
  }

  // 7. General query / Greeting
  const greetingKeywords = ['সালাম', 'hello', 'hi', 'কেমন আছেন', 'আছেন', 'help', 'সাহায্য'];
  if (greetingKeywords.some(k => textLower.includes(k))) {
    return {
      intent: 'generalquery',
      category: 'প্রশাসনিক',
      confidence_score: 0.95,
      reply_text: `আসসালামু আলাইকুম! আমি ডিজিটাল ইউনিয়ন পরিষদ সিটিজেন অ্যাসিস্ট্যান্ট। ০২নং বহেড়াতৈল ইউনিয়ন পরিষদের নাগরিক সেবা, সার্টিফিকেট, অভিযোগ দায়ের বা পূর্বে জমাকৃত রিপোর্ট নং সম্পর্কে আপনার জিজ্ঞাসা জানাতে পারেন।`,
      needs_escalation: false,
      ticket_summary: null,
      formatted_response: fr
    };
  }

  // Default unknown topic
  return {
    intent: 'other',
    category: 'none',
    confidence_score: 0.45,
    reply_text: `এই তথ্যটি বর্তমানে সিস্টেমে নেই। অনুগ্রহ করে ০২নং বহেড়াতৈল ইউনিয়ন পরিষদে যোগাযোগ করুন।`,
    needs_escalation: true,
    ticket_summary: text.slice(0, 100),
    formatted_response: fr
  };
}

export interface ChatbotMessageOptions {
  message: string;
  serviceName?: string | null;
  reportNumber?: string | null;
  context?: string | null;
  citizenProfile?: { name: string; mobile: string; address: string } | null;
  serviceData?: { documents: string[]; steps: string[]; counter: string; notes: string[] } | null;
  contactDirectory?: any | null;
  phone?: string;
  channel?: 'whatsapp' | 'call' | 'web';
  serviceId?: string;
  history?: Array<{ role: string; content: string }>;
}

// মূল ফাংশন — Web, WhatsApp এবং কল-লগ থেকে একযোগে ব্যবহারের জন্য (handleChatbotMessage)
async function handleChatbotMessageInternal(
  inputOrMessage: string | ChatbotMessageOptions,
  phoneNumberArg: string = '01XXXXXXXXX',
  channelArg: 'whatsapp' | 'call' | 'web' = 'whatsapp',
  serviceIdArg?: string,
  reqHistoryArg: Array<{ role: string; content: string }> = []
): Promise<GeminiOutputResponse> {
  let opts: ChatbotMessageOptions;

  if (typeof inputOrMessage === 'string') {
    opts = {
      message: inputOrMessage,
      phone: phoneNumberArg,
      channel: channelArg,
      serviceId: serviceIdArg,
      history: reqHistoryArg
    };
  } else {
    opts = inputOrMessage;
  }

  const userMessage = (opts.message || '').trim();
  const phoneNumber = opts.phone || '01XXXXXXXXX';
  const channel = opts.channel || 'web';
  const serviceId = opts.serviceId;
  const reqHistory = opts.history || [];

  try {
    // ধাপ ১: আগের কথোপকথনের ইতিহাস টেনে আনা (সর্বোচ্চ ৩টি)
    const previousContext = reqHistory.slice(-CHATBOT_CONFIG.MAX_CONTEXT_MESSAGES).map(m => `${m.role === 'user' ? 'নাগরিক' : 'বট'}: ${m.content}`);

    // ধাপ ২: নাগরিকের পরিচিত তথ্য আছে কিনা দেখা (UPMS ডেটাবেস থেকে)
    const citizenInfo = opts.citizenProfile 
      ? { name: opts.citizenProfile.name, phone: opts.citizenProfile.mobile, address: opts.citizenProfile.address, lastApplication: '' }
      : lookupCitizenByPhone(phoneNumber);

    // ধাপ ৩: রিপোর্ট নম্বর বিশ্লেষণ (ইনপুট বা টেক্সট থেকে)
    const reportMatch = userMessage.match(/(?:BT[-_]?(?:REP[-_]?)?\d+)/i);
    const extractedReportNo = reportMatch ? reportMatch[0].toUpperCase().replace('_', '-') : null;
    const reportNumber = opts.reportNumber || extractedReportNo || null;

    // ধাপ ৪: সেবা শনাক্তকরণ
    const textLower = userMessage.toLowerCase();
    const matchedService = SERVICES_DATA.find(s => 
      s.id === serviceId || 
      (opts.serviceName && s.name.toLowerCase().includes(opts.serviceName.toLowerCase())) ||
      textLower.includes(s.name.toLowerCase()) || 
      (s.id === 'birth-reg' && textLower.includes('জন্ম')) ||
      (s.id === 'death-reg' && textLower.includes('মৃত্যু')) ||
      (s.id === 'warish-cert' && (textLower.includes('ওয়ারিশ') || textLower.includes('উত্তরাধিকার'))) ||
      (s.id === 'citizen-cert' && (textLower.includes('নাগরিকত্ব') || textLower.includes('চারিত্রিক'))) ||
      (s.id === 'trade-license' && textLower.includes('ট্রেড')) ||
      (s.id === 'allowance-card' && (textLower.includes('ভাতা') || textLower.includes('বয়স্ক')))
    );

    // ধাপ ৫: Production Gemini Input Schema অবজেক্ট তৈরি
    const geminiInput: GeminiInputPayload = {
      message: userMessage,
      serviceName: opts.serviceName || (matchedService ? matchedService.name : null),
      reportNumber: reportNumber,
      context: opts.context || (previousContext.length ? previousContext.join('\n') : null),
      citizenProfile: opts.citizenProfile || (citizenInfo ? {
        name: citizenInfo.name,
        mobile: citizenInfo.phone || phoneNumber,
        address: citizenInfo.address || 'বহেড়াতৈল, সখিপুর, টাঙ্গাইল'
      } : null),
      serviceData: opts.serviceData || (matchedService ? {
        documents: matchedService.requiredDocuments,
        steps: matchedService.applicationProcess,
        counter: matchedService.counter,
        notes: matchedService.importantNotes
      } : null),
      contactDirectory: opts.contactDirectory || CONTACT_DIRECTORY_DATA
    };

    const ai = getGenAI();
    let aiResponse: GeminiOutputResponse;

    if (!ai) {
      aiResponse = generateStructuredFallbackResponse(userMessage, phoneNumber, serviceId || matchedService?.id, reportNumber || undefined);
    } else {
      try {
        const kbContext = getKnowledgeBaseContext();
        const reportsContext = getCitizenReportsContext();

        const fullPrompt = `You are the official Digital Union Parishad Citizen Assistant for Baheratail Union, Sakhipur, Tangail, Bangladesh (০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল, বাংলাদেশ).

Official Brand Identity:
- System Name: ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্ক
- Union: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল
- Counter types: UDC / সচিব / চেয়ারম্যান
- Always respond in polite, clear, structured Bangla.
- Never reveal AI or model identity (do not mention Gemini, Claude, AI model).
- Use ONLY verified information from the Knowledge Base and provided input payload.
- If information is missing or out of scope, state: "এই তথ্যটি বর্তমানে সিস্টেমে নেই। অনুগ্রহ করে ইউনিয়ন পরিষদে যোগাযোগ করুন।"
- When user provides contact inquiry, inform them: "আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন।"

WhatsApp Call Rules & Safety Constraints (CRITICAL):
- WhatsApp Call শুরু হওয়ার আগে AI অবশ্যই অফিস আওয়ার উল্লেখ করবে:
  অফিস আওয়ার (UDC Operator): শনিবার–বৃহস্পতিবার: সকাল ১০:০০ — বিকাল ৫:০০, শুক্রবার: বন্ধ।
- যখন নাগরিক কল করতে চায় বা "কল", "ফোন", "WhatsApp কল" বলে:
  AI উত্তর দিবে:
  "📞 কল করার আগে একটি বিষয় জানিয়ে রাখি—

  আমাদের অফিস আওয়ার:
  শনিবার–বৃহস্পতিবার: সকাল ১০টা থেকে বিকাল ৫টা
  শুক্রবার: বন্ধ

  এই সময়ের বাইরে কল করলে সাড়া পাওয়া নাও যেতে পারে।
  আপনি চাইলে এখনই WhatsApp-এ লিখিতভাবে বার্তা পাঠাতে পারেন।

  👉 WhatsApp: https://wa.me/message/7PMRKZ6ZMPT2G1"
- AI SAFETY RULES: AI কখনোই বলবে না:
  ❌ "এখনই কল করুন"
  ❌ "আমি কল রিসিভ করব"
  ❌ "চেয়ারম্যান/সচিব এখন কল রিসিভ করবেন"
- AI কেবল বলবে:
  "অফিস আওয়ারে কল করলে সাড়া পাওয়া যাবে। লিখিত বার্তা পাঠালে দ্রুত উত্তর পাওয়া যাবে।"

[Input Payload Received (Strict Gemini Input Schema)]
${JSON.stringify(geminiInput, null, 2)}

[Official Services Knowledge Base]
${kbContext}

[Citizen Reports Database]
${reportsContext}

Gemini Output Formatter (Full Production Version):
You MUST output ONLY a valid raw JSON object matching this exact schema:
{
  "intent": "generalquery | servicequery | statuscheck | complaint | suggestion | contactrequest | other",
  "category": "সনদ | জন্ম | মৃত্যু | রাস্তা | পানি | বিদ্যুৎ | প্রশাসনিক | অন্যান্য | none",
  "confidence_score": 0.0 to 1.0,
  "reply_text": "Formatted Bangla text response",
  "needs_escalation": false,
  "ticket_summary": null,
  "office_hours": {
    "call_available": "10:00–17:00 (Sat–Thu)",
    "closed": "Friday & Govt Holidays"
  },
  "formatted_response": {
    "service": "",
    "documents": [],
    "steps": [],
    "counter": "",
    "notes": [],
    "report_analysis": {
      "reportNumber": "",
      "summary": "",
      "possible_reason": "",
      "recommended_action": ""
    },
    "contact": {
      "call": "${currentOperator.phone || '+8801834333300'}",
      "whatsapp": "${currentOperator.whatsappUrl || 'https://wa.me/message/7PMRKZ6ZMPT2G1'}",
      "sms": "${currentOperator.phone || '+8801834333300'}",
      "email": "${currentOperator.email || 'Baheratailunion@gmail.com'}"
    }
  }
}

Formatted Response Structure (Bangla Template):
Inside "reply_text", format the response according to this template whenever applicable (omit sections that have no data):
📌 সেবা: <service>

📄 প্রয়োজনীয় কাগজপত্র:
- <document_1>
- <document_2>

🛠️ প্রক্রিয়া:
1) <step_1>
2) <step_2>

🏢 দায়িত্বপ্রাপ্ত কাউন্টার: <counter>

⚠️ গুরুত্বপূর্ণ নোট:
- <note_1>

📝 রিপোর্ট নং বিশ্লেষণ:
<reportNumber> অনুযায়ী:
- <summary>
- <possible_reason>

✅ করণীয়:
- <recommended_action>

📞 যোগাযোগ:
- কল: <call>
- WhatsApp: <whatsapp>
- SMS: <sms>
- ইমেইল: <email>

🤝 আরও কোনো সহায়তা লাগলে আমাকে জানাতে পারেন।

Output raw JSON only without markdown code fences.`;

        const result = await ai.models.generateContent({
          model: CHATBOT_CONFIG.GEMINI_MODEL,
          contents: [{ role: 'user', parts: [{ text: fullPrompt }] }],
          config: {
            temperature: 0.2,
            responseMimeType: 'application/json',
          }
        });

        const rawText = (result.text || '').trim();
        const parsed = JSON.parse(rawText);

        const normalizedIntent = normalizeIntent(parsed.intent);
        const normalizedCategory = normalizeCategory(parsed.category);
        const normalizedFormatted = validateAndNormalizeFormattedResponse(
          parsed.formatted_response,
          geminiInput.serviceName || undefined,
          geminiInput.reportNumber || undefined
        );

        let finalReplyText = parsed.reply_text || '';
        // If reply_text is missing or template format needed
        if (!finalReplyText || (normalizedFormatted.service && !finalReplyText.includes('📌 সেবা:'))) {
          finalReplyText = buildBanglaFormattedTemplate(normalizedFormatted, finalReplyText);
        }

        aiResponse = {
          intent: normalizedIntent,
          category: normalizedCategory,
          confidence_score: typeof parsed.confidence_score === 'number' ? parsed.confidence_score : 0.85,
          reply_text: finalReplyText,
          needs_escalation: !!parsed.needs_escalation,
          ticket_summary: parsed.ticket_summary || null,
          formatted_response: normalizedFormatted,
          office_hours: parsed.office_hours || (normalizedIntent === 'contactrequest' ? {
            call_available: OFFICE_HOURS.call_available,
            closed: OFFICE_HOURS.closed
          } : undefined)
        };
      } catch (geminiError) {
        console.warn('Gemini chatbot call failed, using verified fallback:', geminiError);
        aiResponse = generateStructuredFallbackResponse(
          userMessage, 
          phoneNumber, 
          serviceId || matchedService?.id, 
          reportNumber || undefined
        );
      }
    }

    // AI Safety Sanitization Rule (Strict Enforcement)
    if (aiResponse.reply_text) {
      aiResponse.reply_text = aiResponse.reply_text
        .replace(/এখনই\s*কল\s*করুন/g, 'অফিস আওয়ারে কল করতে পারেন বা লিখিত বার্তা পাঠাতে পারেন')
        .replace(/আমি\s*কল\s*রিসিভ\s*করব/g, 'অফিস আওয়ারে ইউডিসি হেল্পডেস্কে অপারেটর কল রিসিভ করবেন')
        .replace(/চেয়ারম্যান\/সচিব\s*এখন\s*কল\s*রিসিভ\s*করবেন/g, 'অফিস আওয়ারে সংশ্লিষ্ট কাউন্টারে যোগাযোগ করা যাবে');
    }

    // ধাপ ৬: লগ সংরক্ষণ
    chatLogs.unshift({
      timestamp: new Date().toISOString(),
      phone: phoneNumber,
      channel,
      userMessage,
      botReply: aiResponse.reply_text
    });

    // ধাপ ৭: প্রয়োজনে টিকেট তৈরি (যদি অভিযোগ বা পরামর্শ হয়)
    if (aiResponse.intent === 'complaint' || aiResponse.intent === 'suggestion') {
      const now = new Date();
      const dateString = now.toISOString().replace(/[-:T]/g, '').slice(0, 14);
      const ticketId = `T-${dateString.slice(0, 8)}-${dateString.slice(8, 14)}`;

      const newTicket: TicketItem = {
        ticketId,
        timestamp: now.toLocaleString('bn-BD', { hour12: true }),
        phone: phoneNumber,
        channel,
        intent: aiResponse.intent,
        category: aiResponse.category,
        summary: aiResponse.ticket_summary || userMessage.slice(0, 100),
        status: 'গৃহীত'
      };

      ticketsDatabase.unshift(newTicket);
      aiResponse.ticket_id = ticketId;
      aiResponse.reply_text += `\n\n📌 আপনার অভিযোগ/পরামর্শটি নিবন্ধিত হয়েছে।\n🎫 ট্র্যাকিং টিকেট নং: **${ticketId}** (স্ট্যাটাস: গৃহীত)`;
    }

    // ধাপ ৮: কনফিডেন্স কম হলে জোর করে এসকেলেট করা
    if (aiResponse.confidence_score < CHATBOT_CONFIG.CONFIDENCE_THRESHOLD) {
      aiResponse.needs_escalation = true;
      aiResponse.reply_text += '\n\nআপনার প্রশ্নটি আরও ভালোভাবে বোঝার জন্য একজন স্টাফ শীঘ্রই আপনার সাথে যোগাযোগ করবেন। ধন্যবাদ।';
    }

    // ধাপ ৯: স্টাফের নজরে আনা (এসকেলেশন কিউ)
    if (aiResponse.needs_escalation) {
      const escalationItem: EscalationItem = {
        id: `esc-${Date.now()}`,
        timestamp: new Date().toLocaleString('bn-BD', { hour12: true }),
        phone: phoneNumber,
        channel,
        userMessage,
        confidence_score: aiResponse.confidence_score,
        handled: 'না',
        reason: aiResponse.intent === 'other' ? 'অনুপলব্ধ তথ্য / সংবেদনশীল বিষয়' : 'নিম্ন কনফিডেন্স স্কোর (<০.৬)'
      };
      escalationQueue.unshift(escalationItem);
    }

    aiResponse.channel = channel;
    return aiResponse;

  } catch (err: any) {
    console.error('handleChatbotMessage error:', err);
    const emptyFr = createEmptyFormattedResponse();
    return {
      intent: 'other',
      category: 'none',
      confidence_score: 0,
      reply_text: 'দুঃখিত, এই মুহূর্তে সাড়া দিতে সমস্যা হচ্ছে। একজন স্টাফ শীঘ্রই যোগাযোগ করবেন।',
      needs_escalation: true,
      ticket_summary: userMessage,
      channel,
      formatted_response: emptyFr
    };
  }
}

// System instructions for Digital Union Parishad Citizen Assistant (Strict compliance with PROJECT_BRIEF.md)
const SYSTEM_INSTRUCTION = `You are the official Digital Union Parishad Citizen Assistant for Baheratail Union, Sakhipur, Tangail, Bangladesh (০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল, বাংলাদেশ).

Brand Identity & Persona:
- System Name: ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্ক
- Union: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল
- Tagline: "আপনার সেবায় প্রযুক্তির ছোঁয়া — ডিজিটাল ইউনিয়ন পরিষদ"
- Welcome message: "আসসালামু আলাইকুম! ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্কে আপনাকে স্বাগতম। 🤝"
- Never reveal your identity (AI, Gemini, Claude, model, or internal system details). Always respond as "ডিজিটাল ইউনিয়ন পরিষদ হেল্পডেস্ক".

Your Core Mission:
- Always answer in simple, polite, structured Bangla.
- Explain Union Parishad services, required documents, step-by-step processes, counters, and rules.
- Use ONLY verified information from Knowledge Base and system data.
- Fallback message when information is missing or uncertain:
  "এই বিষয়ে নিশ্চিত তথ্য আমার কাছে নেই। অনুগ্রহ করে ইউনিয়ন পরিষদে যোগাযোগ করুন।"
- Never guess fees/costs. Only mention official fees if explicitly provided in Knowledge Base.

"রিপোর্ট নং" (Report No) Rules:
- Never use "আবেদন নং" or "আবেদন স্ট্যাটাস" — always use "রিপোর্ট নং" (problem/issue-tracking ID).
- When a citizen provides a "রিপোর্ট নং", analyze:
  - তাদের পূর্বের সমস্যা কী ছিল
  - কেন তারা আবার যোগাযোগ করছে
  - কোন সেবা বা নথি সম্পর্কিত সমস্যা
  - কোন ধাপে আটকে গেছে
- If the report number is not in system:
  "আপনার প্রদত্ত রিপোর্ট নং সিস্টেমে পাওয়া যায়নি। অনুগ্রহ করে সঠিক রিপোর্ট নং প্রদান করুন।"

Strict Response Template (follow this structure for service answers):
📌 সেবা: <সেবার নাম>
📄 প্রয়োজনীয় কাগজপত্র:
   - ...
🛠️ প্রক্রিয়া:
   ধাপ ১: ...
   ধাপ ২: ...
🏢 দায়িত্বপ্রাপ্ত কাউন্টার: <UDC/সচিব/চেয়ারম্যান>
⚠️ গুরুত্বপূর্ণ নোট: ...
📝 রিপোর্ট নং বিশ্লেষণ: (শুধু রিপোর্ট নং দেওয়া থাকলে)
✅ করণীয়: ...
📞 যোগাযোগ: কল | WhatsApp | SMS | ইমেইল (আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন)
🤝 আরও কোনো সহায়তা লাগলে আমাকে জানাতে পারেন।

Restrictions:
- Do NOT invent information or fake contact numbers.
- Do NOT guess fees or rules.
- Do NOT declare official approvals or rejections.
- Do NOT collect sensitive private credentials.
- Do NOT provide unofficial political or legal advice.`;

// Grounding Knowledge Base context string
function getKnowledgeBaseContext(): string {
  return SERVICES_DATA.map((s) => {
    return `[সেবা: ${s.name}]
বিবরণ: ${s.shortDescription}
কাউন্টার: ${s.counter}
প্রয়োজনীয় কাগজপত্র: ${s.requiredDocuments.join(', ')}
প্রক্রিয়াকরণ ধাপসমূহ: ${s.applicationProcess.join(' -> ')}
জরুরি নোট: ${s.importantNotes.join('; ')}
কমন ভুল: ${s.commonMistakes.join('; ')}
অফিসিয়াল ফি তথ্য (যদি থাকে): ${s.fee}`;
  }).join('\n\n');
}

// Grounding Citizen Reports Database context string
function getCitizenReportsContext(): string {
  return CITIZEN_REPORTS_DATA.map((r) => {
    return `[রিপোর্ট নং: ${r.reportNo}]
নাগরিকের নাম: ${r.citizenName}
সেবা: ${r.serviceName}
পূর্বের সমস্যা: ${r.previousIssue}
যোগাযোগের কারণ: ${r.reasonForContact}
সম্পর্কিত নথি: ${r.relatedDocuments.join(', ')}
আটকে থাকা ধাপ: ${r.stuckStep}
বর্তমান অবস্থা: ${r.currentStatus}
দায়িত্বপ্রাপ্ত কাউন্টার: ${r.counter}
সুপারিশকৃত করণীয়: ${r.recommendedAction}`;
  }).join('\n\n');
}

// Fallback response generator if Gemini API key is missing or offline
function generateFallbackResponse(userMessage: string, serviceId?: string): string {
  const query = userMessage.trim();
  const queryLower = query.toLowerCase();
  
  // 1. Check if user provided a "রিপোর্ট নং" or referenced report
  const isReportQuery = queryLower.includes('রিপোর্ট') || 
                        queryLower.includes('report') || 
                        /BT[-_]?(?:REP[-_]?)?\d+/i.test(query);

  const matchedReport = findReportByNo(query);

  if (matchedReport) {
    const docs = matchedReport.relatedDocuments.map(d => `   - ${d}`).join('\n');
    return `📌 সেবা: ${matchedReport.serviceName}
📄 প্রয়োজনীয় কাগজপত্র:
${docs}
🏢 দায়িত্বপ্রাপ্ত কাউন্টার: ${matchedReport.counter}
⚠️ গুরুত্বপূর্ণ নোট: আটকে থাকা ধাপ — ${matchedReport.stuckStep}
📝 রিপোর্ট নং বিশ্লেষণ: [${matchedReport.reportNo}] নাগরিক: ${matchedReport.citizenName}। পূর্বের সমস্যা: ${matchedReport.previousIssue}। যোগাযোগের কারণ: ${matchedReport.reasonForContact}। বর্তমান অবস্থা: ${matchedReport.currentStatus}।
✅ করণীয়: ${matchedReport.recommendedAction}
📞 যোগাযোগ: কল | WhatsApp | SMS | ইমেইল (আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন)
🤝 আরও কোনো সহায়তা লাগলে আমাকে জানাতে পারেন।`;
  }

  // If user explicitly entered/asked about an unknown report number
  if (isReportQuery) {
    return `আপনার প্রদত্ত রিপোর্ট নং সিস্টেমে পাওয়া যায়নি। অনুগ্রহ করে সঠিক রিপোর্ট নং প্রদান করুন।`;
  }

  // 2. Check if asking for contact
  if (
    queryLower.includes('যোগাযোগ') || 
    queryLower.includes('ফোন') || 
    queryLower.includes('মোবাইল') || 
    queryLower.includes('নাম্বার') || 
    queryLower.includes('contact') || 
    queryLower.includes('হোয়াটসঅ্যাপ') || 
    queryLower.includes('whatsapp')
  ) {
    return `আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন।

বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল হেল্পডেস্ক:
• UDC উদ্যোক্তা: ${currentOperator.name}
• মোবাইল/এসএমএস: ${currentOperator.phone}
• কার্যালয়: ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ, সখিপুর, টাঙ্গাইল
(অনুগ্রহ করে কল না করে লিখিত মেসেজ পাঠানোর অনুরোধ রইলো)`;
  }

  // 3. Service explanation rules
  let matchedService = SERVICES_DATA.find(s => s.id === serviceId);
  if (!matchedService) {
    if (queryLower.includes('জন্ম') || queryLower.includes('birth')) {
      matchedService = SERVICES_DATA.find(s => s.id === 'birth-reg');
    } else if (queryLower.includes('মৃত্যু') || queryLower.includes('death')) {
      matchedService = SERVICES_DATA.find(s => s.id === 'death-reg');
    } else if (queryLower.includes('নাগরিক') || queryLower.includes('citizen')) {
      matchedService = SERVICES_DATA.find(s => s.id === 'citizen-cert');
    } else if (queryLower.includes('চারিত্রিক') || queryLower.includes('character')) {
      matchedService = SERVICES_DATA.find(s => s.id === 'character-cert');
    } else if (queryLower.includes('অবিবাহিত') || queryLower.includes('unmarried')) {
      matchedService = SERVICES_DATA.find(s => s.id === 'unmarried-cert');
    } else if (queryLower.includes('ওয়ারিশ') || queryLower.includes('উত্তরাধিকার') || queryLower.includes('warish')) {
      matchedService = SERVICES_DATA.find(s => s.id === 'warish-cert');
    } else if (queryLower.includes('প্রত্যয়ন') || queryLower.includes('প্রত্যয়ন')) {
      matchedService = SERVICES_DATA.find(s => s.id === 'attestation-cert');
    } else if (queryLower.includes('ভাতা') || queryLower.includes('বয়স্ক') || queryLower.includes('বিধবা') || queryLower.includes('প্রতিবন্ধী')) {
      matchedService = SERVICES_DATA.find(s => s.id === 'social-welfare');
    }
  }

  if (matchedService) {
    const docs = matchedService.requiredDocuments.map(d => `   - ${d}`).join('\n');
    const steps = matchedService.applicationProcess.map((step, i) => `   ধাপ ${i + 1}: ${step}`).join('\n');
    const notes = matchedService.importantNotes.length > 0 
      ? matchedService.importantNotes.join('; ')
      : 'দালালমুক্ত সেবা পেতে সরাসরি ইউনিয়ন পরিষদ কার্যালয়ে আসুন।';

    return `📌 সেবা: ${matchedService.name}
📄 প্রয়োজনীয় কাগজপত্র:
${docs}
🛠️ প্রক্রিয়া:
${steps}
🏢 দায়িত্বপ্রাপ্ত কাউন্টার: ${matchedService.counter}
⚠️ গুরুত্বপূর্ণ নোট: ${notes}
✅ করণীয়: প্রয়োজনীয় কাগজপত্র প্রস্তুত করে ইউনিয়ন ডিজিটাল সেন্টার (UDC) বা সংশ্লিষ্ট কাউন্টারে জমা দিন।
📞 যোগাযোগ: কল | WhatsApp | SMS | ইমেইল (আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন)
🤝 আরও কোনো সহায়তা লাগলে আমাকে জানাতে পারেন।`;
  }

  // 4. Default fallback for unknown or uncertain topics
  return `এই বিষয়ে নিশ্চিত তথ্য আমার কাছে নেই। অনুগ্রহ করে ইউনিয়ন পরিষদে যোগাযোগ করুন।`;
}

// 1. Chat API Endpoint (Powers Web Assistant & Citizen Dialogues)
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { 
      message, 
      serviceName,
      reportNumber,
      context,
      citizenProfile,
      serviceData,
      contactDirectory,
      history = [], 
      serviceId, 
      phone = '01XXXXXXXXX', 
      channel = 'web' 
    } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    const chatbotResult = await handleChatbotMessageInternal({
      message,
      serviceName,
      reportNumber,
      context,
      citizenProfile,
      serviceData,
      contactDirectory,
      phone,
      channel: channel as 'whatsapp' | 'call' | 'web',
      serviceId,
      history
    });

    res.json({ 
      reply: chatbotResult.reply_text,
      ...chatbotResult
    });
  } catch (error: any) {
    console.error('Chat endpoint error:', error);
    res.status(500).json({
      error: 'এই মুহূর্তে সাময়িক সমস্যা দেখা দিয়েছে। আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন।',
      reply: 'এই মুহূর্তে সাময়িক সমস্যা দেখা দিয়েছে। আপনি চাইলে হেল্পডেস্কের কল/এসএমএস/হোয়াটসঅ্যাপ বাটন ব্যবহার করতে পারেন।'
    });
  }
});

// WhatsApp / Make.com Webhook Endpoint (matching doPost(e) in AI_Chatbot.gs)
app.post('/api/webhook/whatsapp', async (req: Request, res: Response) => {
  try {
    const { message, phone = '01XXXXXXXXX', channel = 'whatsapp' } = req.body;
    if (!message) {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    const result = await handleChatbotMessageInternal({
      message,
      phone,
      channel: (channel as 'whatsapp' | 'call' | 'web') || 'whatsapp'
    });
    // Returns exact Make.com webhook compatible payload
    res.json({ 
      reply: result.reply_text,
      intent: result.intent,
      category: result.category,
      confidence_score: result.confidence_score,
      needs_escalation: result.needs_escalation,
      ticket_summary: result.ticket_summary,
      ticket_id: result.ticket_id || null,
      formatted_response: result.formatted_response
    });
  } catch (err: any) {
    console.error('WhatsApp webhook error:', err);
    res.status(500).json({ 
      error: err?.message || 'Server error',
      reply: 'দুঃখিত, এই মুহূর্তে সাড়া দিতে সমস্যা হচ্ছে। একজন স্টাফ শীঘ্রই যোগাযোগ করবেন।'
    });
  }
});

// Generic Chatbot API Endpoint (for Multi-channel integration)
app.post('/api/chatbot', async (req: Request, res: Response) => {
  try {
    const { 
      message, 
      serviceName,
      reportNumber,
      context,
      citizenProfile,
      serviceData,
      contactDirectory,
      phone = '01XXXXXXXXX', 
      channel = 'whatsapp', 
      serviceId, 
      history = [] 
    } = req.body;
    if (!message) {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    const result = await handleChatbotMessageInternal({
      message,
      serviceName,
      reportNumber,
      context,
      citizenProfile,
      serviceData,
      contactDirectory,
      phone,
      channel: (channel as 'whatsapp' | 'call' | 'web') || 'whatsapp',
      serviceId,
      history
    });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Tickets Endpoint (List all complaints/suggestions registered as tickets)
app.get('/api/tickets', (_req: Request, res: Response) => {
  res.json({
    tickets: ticketsDatabase,
    total: ticketsDatabase.length
  });
});

// Create manual ticket or update status
app.post('/api/tickets/:id/status', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;
  const ticket = ticketsDatabase.find(t => t.ticketId === id);
  if (!ticket) {
    res.status(404).json({ error: 'Ticket not found' });
    return;
  }
  if (status) {
    ticket.status = status;
  }
  res.json({ success: true, ticket });
});

// Escalation Queue Endpoint (Staff review queue)
app.get('/api/escalations', (_req: Request, res: Response) => {
  res.json({
    escalations: escalationQueue,
    total: escalationQueue.length
  });
});

// Mark escalation as handled
app.post('/api/escalations/:id/handle', (req: Request, res: Response) => {
  const { id } = req.params;
  const esc = escalationQueue.find(e => e.id === id);
  if (!esc) {
    res.status(404).json({ error: 'Escalation item not found' });
    return;
  }
  esc.handled = 'হ্যাঁ';
  res.json({ success: true, escalation: esc });
});

// Citizen phone lookup endpoint (UPMS Citizen DB)
app.get('/api/citizens/lookup', (req: Request, res: Response) => {
  const phone = (req.query.phone as string || '').trim();
  const citizen = lookupCitizenByPhone(phone);
  if (citizen) {
    res.json({ found: true, citizen });
  } else {
    res.json({ found: false, message: 'এই ফোন নম্বরটি ডেটাবেসে পাওয়া যায়নি — নতুন নাগরিক হতে পারে।' });
  }
});

// 2. Services List Endpoint
app.get('/api/services', (_req: Request, res: Response) => {
  res.json({
    services: SERVICES_DATA,
    operator: currentOperator,
  });
});

// 3. Operator Profile Endpoint
app.get('/api/operator', (_req: Request, res: Response) => {
  res.json(currentOperator);
});

// Update operator profile / photo
app.post('/api/operator', (req: Request, res: Response) => {
  try {
    const { name, phone, email, whatsappUrl, facebookUrl, photoUrl } = req.body;
    if (name) currentOperator.name = name;
    if (phone) currentOperator.phone = phone;
    if (email) currentOperator.email = email;
    if (whatsappUrl) currentOperator.whatsappUrl = whatsappUrl;
    if (facebookUrl) currentOperator.facebookUrl = facebookUrl;
    if (photoUrl) currentOperator.photoUrl = photoUrl;

    res.json({ success: true, operator: currentOperator });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update operator profile' });
  }
});

// Contact Directory Endpoint (Provides hierarchy, ward members, UDC operator and staff)
app.get('/api/contacts', (_req: Request, res: Response) => {
  res.json(CONTACT_DIRECTORY_DATA);
});

// 4. Citizen Report & Status Verification Endpoint
app.get('/api/application-status', (req: Request, res: Response) => {
  const queryId = (req.query.reportNo as string || req.query.trackingId as string || '').trim();
  const phone = (req.query.phone as string || '').trim();

  if (!queryId && !phone) {
    res.status(400).json({ 
      found: false,
      message: 'অনুগ্রহ করে সঠিক রিপোর্ট নং প্রদান করুন।' 
    });
    return;
  }

  const matchedReport = findReportByNo(queryId);

  if (matchedReport) {
    res.json({
      found: true,
      reportNo: matchedReport.reportNo,
      trackingId: matchedReport.reportNo,
      applicantName: matchedReport.citizenName,
      serviceName: matchedReport.serviceName,
      previousIssue: matchedReport.previousIssue,
      reasonForContact: matchedReport.reasonForContact,
      relatedDocuments: matchedReport.relatedDocuments,
      stuckStep: matchedReport.stuckStep,
      status: 'processing',
      statusText: matchedReport.currentStatus,
      submissionDate: matchedReport.submissionDate || '১০ মার্চ ২০২৫',
      counter: matchedReport.counter,
      recommendedAction: matchedReport.recommendedAction,
      message: `আপনার রিপোর্ট নং ${matchedReport.reportNo}-এর বর্তমান অগ্রগতি: ${matchedReport.currentStatus}।`
    });
    return;
  }

  // Official instruction when not found
  res.json({
    found: false,
    reportNo: queryId,
    trackingId: queryId,
    message: 'আপনার প্রদত্ত রিপোর্ট নং সিস্টেমে পাওয়া যায়নি। অনুগ্রহ করে সঠিক রিপোর্ট নং প্রদান করুন।'
  });
});

// Helper to find matching service from knowledge base
function findMatchingServiceFromKB(text: string): typeof SERVICES_DATA[0] | undefined {
  if (!text) return undefined;
  const q = text.toLowerCase().trim();

  // Exact ID or Name match
  const byExact = SERVICES_DATA.find(s => s.id === q || s.name.toLowerCase() === q);
  if (byExact) return byExact;

  // Keyword match
  if (q.includes('জন্ম') || q.includes('birth')) {
    return SERVICES_DATA.find(s => s.id === 'birth-reg');
  }
  if (q.includes('মৃত্যু') || q.includes('death')) {
    return SERVICES_DATA.find(s => s.id === 'death-reg');
  }
  if (q.includes('ওয়ারিশ') || q.includes('ওয়ারিশ') || q.includes('উত্তরাধিকার') || q.includes('warishan')) {
    return SERVICES_DATA.find(s => s.id === 'warishan');
  }
  if (q.includes('নাগরিক') || q.includes('জাতীয়তা') || q.includes('citizenship')) {
    return SERVICES_DATA.find(s => s.id === 'citizenship');
  }
  if (q.includes('ট্রেড') || q.includes('ব্যবসা') || q.includes('বাণিজ্যিক') || q.includes('লাইসেন্স') || q.includes('trade')) {
    return SERVICES_DATA.find(s => s.id === 'trade-license');
  }
  if (q.includes('চারিত্রিক') || q.includes('character')) {
    return SERVICES_DATA.find(s => s.id === 'character-cert');
  }
  if (q.includes('ভূমিহীন') || q.includes('landless')) {
    return SERVICES_DATA.find(s => s.id === 'landless-cert');
  }
  if (q.includes('পারিবারিক') || q.includes('family')) {
    return SERVICES_DATA.find(s => s.id === 'family-cert');
  }
  if (q.includes('ভাতা') || q.includes('বয়স্ক') || q.includes('বিধবা') || q.includes('প্রতিবন্ধী') || q.includes('allowance')) {
    return SERVICES_DATA.find(s => s.id === 'allowance');
  }
  if (q.includes('ট্যাক্স') || q.includes('হোল্ডিং') || q.includes('খাজনা') || q.includes('tax')) {
    return SERVICES_DATA.find(s => s.id === 'holding-tax');
  }
  if (q.includes('ড্রেন') || q.includes('নর্দমা') || q.includes('জলাবদ্ধ') || q.includes('drainage')) {
    return SERVICES_DATA.find(s => s.id === 'drainage');
  }
  if (q.includes('রাস্তা') || q.includes('সড়ক') || q.includes('কালভার্ট') || q.includes('road')) {
    return SERVICES_DATA.find(s => s.id === 'road-repair');
  }
  if (q.includes('পানি') || q.includes('টিউবওয়েল') || q.includes('নলকূপ') || q.includes('water')) {
    return SERVICES_DATA.find(s => s.id === 'tubewell');
  }

  // Fallback match on service name inclusion
  return SERVICES_DATA.find(s => q.includes(s.name.toLowerCase()) || s.name.toLowerCase().includes(q));
}

// 5. Office Hours endpoint
app.get('/api/office-hours', (_req: Request, res: Response) => {
  res.json(OFFICE_HOURS);
});

// 6. WhatsApp Q1-Q7 Flowchart State Machine API & General Flowchart
app.post('/api/flowchart/step', async (req: Request, res: Response) => {
  try {
    const { 
      step = 'start', 
      name, 
      mobile, 
      reportNumber, 
      issueText,
      // 7-step specific fields
      q1_name,
      q2_mobile,
      q3_previous_contact,
      q4_service,
      q5_purpose,
      q6_documents_time,
      q7_prior_submission,
      userResponse
    } = req.body;

    // =========================================================================
    // 💬 7-STEP WHATSAPP ONBOARDING FLOWCHART (Citizen → WhatsApp Message)
    // =========================================================================
    // Q1: নাম
    if (step === 'whatsapp_start' || step === 'q1' || step === 'q1_name') {
      res.json({
        flowType: 'whatsapp_q1_q7',
        currentStep: 'q1_name',
        stepNumber: 1,
        totalSteps: 7,
        title: 'Q1: নাম',
        reply: 'স্বাগতম! ০২নং বহেড়াতৈল ইউনিয়ন পরিষদ ডিজিটাল হেল্পডেস্কে আপনাকে স্বাগতম। 🌿\n\n(প্রশ্ন ১/৭) অনুগ্রহ করে আপনার শুভ নামটি জানাবেন?',
        quickOptions: ['মো: শফিকুল ইসলাম', 'মোছা: মরিয়ম বেগম', 'আব্দুর রহিম'],
        nextStep: 'q2_mobile'
      });
      return;
    }

    // Q2: মোবাইল WhatsApp থেকে পাওয়া
    if (step === 'q2' || step === 'q2_mobile') {
      const citizenName = (q1_name || name || userResponse || '').trim();
      res.json({
        flowType: 'whatsapp_q1_q7',
        currentStep: 'q2_mobile',
        stepNumber: 2,
        totalSteps: 7,
        title: 'Q2: মোবাইল WhatsApp থেকে পাওয়া',
        citizenName,
        reply: `${citizenName ? citizenName + ', ' : ''}ধন্যবাদ!\n\n(প্রশ্ন ২/৭) আপনার সচল মোবাইল নম্বরটি দিন (WhatsApp থেকে পাওয়া বা আপনার ১১ ডিজিটের নম্বর)।`,
        quickOptions: [mobile || '01711000001', '01834333300'],
        nextStep: 'q3_previous_contact'
      });
      return;
    }

    // Q3: পূর্বে যোগাযোগ করেছেন?
    if (step === 'q3' || step === 'q3_previous_contact') {
      const phoneInput = (q2_mobile || mobile || userResponse || '').trim();
      const existing = lookupCitizenByPhone(phoneInput) || dynamicCitizens.find(c => c.mobile === phoneInput);

      let contextNote = '';
      if (existing) {
        contextNote = `\n[UPMS সিস্টেমে আপনার পূর্বের প্রোফাইল (${existing.name}) পাওয়া গেছে]`;
      }

      res.json({
        flowType: 'whatsapp_q1_q7',
        currentStep: 'q3_previous_contact',
        stepNumber: 3,
        totalSteps: 7,
        title: 'Q3: পূর্বে যোগাযোগ করেছেন?',
        isReturning: !!existing,
        existingRecord: existing || null,
        reply: `(প্রশ্ন ৩/৭) আপনি কি পূর্বে ইউনিয়ন পরিষদে বা হেল্পডেস্কে এই বিষয়ে যোগাযোগ করেছেন? [হ্যাঁ / না]${contextNote}\n(পূর্বে যোগাযোগ থাকলে বা কোনো পূর্ববর্তী রিপোর্ট নং জানা থাকলে তাও জানাতে পারেন)`,
        quickOptions: ['না, এই প্রথমবার', 'হ্যাঁ, পূর্বে যোগাযোগ করেছিলাম', 'হ্যাঁ, আমার পূর্বের রিপোর্ট নং আছে'],
        nextStep: 'q4_service'
      });
      return;
    }

    // Q4: কোন সেবা?
    if (step === 'q4' || step === 'q4_service') {
      res.json({
        flowType: 'whatsapp_q1_q7',
        currentStep: 'q4_service',
        stepNumber: 4,
        totalSteps: 7,
        title: 'Q4: কোন সেবা?',
        reply: '(প্রশ্ন ৪/৭) আপনি ইউনিয়ন পরিষদের কোন সেবাটি গ্রহণ করতে চান?\n(যেমন: জন্ম নিবন্ধন, নাগরিকত্ব সনদ, ওয়ারিশান সনদ, ট্রেড লাইসেন্স, মৃত্যু নিবন্ধন, বয়স্ক/বিধবা ভাতা, রাস্তা/ড্রেন সংস্কার ইত্যাদি)',
        quickOptions: ['জন্ম নিবন্ধন', 'নাগরিকত্ব সনদ', 'ওয়ারিশান সনদ', 'ট্রেড লাইসেন্স', 'বয়স্ক/বিধবা ভাতা', 'রাস্তা/ড্রেন সংস্কার'],
        nextStep: 'q5_purpose'
      });
      return;
    }

    // Q5: উদ্দেশ্য?
    if (step === 'q5' || step === 'q5_purpose') {
      const selectedService = (q4_service || userResponse || '').trim();
      res.json({
        flowType: 'whatsapp_q1_q7',
        currentStep: 'q5_purpose',
        stepNumber: 5,
        totalSteps: 7,
        title: 'Q5: উদ্দেশ্য?',
        service: selectedService,
        reply: `(প্রশ্ন ৫/৭) ${selectedService ? selectedService + ' সংক্রান্ত ' : ''}আপনার মূল উদ্দেশ্য বা সুনির্দিষ্ট আবেদনটি কী?\n(যেমন: নতুন আবেদন দাখিল, ভুল তথ্য সংশোধন, আবেদনের স্ট্যাটাস/অগ্রগতি যাচাই, অভিযোগ দাখিল বা নিয়মাবলি ও ফি জানা)`,
        quickOptions: ['নতুন আবেদন দাখিল করতে চাই', 'ভুল তথ্য সংশোধন প্রয়োজন', 'আবেদনের বর্তমান অগ্রগতি জানতে চাই', 'প্রয়োজনীয় কাগজপত্র ও ফি জানতে চাই'],
        nextStep: 'q6_documents_time'
      });
      return;
    }

    // Q6: কাগজপত্র/সময়?
    if (step === 'q6' || step === 'q6_documents_time') {
      res.json({
        flowType: 'whatsapp_q1_q7',
        currentStep: 'q6_documents_time',
        stepNumber: 6,
        totalSteps: 7,
        title: 'Q6: কাগজপত্র/সময়?',
        reply: '(প্রশ্ন ৬/৭) প্রয়োজনীয় কাগজপত্র (NID, পিতা-মাতার সনদ, ছবি, ট্যাক্স রশিদ ইত্যাদি) কি আপনার কাছে প্রস্তুত আছে? এবং কতদিনের মধ্যে সেবাটি আপনার প্রয়োজন?',
        quickOptions: ['হ্যাঁ, প্রয়োজনীয় সব কাগজ প্রস্তুত আছে', 'কিছু কাগজ বাকি আছে, ২-৩ দিন সময় লাগবে', 'জরুরি ভিত্তিতে দ্রুত প্রয়োজন'],
        nextStep: 'q7_prior_submission'
      });
      return;
    }

    // Q7: পূর্বে জমা দেওয়া কাজ?
    if (step === 'q7' || step === 'q7_prior_submission') {
      res.json({
        flowType: 'whatsapp_q1_q7',
        currentStep: 'q7_prior_submission',
        stepNumber: 7,
        totalSteps: 7,
        title: 'Q7: পূর্বে জমা দেওয়া কাজ?',
        reply: '(প্রশ্ন ৭/৭) পূর্বে কি এই সংক্রান্ত কোনো আবেদন বা কাগজপত্র ইউনিয়ন ডিজিটাল সেন্টার (UDC) বা সচিব/চেয়ারম্যান কার্যালয়ে জমা দেওয়া হয়েছিল? (হ্যাঁ / না / বিস্তারিত)',
        quickOptions: ['না, এখনও জমা দেইনি', 'হ্যাঁ, ইউডিসি কাউন্টারে জমা দেওয়া আছে', 'অনলাইনে আবেদন জমা দেওয়া হয়েছিল'],
        nextStep: 'whatsapp_summary'
      });
      return;
    }

    // AI → Summary + Report Number + Final Guidance
    if (step === 'whatsapp_summary' || step === 'finish_whatsapp') {
      const citizenName = (q1_name || name || 'নাগরিক').trim();
      const citizenMobile = (q2_mobile || mobile || '01711000001').trim();
      const prevContact = (q3_previous_contact || userResponse || 'না').trim();
      const serviceQuery = (q4_service || 'সাধারণ নাগরিক সেবা').trim();
      const purpose = (q5_purpose || 'নাগরিক সেবা গ্রহণ').trim();
      const docsTime = (q6_documents_time || 'কাগজপত্র প্রস্তুত আছে').trim();
      const priorSub = (q7_prior_submission || userResponse || 'না').trim();

      // Generate numeric report number (≥ 5 digits)
      const newReportNo = generateNumericReportNumber();

      // Match with Knowledge Base
      const matchedService = findMatchingServiceFromKB(serviceQuery);
      const serviceName = matchedService ? matchedService.name : serviceQuery;
      const counter = matchedService ? matchedService.counter : 'ইউনিয়ন ডিজিটাল সেন্টার (UDC)';
      const fee = matchedService ? matchedService.fee : 'সরকারি নিয়মানুযায়ী নির্ধারিত ফি';
      const procTime = matchedService ? matchedService.processingTime : '৩ থেকে ৭ কার্যদিবস';
      const reqDocs = matchedService ? matchedService.requiredDocuments : [
        'জাতীয় পরিচয়পত্র (NID) / অনলাইন জন্ম নিবন্ধন সনদের ফটোকপি',
        'হালনাগাদ হোল্ডিং ট্যাক্স বা নাগরিকত্বের প্রত্যয়ন',
        'পাসপোর্ট সাইজ ছবি ও সচল মোবাইল নম্বর'
      ];
      const stepsList = matchedService ? matchedService.applicationProcess : [
        '১) প্রয়োজনীয় সকল মূল কাগজপত্র ও সত্যায়িত ফটোকপি প্রস্তুত করুন।',
        '২) ০২নং বহেড়াতৈল ইউনিয়ন ডিজিটাল সেন্টার (UDC) কাউন্টারে আবেদন ফরম পূরণ ও জমা দিন।',
        '৩) সচিব ও চেয়ারম্যান মহোদয়ের স্বাক্ষরের পর মূল সনদ সংগ্রহ করুন।'
      ];

      // Save dynamic citizen and report
      dynamicCitizens.push({
        name: citizenName,
        mobile: citizenMobile,
        reportNumber: newReportNo,
        issueText: `${serviceName} - ${purpose}`,
        createdAt: new Date().toISOString()
      });

      const reportRecord: DynamicReportRecord = {
        reportNo: newReportNo,
        citizenName,
        mobile: citizenMobile,
        serviceName,
        previousIssue: `উদ্দেশ্য: ${purpose} | পূর্বে যোগাযোগ: ${prevContact} | পূর্বে জমা: ${priorSub}`,
        reasonForContact: purpose,
        relatedDocuments: reqDocs,
        stuckStep: priorSub.includes('হ্যাঁ') ? 'কাউন্টারে জমাদানকৃত ফাইল পর্যালোচনাধীন' : 'আবেদন ও কাগজপত্র দাখিলের অপেক্ষায়',
        currentStatus: 'WhatsApp অনবোর্ডিং সম্পন্ন ও রিপোর্ট নথিভুক্ত',
        counter,
        recommendedAction: priorSub.includes('হ্যাঁ') 
          ? `আপনার রিপোর্ট নং (${newReportNo}) প্রদর্শন করে সরাসরি ${counter}-এ ফাইলের অগ্রগতি যাচাই করুন।` 
          : `প্রয়োজনীয় কাগজপত্র প্রস্তুত করে ইউনিয়ন ডিজিটাল সেন্টারে (UDC) জমা দিন।`,
        submissionDate: new Date().toLocaleDateString('bn-BD')
      };
      dynamicReports.push(reportRecord);

      // Add to ticket database
      const newTicket: TicketItem = {
        ticketId: `TICK-${newReportNo}`,
        timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        phone: citizenMobile,
        channel: 'whatsapp',
        intent: 'servicequery',
        category: detectCategoryFromText(serviceName + ' ' + purpose),
        summary: `নাগরিক: ${citizenName} | সেবা: ${serviceName} | উদ্দেশ্য: ${purpose} | রিপোর্ট নং: ${newReportNo}`,
        status: 'গৃহীত'
      };
      ticketsDatabase.unshift(newTicket);

      // Formatted Response Model
      const fr = createEmptyFormattedResponse();
      fr.service = serviceName;
      fr.documents = reqDocs;
      fr.steps = stepsList;
      fr.counter = counter;
      fr.notes = [
        `সরকারি ফি: ${fee}`,
        `আনুমানিক সময়: ${procTime}`,
        'দালাল বা মধ্যস্বত্বভোগী পরিহার করুন। সরাসরি ইউনিয়ন পরিষদ কার্যালয়ে আসুন।'
      ];
      fr.report_analysis = {
        reportNumber: newReportNo,
        summary: `নাগরিক: ${citizenName} (${citizenMobile}) | সেবা: ${serviceName} | উদ্দেশ্য: ${purpose}`,
        possible_reason: priorSub.includes('হ্যাঁ') ? 'পূর্বে আবেদন জমা দেওয়া হয়েছিল, বর্তমান স্ট্যাটাস যাচাই প্রয়োজন' : 'নতুন সেবা গ্রহীতা, প্রাথমিক পরামর্শ প্রদান করা হয়েছে',
        recommended_action: reportRecord.recommendedAction
      };

      // Construct comprehensive Bangla AI Guidance message
      const finalReply = 
`📋 **নাগরিক আবেদন ও কথোপকথন সারসংক্ষেপ (WhatsApp Summary):**
• নাম (Q1): ${citizenName}
• মোবাইল (WhatsApp Q2): ${citizenMobile}
• পূর্বে যোগাযোগ (Q3): ${prevContact}
• নির্বাচিত সেবা (Q4): ${serviceName}
• উদ্দেশ্য (Q5): ${purpose}
• কাগজপত্র ও সময়সীমা (Q6): ${docsTime}
• পূর্বে জমা দেওয়া কাজ (Q7): ${priorSub}

🎫 **আপনার অফিসিয়াল রিপোর্ট নং (Report Number):**
👉 **${newReportNo}**
*(ভবিষ্যতে ইউডিসি ও ইউনিয়ন পরিষদে এই কাজের অগ্রগতি জানতে বা ট্র্যাকিং করতে এই নম্বরটি প্রদর্শন করুন)*

📌 **সেবা:** ${serviceName}

📄 **প্রয়োজনীয় কাগজপত্র:**
${reqDocs.map(d => `• ${d}`).join('\n')}

⏱️ **প্রক্রিয়াকরণ সময় ও সরকারি ফি:**
• সরকারি ফি: ${fee}
• প্রসেসিং সময়: ${procTime}

🏢 **দায়িত্বপ্রাপ্ত কাউন্টার:** ${counter}

👉 **পরিস্থিতি পর্যালোচনা ও সম্ভাব্য কারণ:**
${priorSub.includes('হ্যাঁ') 
  ? 'পূর্বে কাউন্টারে কাগজপত্র জমা দেওয়া হয়েছিল। ফাইলের বর্তমান অবস্থা যাচাই করে দ্রুত নিষ্পত্তি করা সম্ভব।' 
  : 'আপনার আবেদনটি নতুন হিসেবে নিবন্ধিত হয়েছে। সকল প্রয়োজনীয় কাগজপত্র প্রস্তুত রেখে কাউন্টারে জমা দিলেই দ্রুত সেবা পাবেন।'}

✅ **চূড়ান্ত দিকনির্দেশনা (Final Guidance):**
১. আপনার সকল প্রয়োজনীয় মূল কাগজপত্র ও ফটোকপির সাথে রিপোর্ট নং **${newReportNo}** সংগ্রহে রাখুন।
২. সরাসরি ${counter}-এ গিয়ে উদ্যোক্তা বা দায়িত্বে নিয়োজিত কর্মকর্তার কাছে আবেদন পেশ করুন।
৩. যাচাই-বাছাই ও সচিব/চেয়ারম্যান মহোদয়ের অনুমোদনের পর নির্ধারিত সময়ে মূল সনদ/সেবা বুঝে নিন।

⚠️ **জরুরি সতর্কতা:**
দালালমুক্ত সেবা পেতে সরাসরি ইউনিয়ন পরিষদ কার্যালয়ে আসুন। সরকারি ফি ছাড়া কোনো অতিরিক্ত অর্থ প্রদান করবেন না।

📞 **হেল্পডেস্ক ও WhatsApp সরাসরি যোগাযোগ:**
• সরাসরি কল: ${currentOperator.phone}
• WhatsApp চ্যাট: ${currentOperator.whatsappUrl}
• অফিস আওয়ার: ${OFFICE_HOURS.displayText}`;

      res.json({
        flowType: 'whatsapp_q1_q7',
        currentStep: 'completed',
        stepNumber: 8,
        totalSteps: 7,
        generated_report_number: newReportNo,
        citizenName,
        mobile: citizenMobile,
        serviceName,
        reply: finalReply,
        formatted_response: fr,
        office_hours: {
          call_available: OFFICE_HOURS.call_available,
          closed: OFFICE_HOURS.closed
        },
        report: reportRecord
      });
      return;
    }

    // =========================================================================
    // Backward-Compatible 5-Step Mode (Fallback)
    // =========================================================================
    // 1️⃣ Entry & Greeting:
    if (step === 'start') {
      res.json({
        reply: 'আপনার নামটি জানাবেন?',
        currentStep: 'ask_name',
        nextStep: 'ask_mobile'
      });
      return;
    }

    if (step === 'name') {
      const citizenName = (name || '').trim();
      res.json({
        reply: `${citizenName ? citizenName + ', ' : ''}আপনার মোবাইল নম্বরটি দিন।`,
        currentStep: 'ask_mobile',
        nextStep: 'check_previous'
      });
      return;
    }

    // 2️⃣ Check previous chat (returning vs new):
    if (step === 'mobile') {
      const phoneInput = (mobile || '').trim();
      const existing = lookupCitizenByPhone(phoneInput) || dynamicCitizens.find(c => c.mobile === phoneInput);

      if (existing) {
        res.json({
          isReturning: true,
          citizenName: existing.name,
          reply: 'আপনি পূর্বে আমাদের সাথে যোগাযোগ করেছেন। অনুগ্রহ করে আপনার রিপোর্ট নং দিন।',
          currentStep: 'returning_citizen',
          nextStep: 'validate_report'
        });
        return;
      } else {
        res.json({
          isReturning: false,
          reply: 'আপনি নতুন নাগরিক হিসেবে যুক্ত হচ্ছেন। অনুগ্রহ করে আপনার সমস্যাটি লিখুন বা ভয়েসে বলুন।',
          currentStep: 'new_citizen',
          nextStep: 'new_issue'
        });
        return;
      }
    }

    // VALIDATE reportNumber:
    if (step === 'validate_report') {
      const repNum = (reportNumber || '').trim();
      if (!validateNumericReportNumber(repNum)) {
        res.json({
          valid: false,
          reply: 'রিপোর্ট নং শুধুমাত্র সংখ্যা হবে এবং কমপক্ষে ৫ ডিজিট হতে হবে।',
          currentStep: 'returning_citizen',
          nextStep: 'validate_report'
        });
        return;
      }

      // Valid: fetch previous conversation by reportNumber
      const matched = findReportByNo(repNum) || dynamicReports.find(r => r.reportNo === repNum);
      if (matched) {
        const fr = createEmptyFormattedResponse();
        fr.service = matched.serviceName;
        fr.documents = [...matched.relatedDocuments];
        fr.counter = matched.counter;
        fr.notes = [
          `বর্তমান অবস্থা: ${matched.currentStatus}`,
          `আটকে থাকা ধাপ: ${matched.stuckStep}`
        ];
        fr.report_analysis = {
          reportNumber: matched.reportNo,
          summary: `পূর্বের সমস্যা: ${matched.previousIssue}`,
          possible_reason: `আটকে থাকা ধাপ: ${matched.stuckStep}`,
          recommended_action: matched.recommendedAction
        };

        const reply = `📌 আপনার পূর্বের রিপোর্ট পর্যালোচনা (${matched.reportNo}):\n\n• পূর্বের সমস্যা (Previous Summary): ${matched.previousIssue}\n• পূর্বের ধাপসমূহ (Previous Steps): ${matched.stuckStep}\n• আটকে থাকার কারণ (Pending Reason): ${matched.reasonForContact}\n• বর্তমান অবস্থা: ${matched.currentStatus}\n\n✅ আপডেট দিকনির্দেশনা (Updated Guidance):\n${matched.recommendedAction}\n\n🏢 দায়িত্বপ্রাপ্ত কাউন্টার: ${matched.counter}`;

        res.json({
          valid: true,
          reply,
          report: matched,
          formatted_response: fr,
          currentStep: 'completed',
          nextStep: 'completed'
        });
        return;
      } else {
        res.json({
          valid: true,
          reply: `রিপোর্ট নং (${repNum}) সিস্টেমে নথিভুক্ত রয়েছে। ইউডিসি কাউন্টারে এই রিপোর্ট নম্বরটি প্রদর্শন করে দ্রুত সেবা গ্রহণ করতে পারেন।`,
          currentStep: 'completed',
          nextStep: 'completed'
        });
        return;
      }
    }

    // 3️⃣ New citizen → auto report number & 4️⃣ Issue understanding & 5️⃣ Final response template
    if (step === 'new_issue') {
      const text = (issueText || '').trim();
      const newReportNo = generateNumericReportNumber();

      const citizenName = name || 'নতুন নাগরিক';
      const citizenMobile = mobile || '01XXXXXXXXX';

      dynamicCitizens.push({
        name: citizenName,
        mobile: citizenMobile,
        reportNumber: newReportNo,
        issueText: text,
        createdAt: new Date().toISOString()
      });

      const detectedCat = detectCategoryFromText(text);

      const newReportRecord: DynamicReportRecord = {
        reportNo: newReportNo,
        citizenName,
        mobile: citizenMobile,
        serviceName: detectedCat === 'অন্যান্য' ? 'সাধারণ নাগরিক সেবা ও তথ্য' : `${detectedCat} সংক্রান্ত সেবা`,
        previousIssue: text,
        reasonForContact: 'নতুন নাগরিক আবেদন দাখিল ও ট্র্যাকিং',
        relatedDocuments: ['জাতীয় পরিচয়পত্র (NID) / অনলাইন জন্ম নিবন্ধন সনদ', 'প্রযোজ্য ক্ষেত্রে চেয়ারম্যান প্রত্যয়ন'],
        stuckStep: 'প্রাথমিক যাচাই সম্পন্ন',
        currentStatus: 'নতুন রিপোর্ট সংরক্ষিত',
        counter: 'ইউনিয়ন ডিজিটাল সেন্টার (UDC)',
        recommendedAction: 'প্রয়োজনীয় কাগজপত্র প্রস্তুত করে ইউনিয়ন ডিজিটাল সেন্টারে জমা দিন।',
        submissionDate: new Date().toLocaleDateString('bn-BD')
      };
      dynamicReports.push(newReportRecord);

      const fr = createEmptyFormattedResponse();
      fr.service = newReportRecord.serviceName;
      fr.documents = [...newReportRecord.relatedDocuments];
      fr.steps = [
        '১) ইউনিয়ন ডিজিটাল সেন্টারে (UDC) কাগজপত্র জমা',
        '২) যাচাই-বাছাই ও সচিব/চেয়ারম্যান অনুমোদন'
      ];
      fr.counter = newReportRecord.counter;
      fr.notes = ['দালালমুক্ত সেবা পেতে সরাসরি ইউনিয়ন পরিষদ কার্যালয়ে আসুন।'];
      fr.report_analysis = {
        reportNumber: newReportNo,
        summary: text,
        possible_reason: 'নতুন নাগরিক সমস্যা নিবন্ধিত হয়েছে',
        recommended_action: newReportRecord.recommendedAction
      };

      const finalReply = `আপনার রিপোর্ট নং তৈরি হয়েছে: ${newReportNo}\nএটি ভবিষ্যতে আপনার সমস্যার ট্র্যাকিংয়ের জন্য ব্যবহার হবে।\n\n` + buildBanglaFormattedTemplate(fr) + `\n\n🤝 আর কোনো সহায়তা লাগবে?`;

      res.json({
        generated_report_number: newReportNo,
        reply: finalReply,
        category: detectedCat,
        formatted_response: fr,
        currentStep: 'completed',
        nextStep: 'completed'
      });
      return;
    }

    res.status(400).json({ error: 'Invalid step' });
  } catch (err: any) {
    console.error('Flowchart step error:', err);
    res.status(500).json({ error: 'Internal flowchart processing error' });
  }
});

// Vite Middleware & Static Serving Setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Union Parishad Helpdesk Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
